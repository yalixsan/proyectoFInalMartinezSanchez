package domain;

/**
 * Representa el suelo 
 */
public class CheckeredFloor extends BoardElement {
    private double width, height;

    /**
     * Crea un nuevo suelo
     * @param position Coordenada superior izquierda (X, Y) donde empieza el suelo
     * @param width    El ancho total del rectángulo del suelo
     * @param height   La altura total del rectángulo del suelo
     */
    public CheckeredFloor(Position position, double width, double height) {
        super(position);
        this.width = width;
        this.height = height;
    }

    /** 
     * @return El ancho del suelo. 
     */
    public double getWidth() { return width; }
    
    /**
     *  @return La altura del suelo. 
     */
    public double getHeight() { return height; }

    @Override
    public java.util.Map<String, String> toVisualMap() {
        java.util.Map<String, String> data = new java.util.HashMap<>();
        if (isActive) {
            data.put("shape", "CHECKER");
            data.put("x", String.valueOf((int)position.getX()));
            data.put("y", String.valueOf((int)position.getY()));
            data.put("w", String.valueOf((int)width));
            data.put("h", String.valueOf((int)height));
            data.put("r", "255");
            data.put("g", "255");
            data.put("b", "255");
            data.put("br", "0");
            data.put("bg", "0");
            data.put("bb", "0");
        }
        return data;
    }
}
