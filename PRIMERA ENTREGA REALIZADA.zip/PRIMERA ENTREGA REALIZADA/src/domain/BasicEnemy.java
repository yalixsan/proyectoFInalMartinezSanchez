package domain;

/**
 * Enemigo clásico representado como una esfera o punto azul
 * Se mueve siguiendo estrictamente la estrategia inyectada y mata al instante
 */
public class BasicEnemy extends Enemy {
    /**
     * Crea al enemigo básico
     * @param position Punto de inicio
     * @param movementStrategy Patrón de movimiento
     */
    public BasicEnemy(Position position, MovementStrategy movementStrategy) {
        super(position, 1.0, movementStrategy);
    }

    /** Vacío ya que su movimiento está controlado por el Game Loop a través de Tickable */
    @Override
    public void move() {
    }

    /** Permite al GamePanel dibujar este enemigo en la pantalla */
    @Override
    public void accept(BoardElementVisitor visitor) {
        visitor.visitBasicEnemy(this);
    }
}
