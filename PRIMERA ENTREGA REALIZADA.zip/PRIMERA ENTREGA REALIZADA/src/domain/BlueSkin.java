package domain;
import java.awt.Color;

public class BlueSkin implements PlayerSkin {
    public double getSpeed() { return 5.25; }
    public double getSize() { return 1.5; }
    public String getName() { return "BlueSkin"; }
    public HitResult onHit(Player player) { return HitResult.DEAD; }
    public void onRespawn() {}
    public Color getColor() { return Color.BLUE; }
}
