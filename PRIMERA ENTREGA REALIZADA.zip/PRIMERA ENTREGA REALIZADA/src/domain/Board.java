package domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Almacena de forma categorizada todos los elementos del mundo
 * Responsable de revisar colisiones y saber en dónde se puede caminar para el Player
 */
public class Board {
    private int width;
    private int height;
    private List<BoardElement> renderingElements;
    private List<Collidable> collidables;
    private List<Collectable> collectables;
    private List<ZoneElement> zones;
    private List<Tickable> tickables;
    private int timeLimit = 50;

    /**
     * Instancia un tablero vacío preparándolo para ser llenado por el LevelLoader
     * @param width  Ancho del área de juego
     * @param height Alto del área de juego
     */
    public Board(int width, int height) {
        this.width = width;
        this.height = height;
        this.renderingElements = new ArrayList<>();
        this.collidables = new ArrayList<>();
        this.collectables = new ArrayList<>();
        this.zones = new ArrayList<>();
        this.tickables = new ArrayList<>();
    }

    public void addVisual(BoardElement element) { renderingElements.add(element); }
    public void addCollidable(Collidable collidable) { collidables.add(collidable); }
    public void addCollectable(Collectable collectable) { collectables.add(collectable); }
    public void addZone(ZoneElement zone) { zones.add(zone); }
    public void addTickable(Tickable tickable) { tickables.add(tickable); }
    
    /** 
     * Vacía completamente el nivel actual (usado al cargar un nuevo nivel o resetear) 
     */
    public void clearAll() {
        renderingElements.clear(); collidables.clear(); collectables.clear(); zones.clear(); tickables.clear();
    }

    public List<BoardElement> getElementsAt(Position position) {
        List<BoardElement> found = new ArrayList<>();
        for (BoardElement e : renderingElements) {
            if (e.getPosition().distanceTo(position) < 1.0) {
                found.add(e);
            }
        }
        return found;
    }

    /**
     * Revisa físicamente si un elemento en movimiento ha chocado contra las "hitboxes" de otros elementos
     * @param element El objeto en movimiento
     * @param elementSizeX Ancho del objeto
     * @param elementSizeY Alto del objeto
     * @return Una lista con todo aquello que fue tocado en ese fotograma
     */
    public List<Collidable> checkCollision(MovableElement element, double elementSizeX, double elementSizeY) {
        List<Collidable> hits = new ArrayList<>();
        double threshold = (elementSizeX / 2.0) + 8.0;

        for (Collidable c : collidables) {
            if (c != element) {
                double dx = (c.getPosition().getX() + (elementSizeX / 2.0)) - (element.getPosition().getX() + (elementSizeX / 2.0));
                double dy = (c.getPosition().getY() + (elementSizeY / 2.0)) - (element.getPosition().getY() + (elementSizeY / 2.0));
                double dist = Math.sqrt(dx*dx + dy*dy);

                if (dist < threshold) { 
                    hits.add(c);
                }
            }
        }
        return hits;
    }

    /**
     * Chequea si es posible caminar hacia un punto
     * @param position Coordenada que se desea pisar
     * @param size Tamaño del que quiere caminar
     * @return true si el espacio está libre
     */
    public boolean isWalkable(Position position, double size) {
        for (Collidable c : collidables) {
            if (c.blocksPosition(position, size)) {
                return false;
            }
        }
        return position.getX() >= 0 && position.getX() + size <= width && position.getY() >= 0 && position.getY() + size <= height;
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public List<BoardElement> getVisualElements() { return renderingElements; }
    public List<Collidable> getCollidables() { return collidables; }
    public List<Collectable> getCollectables() { return collectables; }
    public List<ZoneElement> getZones() { return zones; }
    public List<Tickable> getTickables() { return tickables; }
    public int getTimeLimit() { return timeLimit; }
    public void setTimeLimit(int timeLimit) { this.timeLimit = timeLimit; }
}
