package domain;

public abstract class BoardElement {
    protected Position position;
    protected boolean isActive;

    public BoardElement(Position position) {
        this.position = position;
        this.isActive = true;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public boolean isActive() {
        return isActive;
    }

    public void deactivate() {
        this.isActive = false;
    }

    public abstract void accept(BoardElementVisitor visitor);
}
