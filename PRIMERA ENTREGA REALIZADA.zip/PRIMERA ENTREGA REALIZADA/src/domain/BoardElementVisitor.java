package domain;

public interface BoardElementVisitor {
    void visitWall(Wall wall);
    void visitInitialZone(InitialZone zone);
    void visitFinalZone(FinalZone zone);
    void visitYellowCoin(YellowCoin coin);
    void visitBasicEnemy(BasicEnemy enemy);
    void visitCheckeredFloor(CheckeredFloor floor);
}
