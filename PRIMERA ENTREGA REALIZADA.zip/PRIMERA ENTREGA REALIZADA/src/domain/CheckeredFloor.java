package domain;

/**
 * Representa el suelo ajedrezado, lo cual hicimos debido a que es decorativo en el nivel
 * Este elemento no tiene ni fisicas ni colosiones, es decorativo
 */
public class CheckeredFloor extends BoardElement {
    private double width, height;

    /**
     * Crea un nuevo suelo ajedrezado
     * @param position Coordenada superior izquierda (X, Y) donde empieza el suelo
     * @param width    El ancho total del rectángulo del suelo
     * @param height   La altura total del rectángulo del suelo
     */
    public CheckeredFloor(Position position, double width, double height) {
        super(position);
        this.width = width;
        this.height = height;
    }

    /**
     * Acepta al visitante gráfico para ser renderizado en pantalla
     * @param visitor El objeto encargado de dibujar 
     */
    @Override
    public void accept(BoardElementVisitor visitor) {
        visitor.visitCheckeredFloor(this);
    }

    /** 
     * @return El ancho del suelo. 
     */
    public double getWidth() { return width; }
    
    /**
     *  @return La altura del suelo. 
     */
    public double getHeight() { return height; }
}
