package domain;

/**
 * Representa una moneda dentro del juego
 * Actúa como la clase base para todos los tipos específicos de monedas que se pueden manejar a futuro
 * Implementa el patrón de Doble Despacho (Double Dispatch) para manejar las colisiones
 * con el jugador de forma segura y puramente polimórfica.
 */
public abstract class Coin extends CollectableElement {
    /**
     * Constructor de moneda 
     * @param position La posición donde se instanciará la moneda en el tablero
     */
    public Coin(Position position) {
        super(position);
    }

    /**
     * Define lo que sucede cuando el jugador colisiona con la moneda
     * @param p    El objeto Player que ha tocado la moneda
     * @param mode El modo de juego actual 
     */
    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
        if (isActive()) {
            p.collectCoin(this);
        }
    }
}
