package domain;

public interface Collectable {
    boolean countsAsRequiredCoin();
    void resetIfCollectable();
}
