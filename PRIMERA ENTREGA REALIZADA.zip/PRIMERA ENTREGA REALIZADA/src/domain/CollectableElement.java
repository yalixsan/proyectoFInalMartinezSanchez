package domain;

/**
 * Clase base abstracta para cualquier elemento del juego que pueda ser recogido por el jugador
 */
public abstract class CollectableElement extends BoardElement implements Collectable, Collidable {
    /** 
     * Indica si el elemento ya ha sido recolectado por el jugador 
     */
    protected boolean collected;

    /**
     * Constructor default para un elemento recolectable
     * @param position Coordenada inicial del elemento
     */
    public CollectableElement(Position position) {
        super(position);
        this.collected = false;
    }

    /**
     * Define la acción específica que ocurre cuando este elemento es recolectado
     * @param player El jugador que recolecta el elemento
     */
    public abstract void collect(Player player);

    /**
     * Restaura el elemento a su estado original
     * Útil para cuando el jugador muere y el nivel se reinicia
     */
    public void reset() {
        this.collected = false;
        this.isActive = true;
    }

    /**
     * Implementación de la interfaz Collectable para reiniciar el estado de colección.
     */
    @Override
    public void resetIfCollectable() {
        reset();
    }

    /**
     * Determina si este recolectable es obligatorio para pasar el nivel
     * @return true si cuenta como moneda/requisito obligatorio, false en caso contrario
     */
    @Override
    public boolean countsAsRequiredCoin() { return true; }

    /**
     * Lógica por defecto de colisión para elementos
     * @param p    El jugador involucrado en la colisión.
     * @param mode Modo de juego actual.
     */
    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
        if (isActive()) {
            this.collect(p);
        }
    }

    /**
     * Determina si este elemento actúa como un obstáculo sólido
     * @param pos  Posición a verificar
     * @param size Tamaño del objeto intentando cruzar
     * @return false porque los recolectables no bloquean el movimiento
     */
    @Override
    public boolean blocksPosition(Position pos, double size) {
        return false;
    }

    /**
     * @return true si el elemento ya fue agarrado por el jugador
     */
    public boolean isCollected() {
        return collected;
    }
}
