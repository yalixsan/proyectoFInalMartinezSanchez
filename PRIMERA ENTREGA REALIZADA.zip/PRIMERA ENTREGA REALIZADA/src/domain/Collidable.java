package domain;

public interface Collidable {
    Position getPosition();
    boolean blocksPosition(Position pos, double size);
    void collideWithPlayer(Player p, GameMode mode);
}
