package domain;

import java.util.List;

/**
 * La clase fachada
 * Centraliza el estado global, el ciclo de vida del juego y coordina a los diferentes modos de juego
 */
public class DOPOGame {
    private Board board;
    private GameState state;
    private GameMode gameMode;
    private GameTimer timer;

    /**
     * Constructor base, el juego arranca en estado READY
     */
    public DOPOGame() {
        this.state = GameState.READY;
    }

    private String currentLevelName = "level1";

    /**
     * Inicia una partida cargando el nivel especificado desde un archivo
     * @param configPath Nombre del nivel
     * @param mode Modalidad de juego 
     * @param players Lista de jugadores participantes
     */
    public void startGame(String configPath, String mode, List<Player> players) {
        this.state = GameState.PLAYING;
        this.currentLevelName = configPath;
        
        LevelLoader loader = new LevelLoader();
        this.board = loader.loadLevel(configPath);
        
        if (mode.equals("SinglePlayer")) {
            this.gameMode = new SinglePlayerMode(players, board);
        }
        
        this.timer = new GameTimer(board.getTimeLimit()); 
        this.gameMode.initGame();
    }

    public String getCurrentLevelName() { return currentLevelName; }

    /** 
     * Pausa la ejecución lógica del juego (Game Loop)
     */
    public void pauseGame() {
        if (state == GameState.PLAYING) state = GameState.PAUSED;
    }

    /**
     *  Reanuda el Game Loop
     */
    public void resumeGame() {
        if (state == GameState.PAUSED) state = GameState.PLAYING;
    }

    /**
     * Termina la partida actual inmediatamente
     */
    public void endGame() {
        state = GameState.GAME_OVER;
    }

    /**
     * Recibe la acción del teclado del usuario y la enruta al jugador correcto
     * @param playerId ID numérico del jugador
     * @param direction Dirección a moverse
     */
    public void movePlayer(int playerId, Direction direction) {
        if (state != GameState.PLAYING) return;
        for (Player p : gameMode.getPlayers()) {
            p.processRemoteInput(playerId, direction);
        }
    }

    /**
     * El corazón del Game Loop, se ejecuta una cantidad X de veces por segundo
     */
    public void tick() {
        if (state != GameState.PLAYING) return;
        
        gameMode.tick();
        timer.tick();

        if (gameMode.checkVictory()) {
            state = GameState.VICTORY;
        } else if (gameMode.isGameOver() || timer.isTimeUp()) {
            state = GameState.GAME_OVER;
        }
    }



    public Board getBoard() { return board; }
    public GameState getState() { return state; }
    public GameMode getGameMode() { return gameMode; }
    public GameTimer getTimer() { return timer; }
}
