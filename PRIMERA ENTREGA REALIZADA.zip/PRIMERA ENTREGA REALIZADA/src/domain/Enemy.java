package domain;

/**
 * Representa la clase base de todos los enemigos en el juego
 * Al ser un Tickable, el motor gráfico actualiza su posición autónomamente en cada fotograma
 */
public abstract class Enemy extends MovableElement implements Collidable, Tickable {
    protected MovementStrategy movementStrategy;

    /**
     * Instancia un enemigo genérico
     * @param position Coordenada inicial de aparición
     * @param speed    Velocidad de movimiento
     * @param movementStrategy Algoritmo que define cómo y hacia dónde se mueve (ej: Lineal para este ciclo)
     */
    public Enemy(Position position, double speed, MovementStrategy movementStrategy) {
        super(position, speed);
        this.movementStrategy = movementStrategy;
    }

    /**
     * Permite cambiar el patrón de movimiento del enemigo
     */
    public void setMovementStrategy(MovementStrategy movementStrategy) {
        this.movementStrategy = movementStrategy;
    }

    public MovementStrategy getMovementStrategy() {
        return movementStrategy;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    /**
     * Devuelve falso porque los enemigos no bloquean el paso físico, sino que matan al contacto
     */
    @Override
    public boolean blocksPosition(Position pos, double size) {
        return false; // Los enemigos matan, y no bloquean :D
    }

    /**
     * Método invocado por el Game Loop 60 veces por segundo
     */
    @Override
    public void tick(Board board) {
        Position nextPos = movementStrategy.calculateNextPosition(this, board);
        setPosition(nextPos);
    }

    /**
     * Delega el manejo de la muerte del jugador al GameMode activo 
     */
    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
        mode.handlePlayerEnemyCollision(p, this);
    }
}
