package domain;

/**
 * Representa la zona final verde que sirve como meta del nivel
 * Si el jugador entra aquí tras recoger todas las monedas, gana el nivel
 */
public class FinalZone extends Zone {
    /**
     * Crea una zona final
     * @param position Coordenada superior izquierda
     * @param width    Ancho de la meta
     * @param height   Alto de la meta
     */
    public FinalZone(Position position, double width, double height) {
        super(position, width, height);
    }

    /**
     * Verifica si el jugador ha llegado a la meta
     * @param pos La posición actual del jugador
     * @return true si el jugador está pisando esta zona
     */
    @Override
    public boolean isFinalZoneFor(Position pos) {
        return contains(pos);
    }

    /**
     * Permite que el motor gráfico dibuje esta zona
     * @param visitor El visitante gráfico
     */
    @Override
    public void accept(BoardElementVisitor visitor) {
        visitor.visitFinalZone(this);
    }
}
