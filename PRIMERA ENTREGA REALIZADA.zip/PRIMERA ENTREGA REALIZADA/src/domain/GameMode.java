package domain;

import java.util.List;

/**
 * Clase base abstracta para cualquier modo de juego
 * Encapsula la lógica de victoria, colisiones y Game Loop específico
 */
public abstract class GameMode {
    protected List<Player> players;
    protected Board board;

    /**
     * Constructor base de un modo de juego
     * @param players Lista de jugadores participantes
     * @param board Tablero inicializado
     */
    public GameMode(List<Player> players, Board board) {
        this.players = players;
        this.board = board;
    }

    /** 
     * Inicializa la partida
     */
    public abstract void initGame();
    /** 
     * Actualiza la lógica de este modo 60 veces por segundo
     */
    public abstract void tick();
    /** 
     * @return true si se cumplieron las condiciones para ganar este nivel
     */
    public abstract boolean checkVictory();
    
    /**
     * Decide qué pasa cuando un jugador choca con un enemigo en este modo de juego
     */
    public abstract void handlePlayerEnemyCollision(Player player, Enemy enemy);
    /**
     * Decide qué pasa cuando dos jugadores chocan entre sí 
     */
    public abstract void handlePlayerPlayerCollision(Player player1, Player player2);
    /**
     * @return true si el jugador perdió la partida
     */
    public abstract boolean isGameOver();
    public List<Player> getPlayers() { return players; }
    public Board getBoard() { return board; }
}
