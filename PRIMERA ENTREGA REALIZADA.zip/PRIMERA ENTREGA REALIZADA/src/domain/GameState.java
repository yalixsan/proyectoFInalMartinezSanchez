package domain;

public enum GameState {
    READY, PLAYING, PAUSED, VICTORY, GAME_OVER
}
