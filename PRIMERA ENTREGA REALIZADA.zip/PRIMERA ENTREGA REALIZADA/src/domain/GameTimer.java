package domain;

public class GameTimer {
    private long remainingMs;
    private long lastTickTime;

    public GameTimer(int totalSeconds) {
        this.remainingMs = totalSeconds * 1000L;
        this.lastTickTime = System.currentTimeMillis();
    }

    public void tick() {
        long now = System.currentTimeMillis();
        long delta = now - lastTickTime;
        this.lastTickTime = now;
        
        if (remainingMs > 0) {
            remainingMs -= delta;
        }
    }

    public int getRemainingTime() { 
        return (int) Math.max(0, remainingMs / 1000); 
    }
    
    public boolean isTimeUp() { 
        return remainingMs <= 0; 
    }
}
