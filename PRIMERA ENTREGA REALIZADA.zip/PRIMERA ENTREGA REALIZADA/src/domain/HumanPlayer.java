package domain;
import java.awt.Color;

public class HumanPlayer extends Player {
    private int playerId;

    public HumanPlayer(Position position, PlayerSkin skin, Color borderColor, int playerId) {
        super(position, skin, borderColor);
        this.playerId = playerId;
    }

    public int getPlayerId() {
        return playerId;
    }

    @Override
    public void processRemoteInput(int pid, Direction dir) {
        if (this.playerId == pid) {
            handleInput(dir);
        }
    }
}
