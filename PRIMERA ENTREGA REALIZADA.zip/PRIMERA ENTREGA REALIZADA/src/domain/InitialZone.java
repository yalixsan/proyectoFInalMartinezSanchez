package domain;

/**
 * Representa la zona inicial verde donde el jugador comienza o reaparece al morir
 */
public class InitialZone extends Zone {
    /**
     * Crea una zona inicial
     * @param position Coordenada superior izquierda
     * @param width    Ancho de la zona
     * @param height   Alto de la zona
     */
    public InitialZone(Position position, double width, double height) {
        super(position, width, height);
    }

    /**
     * Calcula dinámicamente el punto central de la zona para que el jugador aparezca ahí
     * @return Las coordenadas exactas del centro de la zona
     */
    @Override
    public Position getSpawnPoint() {
        // Esto se desarrolló para q el jugador aparezca directamente en la mitad de la zona de spawn sin importar tamaño, para hacerlo más fiel al juego og :D
        double centerX = getPosition().getX() + (getWidth() / 2) - 10;
        double centerY = getPosition().getY() + (getHeight() / 2) - 10;
        return new Position(centerX, centerY);
    }

    /**
     * Permite que el motor gráfico dibuje esta zona
     * @param visitor El visitante gráfico
     */
    @Override
    public void accept(BoardElementVisitor visitor) {
        visitor.visitInitialZone(this);
    }
}
