package domain;

/**
 * Fábrica centralizada encargada de leer y construir los niveles desde archivos de texto
 * Cumple con el Principio de Responsabilidad Única (SRP) quitándole esa carga al motor principal
 * También cumple con Open/Closed (OCP) al permitir niveles infinitos sin tocar el código fuente
 */
public class LevelLoader {
    /**
     * Constructor por defecto del cargador de niveles
     */
    public LevelLoader() {
    }

    /**
     * Lee un archivo .txt de la carpeta levels y construye un tablero jugable
     * @param levelConfig El nombre del nivel a cargar (ej. "level1")
     * @return El tablero completamente ensamblado con muros, enemigos y zonas
     * @throws IllegalArgumentException si el archivo no existe o no se puede leer
     */
    public Board loadLevel(String levelConfig) {
        String filePath = "levels/" + levelConfig + ".txt";
        
        java.util.List<String> lines;
        try {
            lines = java.nio.file.Files.readAllLines(java.nio.file.Paths.get(filePath));
        } catch (java.io.IOException e) {
            throw new IllegalArgumentException("Level not implemented: " + levelConfig);
        }

        Board board = new Board(800, 600);
        board.clearAll();
        
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            
            String[] parts = line.split(" ");
            String command = parts[0];
            
            try {
                switch (command) {
                    case "TIME":
                        board.setTimeLimit(Integer.parseInt(parts[1]));
                        break;
                    case "ZONE":
                        parseZone(parts, board);
                        break;
                    case "FLOOR":
                        parseFloor(parts, board);
                        break;
                    case "WALL":
                        parseWall(parts, board);
                        break;
                    case "COIN":
                        parseCoin(parts, board);
                        break;
                    case "ENEMY":
                        parseEnemy(parts, board);
                        break;
                    default:
                        System.err.println("Unknown command: " + command);
                }
            } catch (Exception ex) {
                System.err.println("Error parsing line: " + line);
            }
        }
        
        return board;
    }

    /**
     * Procesa una línea de comando tipo ZONE para crear zonas iniciales o finales
     * @param parts Arreglo con las palabras separadas de la línea de texto
     * @param board El tablero donde se guardará la zona
     */
    private void parseZone(String[] parts, Board board) {
        String type = parts[1];
        double x = Double.parseDouble(parts[2]);
        double y = Double.parseDouble(parts[3]);
        double w = Double.parseDouble(parts[4]);
        double h = Double.parseDouble(parts[5]);
        
        if (type.equals("INITIAL")) {
            registerZone(board, new InitialZone(new Position(x, y), w, h));
        } else if (type.equals("FINAL")) {
            registerZone(board, new FinalZone(new Position(x, y), w, h));
        }
    }

    /**
     * Procesa una línea de comando tipo FLOOR para crear el suelo estético
     * @param parts Arreglo con la configuración del piso
     * @param board El tablero donde se guardará el suelo
     */
    private void parseFloor(String[] parts, Board board) {
        if (parts[1].equals("CHECKERED")) {
            double x = Double.parseDouble(parts[2]);
            double y = Double.parseDouble(parts[3]);
            double w = Double.parseDouble(parts[4]);
            double h = Double.parseDouble(parts[5]);
            board.addVisual(new CheckeredFloor(new Position(x, y), w, h));
        }
    }

    /**
     * Procesa una línea de comando tipo WALL para construir un muro colisionable
     * @param parts Arreglo con las coordenadas y visibilidad del muro
     * @param board El tablero donde se registrará el muro
     */
    private void parseWall(String[] parts, Board board) {
        double x = Double.parseDouble(parts[1]);
        double y = Double.parseDouble(parts[2]);
        double w = Double.parseDouble(parts[3]);
        double h = Double.parseDouble(parts[4]);
        boolean visible = Boolean.parseBoolean(parts[5]);
        registerWall(board, new Wall(new Position(x, y), w, h, visible));
    }

    /**
     * Procesa una línea de comando tipo COIN para colocar monedas
     * @param parts Arreglo con el tipo y posición de la moneda
     * @param board El tablero a actualizar
     */
    private void parseCoin(String[] parts, Board board) {
        if (parts[1].equals("YELLOW")) {
            double x = Double.parseDouble(parts[2]);
            double y = Double.parseDouble(parts[3]);
            registerCoin(board, new YellowCoin(new Position(x, y)));
        }
    }

    /**
     * Procesa una línea de comando tipo ENEMY y le asigna su estrategia de movimiento
     * @param parts Arreglo con los datos del enemigo (posición, dirección H/V, velocidad)
     * @param board El tablero donde nacerá el enemigo
     */
    private void parseEnemy(String[] parts, Board board) {
        if (parts[1].equals("BASIC")) {
            double x = Double.parseDouble(parts[2]);
            double y = Double.parseDouble(parts[3]);
            boolean isHorizontal = parts[4].equals("H");
            double speed = Double.parseDouble(parts[5]);
            
            BasicEnemy e = new BasicEnemy(new Position(x, y), new LinearMovement(isHorizontal));
            e.setSpeed(speed);
            registerEnemy(board, e);
        }
    }

    /**
     * Registra un muro en las listas correctas del tablero (Visual y Colisionable)
     */
    private void registerWall(Board board, Wall w) {
        board.addVisual(w);
        board.addCollidable(w);
    }
    
    /**
     * Registra una zona en las listas correctas del tablero (Visual y Zona)
     */
    private void registerZone(Board board, Zone z) {
        board.addVisual(z);
        board.addZone(z);
    }
    
    /**
     * Registra una moneda en las listas correctas (Visual, Colisionable y Recolectable)
     */
    private void registerCoin(Board board, YellowCoin c) {
        board.addVisual(c);
        board.addCollidable(c);
        board.addCollectable(c);
    }
    
    /**
     * Registra un enemigo asignándolo al Game Loop (Tickable) y a las colisiones
     */
    private void registerEnemy(Board board, BasicEnemy e) {
        board.addVisual(e);
        board.addCollidable(e);
        board.addTickable(e);
    }
}
