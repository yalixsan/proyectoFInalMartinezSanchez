package domain;

/**
 * Estrategia de movimiento para enemigos
 * Hace rebotar a los enemigos cuando tocan una pared, en el eje X o Y
 */
public class LinearMovement implements MovementStrategy {
    private boolean horizontal;
    private int directionSign = 1;

    /**
     * @param horizontal true para patrullaje de izquierda a derecha, false para arriba/abajo
     */
    public LinearMovement(boolean horizontal) {
        this.horizontal = horizontal;
    }

    /**
     * Realiza un test contra las paredes. Si se va a chocar, invierte su dirección
     */
    @Override
    public Position calculateNextPosition(Enemy enemy, Board board) {
        double currentX = enemy.getPosition().getX();
        double currentY = enemy.getPosition().getY();
        double speed = enemy.getSpeed();

        Position nextPos;
        if (horizontal) {
            nextPos = new Position(currentX + (directionSign * speed), currentY);
        } else {
            nextPos = new Position(currentX, currentY + (directionSign * speed));
        }

        if (!board.isWalkable(nextPos, 20.0)) {
            directionSign *= -1;
            return enemy.getPosition();
        }

        return nextPos;
    }

    public boolean isHorizontal() {
        return horizontal;
    }
}
