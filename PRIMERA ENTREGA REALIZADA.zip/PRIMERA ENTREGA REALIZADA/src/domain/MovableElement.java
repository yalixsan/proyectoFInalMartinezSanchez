package domain;

public abstract class MovableElement extends BoardElement {
    protected double speed;

    public MovableElement(Position position, double speed) {
        super(position);
        this.speed = speed;
    }

    public abstract void move();

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }
}
