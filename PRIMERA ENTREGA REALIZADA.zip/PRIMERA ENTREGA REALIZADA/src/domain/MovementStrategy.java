package domain;

public interface MovementStrategy {
    Position calculateNextPosition(Enemy enemy, Board board);
}
