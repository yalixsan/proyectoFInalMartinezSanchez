package domain;
import java.awt.Color;

/**
 * Representa al jugador principal del juego
 * Maneja sus vidas, monedas, posiciones de reaparición, etc
 */
public abstract class Player extends MovableElement {
    protected int deaths;
    protected int collectedCoins;
    protected int totalCoinsRequired;
    protected int shieldPoints; 
    protected PlayerSkin currentSkin;
    protected PlayerSkin originalSkin;
    protected Color borderColor;
    protected Position spawnPoint;
    protected Direction intendedDirection = Direction.NONE;
    protected int invulnerabilityTimer = 0;

    /**
     * Crea un nuevo jugador
     * @param position Coordenada inicial de aparición
     * @param skin La apariencia y habilidades especiales que tendrá el jugador
     * @param borderColor El color del borde del cuadrado del jugador
     */
    public Player(Position position, PlayerSkin skin, Color borderColor) {
        super(position, skin.getSpeed());
        this.originalSkin = skin;
        this.currentSkin = skin;
        this.borderColor = borderColor;
        this.deaths = 0;
        this.collectedCoins = 0;
        this.spawnPoint = new Position(position.getX(), position.getY());
    }

    /**
     * Procesa lo que sucede cuando el jugador es impactado por un enemigo
     * Llama a la Skin actual para saber si sobrevive o muere
     * @return El resultado del impacto (muerto o sobrevive por escudo)
     */
    public HitResult receiveHit() {
        if (invulnerabilityTimer > 0) {
            return HitResult.SURVIVED_SHIELD;
        }

        HitResult result = currentSkin.onHit(this);
        if (result == HitResult.SURVIVED_SHIELD) {
            invulnerabilityTimer = 60; // Grant 1 second of invulnerability (60 ticks)
        } else if (result == HitResult.DEAD) {
            die();
        }
        return result;
    }

    /**
     * Reduce el contador de invulnerabilidad en cada tick del juego
     */
    public void decreaseInvulnerability() {
        if (invulnerabilityTimer > 0) invulnerabilityTimer--;
    }

    /**
     * Mata al jugador, aumenta su contador de muertes y lo devuelve al punto de control
     */
    public void die() {
        this.deaths++;
        respawn();
    }

    /**
     * Revive al jugador en el último punto de aparición (Spawnpoint) registrado
     * También restaura su apariencia original en caso de haberla perdido
     */
    public void respawn() {
        this.position = new Position(spawnPoint.getX(), spawnPoint.getY());
        this.currentSkin = originalSkin;
        this.currentSkin.onRespawn();
        this.invulnerabilityTimer = 0;
    }

    /**
     * Permite al jugador recoger una moneda y sumar al contador
     * @param coin La moneda física con la que acaba de chocar
     */
    public void collectCoin(Coin coin) {
        collectedCoins++;
        coin.collect(this);
    }

    /**
     * Actualiza el punto de control del jugador (donde nacerá si muere)
     * @param spawnPoint Las nuevas coordenadas seguras
     */
    public void setSpawnPoint(Position spawnPoint) {
        this.spawnPoint = spawnPoint;
    }

    /**
     * @return true si ya agarró todas las monedas necesarias para abrir la meta
     */
    public boolean hasCollectedAllCoins() {
        return collectedCoins >= totalCoinsRequired;
    }

    /**
     * Recibe la dirección que oprimió el usuario en el teclado
     * @param direction Hacia dónde quiere moverse el jugador
     */
    public void handleInput(Direction direction) {
        this.intendedDirection = direction;
    }

    /**
     * Usa la dirección guardada y la velocidad de la Skin para predecir matemáticamente el siguiente paso
     * @return La coordenada a la que se movería si nada se lo impide
     */
    public Position calculateNextPosition() {
        double currentSpeed = currentSkin.getSpeed();
        double dx = intendedDirection.getDx() * currentSpeed;
        double dy = intendedDirection.getDy() * currentSpeed;
        return this.position.translate(dx, dy);
    }

    /**
     * Ejecuta físicamente el movimiento actualizando su posición en el tablero
     */
    @Override
    public void move() {
        this.position = calculateNextPosition();
    }

    /** 
     * @return La cantidad de veces que ha muerto
     */
    public int getDeaths() { return deaths; }
    /** 
     * @return Cuántas monedas lleva recolectadas
     */
    public int getCollectedCoins() { return collectedCoins; }
    /** 
     * @return true si actualmente tiene un escudo temporal activo
     */
    public boolean isInvulnerable() { return invulnerabilityTimer > 0; }
    /**
     *  Reinicia a cero las monedas al morir 
     */
    public void resetCoins() { this.collectedCoins = 0; }
    /** 
     * @return El color que bordea el cuadrado del jugador
     */
    public Color getBorderColor() { return borderColor; }
    /** 
     * @return La apariencia o estado actual del jugador
     */
    public PlayerSkin getCurrentSkin() { return currentSkin; }
    /** 
     * @param val La cantidad máxima de monedas que pide el nivel
     */
    public void setTotalCoinsRequired(int val) { this.totalCoinsRequired = val; }
    
    public void processRemoteInput(int pid, Direction dir) {}

    @Override
    public void accept(BoardElementVisitor visitor) {}
}
