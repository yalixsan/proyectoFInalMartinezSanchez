package domain;
import java.awt.Color;
public interface PlayerSkin {
    double getSpeed();
    double getSize();
    String getName();
    HitResult onHit(Player player);
    void onRespawn();
    Color getColor();
}
