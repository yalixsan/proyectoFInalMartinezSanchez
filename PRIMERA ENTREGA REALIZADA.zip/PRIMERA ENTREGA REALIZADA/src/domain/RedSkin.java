package domain;
import java.awt.Color;

public class RedSkin implements PlayerSkin {
    public double getSpeed() { return 3.5; }
    public double getSize() { return 1.0; }
    public String getName() { return "RedSkin"; }
    public HitResult onHit(Player player) { return HitResult.DEAD; }
    public void onRespawn() {}
    public Color getColor() { return Color.RED; }
}
