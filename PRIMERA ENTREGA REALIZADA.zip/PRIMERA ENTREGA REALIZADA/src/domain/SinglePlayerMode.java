package domain;

import java.util.List;

/**
 * Modo de juego de 1 solo jugador clásico
 */
public class SinglePlayerMode extends GameMode {
    public SinglePlayerMode(List<Player> players, Board board) {
        super(players, board);
    }

    /**
     * Posiciona al jugador en la Zona Inicial y escanea cuántas monedas hay en el mapa
     */
    @Override
    public void initGame() {
        for (ZoneElement z : board.getZones()) {
            Position spawn = z.getSpawnPoint();
            if (spawn != null) {
                players.get(0).setSpawnPoint(spawn);
                players.get(0).setPosition(new Position(spawn.getX(), spawn.getY()));
                break;
            }
        }
        players.get(0).setTotalCoinsRequired(countCoins());
    }

    private int countCoins() {
        int count = 0;
        for (Collectable c : board.getCollectables()) {
            if (c.countsAsRequiredCoin()) count++;
        }
        return count;
    }

    /**
     * El fotograma lógico del modo un jugador
     * Mueve al jugador, calcula sus colisiones e invoca a los enemigos
     */
    @Override
    public void tick() {
        Player p = players.get(0);
        p.decreaseInvulnerability();
        
        double size = 20.0 * p.getCurrentSkin().getSize();

        Position nextPos = p.calculateNextPosition();
        if (board.isWalkable(nextPos, size)) { 
            p.setPosition(nextPos);
        }
        
        for (Tickable t : board.getTickables()) {
            t.tick(board);
        }

        List<Collidable> collisions = board.checkCollision(p, size, size);
        for (Collidable c : collisions) {
            c.collideWithPlayer(p, this);
        }
    }

    /**
     * Revisa si el jugador está pisando la zona final y ya tiene todas las monedas
     */
    @Override
    public boolean checkVictory() {
        Player p = players.get(0);
        if (p.hasCollectedAllCoins()) {
            for (ZoneElement z : board.getZones()) {
                if (z.isFinalZoneFor(p.getPosition())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Si el jugador muere contra un enemigo, resetea todas sus monedas a cero  y restaura todas las monedas del mapa para volver a intentar
     */
    @Override
    public void handlePlayerEnemyCollision(Player player, Enemy enemy) {
        HitResult result = player.receiveHit();
        if (result == HitResult.DEAD) {
            player.resetCoins();
            for (Collectable c : board.getCollectables()) {
                c.resetIfCollectable();
            }
        }
    }

    @Override
    public void handlePlayerPlayerCollision(Player player1, Player player2) {
    }

    @Override
    public boolean isGameOver() {
        return false;
    }
}
