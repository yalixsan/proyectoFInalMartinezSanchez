package domain;

public abstract class SpecialElement extends BoardElement {
    public SpecialElement(Position position) {
        super(position);
    }
}
