package domain;

public interface Tickable {
    void tick(Board board);
}
