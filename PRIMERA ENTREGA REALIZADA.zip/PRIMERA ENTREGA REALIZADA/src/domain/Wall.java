package domain;

/**
 * Representa un bloque o pared impenetrable en el tablero
 * Puede ser visible (dibujado) o invisible (límites de la pantalla)
 */
public class Wall extends SpecialElement implements Collidable {
    private double width, height;
    private boolean visible = true;

    /**
     * Crea un muro visible por defecto
     */
    public Wall(Position position, double width, double height) {
        this(position, width, height, true);
    }

    /**
     * Crea un muro especificando si es invisible o no
     * @param position Coordenada de la esquina superior izquierda
     * @param width    Ancho de la pared
     * @param height   Alto de la pared
     * @param visible  Si debe ser renderizado por el motor gráfico
     */
    public Wall(Position position, double width, double height, boolean visible) {
        super(position);
        this.width = width;
        this.height = height;
        this.visible = visible;
    }

    /** 
     * Delega al motor gráfico su dibujo si es visible
     */
    @Override
    public void accept(BoardElementVisitor visitor) {
        visitor.visitWall(this);
    }

    @Override
    public Position getPosition() {
        return position;
    }

    /**
     * Verifica geométricamente si otro objeto intenta cruzar las fronteras de esta pared
     * @param pos La posición actual del objeto que intenta moverse
     * @param size El tamaño de dicho objeto
     * @return true si la pared está bloqueando el paso
     */
    @Override
    public boolean blocksPosition(Position pos, double size) {
        double px = pos.getX();
        double py = pos.getY();
        return px < position.getX() + width && 
               px + size > position.getX() &&
               py < position.getY() + height &&
               py + size > position.getY();
    }

    /**
     * No ejecuta acciones especiales al tocarlo
     * Su función de bloqueo ya se cubrió en blocksPosition
     */
    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
    }

    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public boolean isVisible() { return visible; }
}
