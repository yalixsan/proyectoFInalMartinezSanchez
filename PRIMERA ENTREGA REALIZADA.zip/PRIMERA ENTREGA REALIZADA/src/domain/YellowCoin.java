package domain;

/**
 * Representa la típica moneda amarilla coleccionable del juego
 * El jugador debe recogerlas todas para poder ganar el nivel
 */
public class YellowCoin extends Coin {
    /**
     * Crea una moneda en la posición indicada
     */
    public YellowCoin(Position position) {
        super(position);
    }

    /**
     * Marca la moneda como recolectada y la desaparece del tablero
     */
    @Override
    public void collect(Player player) {
        collected = true;
        deactivate();
    }

    @Override
    public void accept(BoardElementVisitor visitor) {
        visitor.visitYellowCoin(this);
    }
}
