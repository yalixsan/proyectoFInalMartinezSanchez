package domain;

/**
 * Representa una zona base abstracta dentro del tablero
 * Sirve como molde para las zonas iniciales y finales del juego
 */
public abstract class Zone extends BoardElement implements ZoneElement {
    protected double width;
    protected double height;

    /**
     * Constructor base para una zona
     * @param position Coordenada superior izquierda de la zona
     * @param width    Ancho de la zona
     * @param height   Alto de la zona
     */
    public Zone(Position position, double width, double height) {
        super(position);
        this.width = width;
        this.height = height;
    }

    /**
     * Verifica si una posición dada se encuentra dentro de esta zona
     * @param pos La posición a verificar
     * @return true si la posición está dentro, false si no
     */
    public boolean contains(Position pos) {
        return pos.getX() >= position.getX() && pos.getX() <= position.getX() + width &&
               pos.getY() >= position.getY() && pos.getY() <= position.getY() + height;
    }

    /**
     * @return La posición por defecto donde aparece el jugador 
     */
    @Override
    public Position getSpawnPoint() { return null; }

    /**
     * @param pos La posición actual del jugador
     * @return true si esta es la zona de victoria para esa posición
     */
    @Override
    public boolean isFinalZoneFor(Position pos) { return false; }

    /** @return El ancho de la zona */
    public double getWidth() { return width; }
    
    /** @return El alto de la zona */
    public double getHeight() { return height; }
}
