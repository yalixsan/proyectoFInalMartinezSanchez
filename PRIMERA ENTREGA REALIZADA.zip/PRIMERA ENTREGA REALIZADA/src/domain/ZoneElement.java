package domain;

public interface ZoneElement {
    Position getSpawnPoint();
    boolean isFinalZoneFor(Position pos);
}
