package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import domain.*;

public class GamePanel extends JPanel {
    private DOPOGame game;
    private boolean up, down, left, right;
    
    private final domain.BoardElementVisitor renderer = new domain.BoardElementVisitor() {
        public void visitWall(domain.Wall w) {
            if (w.isVisible()) {
                g2dGlobal.setColor(new Color(180, 180, 255));
                g2dGlobal.fillRect((int)w.getPosition().getX(), (int)w.getPosition().getY(), (int)w.getWidth(), (int)w.getHeight());
                g2dGlobal.setColor(Color.BLACK);
                g2dGlobal.setStroke(new BasicStroke(3));
                g2dGlobal.drawRect((int)w.getPosition().getX(), (int)w.getPosition().getY(), (int)w.getWidth(), (int)w.getHeight());
            }
        }
        public void visitInitialZone(domain.InitialZone z) {
            g2dGlobal.setColor(new Color(153, 255, 153));
            g2dGlobal.fillRect((int)z.getPosition().getX(), (int)z.getPosition().getY(), (int)z.getWidth(), (int)z.getHeight());
            g2dGlobal.setColor(Color.BLACK);
            g2dGlobal.setStroke(new BasicStroke(3));
            g2dGlobal.drawRect((int)z.getPosition().getX(), (int)z.getPosition().getY(), (int)z.getWidth(), (int)z.getHeight());
        }
        public void visitFinalZone(domain.FinalZone z) {
            g2dGlobal.setColor(new Color(153, 255, 153)); // Light green
            g2dGlobal.fillRect((int)z.getPosition().getX(), (int)z.getPosition().getY(), (int)z.getWidth(), (int)z.getHeight());
            g2dGlobal.setColor(Color.BLACK);
            g2dGlobal.setStroke(new BasicStroke(3));
            g2dGlobal.drawRect((int)z.getPosition().getX(), (int)z.getPosition().getY(), (int)z.getWidth(), (int)z.getHeight());
        }
        public void visitYellowCoin(domain.YellowCoin c) {
            if (c.isActive()) {
                g2dGlobal.setColor(Color.YELLOW);
                g2dGlobal.fillOval((int)c.getPosition().getX(), (int)c.getPosition().getY(), 20, 20);
                g2dGlobal.setColor(Color.BLACK);
                g2dGlobal.setStroke(new BasicStroke(2));
                g2dGlobal.drawOval((int)c.getPosition().getX(), (int)c.getPosition().getY(), 20, 20);
            }
        }
        public void visitBasicEnemy(domain.BasicEnemy e) {
            if (e.isActive()) {
                g2dGlobal.setColor(Color.BLUE);
                g2dGlobal.fillOval((int)e.getPosition().getX(), (int)e.getPosition().getY(), 20, 20);
                g2dGlobal.setColor(Color.BLACK);
                g2dGlobal.setStroke(new BasicStroke(2));
                g2dGlobal.drawOval((int)e.getPosition().getX(), (int)e.getPosition().getY(), 20, 20);
            }
        }
        public void visitCheckeredFloor(domain.CheckeredFloor f) {
            g2dGlobal.setColor(Color.WHITE);
            int cx = (int)f.getPosition().getX(), cy = (int)f.getPosition().getY();
            int cw = (int)f.getWidth(), ch = (int)f.getHeight();
            g2dGlobal.fillRect(cx, cy, cw, ch);
            g2dGlobal.setColor(new Color(230, 230, 255));
            for(int x = 0; x < cw; x += 25) {
                for(int y = 0; y < ch; y += 25) {
                    if(((x / 25) + (y / 25)) % 2 == 0) {
                        g2dGlobal.fillRect(cx + x, cy + y, 25, 25);
                    }
                }
            }
            g2dGlobal.setColor(Color.BLACK);
            g2dGlobal.setStroke(new BasicStroke(3));
            g2dGlobal.drawRect(cx, cy, cw, ch);
        }
    };
    
    private Graphics2D g2dGlobal; 

    public GamePanel(V2GUI gui, DOPOGame game) {
        this.game = game;
        setFocusable(true);
        setBackground(Color.LIGHT_GRAY);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP: case KeyEvent.VK_W: up = true; break;
                    case KeyEvent.VK_DOWN: case KeyEvent.VK_S: down = true; break;
                    case KeyEvent.VK_LEFT: case KeyEvent.VK_A: left = true; break;
                    case KeyEvent.VK_RIGHT: case KeyEvent.VK_D: right = true; break;
                }
                updateDirection();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP: case KeyEvent.VK_W: up = false; break;
                    case KeyEvent.VK_DOWN: case KeyEvent.VK_S: down = false; break;
                    case KeyEvent.VK_LEFT: case KeyEvent.VK_A: left = false; break;
                    case KeyEvent.VK_RIGHT: case KeyEvent.VK_D: right = false; break;
                }
                updateDirection();
            }
        });
    }

    private void updateDirection() {
        Direction dir = Direction.NONE;
        if (up && !down && left && !right) dir = Direction.NORTH_WEST;
        else if (up && !down && !left && right) dir = Direction.NORTH_EAST;
        else if (!up && down && left && !right) dir = Direction.SOUTH_WEST;
        else if (!up && down && !left && right) dir = Direction.SOUTH_EAST;
        else if (up && !down) dir = Direction.NORTH;
        else if (!up && down) dir = Direction.SOUTH;
        else if (left && !right) dir = Direction.WEST;
        else if (!left && right) dir = Direction.EAST;
        
        game.movePlayer(1, dir);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (game.getState() != GameState.PLAYING) return;
        
        Graphics2D g2d = (Graphics2D) g;
        Board board = game.getBoard();

        g2d.setColor(new Color(180, 180, 255));
        g2d.fillRect(0, 0, getWidth(), getHeight());

        if (board != null) {
            this.g2dGlobal = g2d;
            
            for (BoardElement e : board.getVisualElements()) {
                e.accept(renderer);
            }

            if (game.getGameMode() != null) {
                for (Player p : game.getGameMode().getPlayers()) {
                    if (p.isInvulnerable() && System.currentTimeMillis() % 200 < 100) {
                        continue;
                    }

                    g2d.setColor(p.getCurrentSkin().getColor());
                    int size = (int)(20 * p.getCurrentSkin().getSize());
                    g2d.fillRect((int)p.getPosition().getX(), (int)p.getPosition().getY(), size, size);
                    g2d.setColor(Color.BLACK);
                    g2d.drawRect((int)p.getPosition().getX(), (int)p.getPosition().getY(), size, size);
                }
            }
        }

        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        int secondsLeft = game.getTimer().getRemainingTime();
        g2d.drawString("Time: " + secondsLeft + "s", 10, 20);
        if (game.getGameMode() != null && !game.getGameMode().getPlayers().isEmpty()) {
            Player p1 = game.getGameMode().getPlayers().get(0);
            g2d.drawString("Deaths: " + p1.getDeaths(), 120, 20);
            g2d.drawString("Coins: " + p1.getCollectedCoins(), 230, 20);
        }
    }
}
