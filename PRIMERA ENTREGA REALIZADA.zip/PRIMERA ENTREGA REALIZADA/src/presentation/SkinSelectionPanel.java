package presentation;

import javax.swing.*;
import java.awt.*;

import domain.PlayerSkin;
import domain.RedSkin;
import domain.BlueSkin;
import domain.GreenSkin;

public class SkinSelectionPanel extends JPanel {
    private V2GUI gui;
    private PlayerSkin selectedSkin = new RedSkin();

    public SkinSelectionPanel(V2GUI gui) {
        this.gui = gui;
        setLayout(null);
        setBackground(new Color(172, 251, 239)); 

        CustomButton backBtn = new CustomButton("Back");
        backBtn.setBounds(30, 20, 120, 45);
        backBtn.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
        backBtn.addActionListener(e -> gui.showPanel("Play"));

        CustomButton startBtn = new CustomButton("START GAME!");
        startBtn.setBounds(275, 450, 250, 60);
        startBtn.setBackground(new Color(144, 238, 144));
        startBtn.addActionListener(e -> {
            gui.setSelectedSkin(selectedSkin);
            gui.showPanel("LevelSelection");
        });

        JButton redHitbox = new JButton();
        redHitbox.setBounds(200, 250, 80, 80);
        redHitbox.setOpaque(false);
        redHitbox.setContentAreaFilled(false);
        redHitbox.setBorderPainted(false);
        redHitbox.addActionListener(e -> { selectedSkin = new RedSkin(); repaint(); });

        JButton blueHitbox = new JButton();
        blueHitbox.setBounds(360, 250, 80, 80);
        blueHitbox.setOpaque(false);
        blueHitbox.setContentAreaFilled(false);
        blueHitbox.setBorderPainted(false);
        blueHitbox.addActionListener(e -> { selectedSkin = new BlueSkin(); repaint(); });

        JButton greenHitbox = new JButton();
        greenHitbox.setBounds(520, 250, 80, 80);
        greenHitbox.setOpaque(false);
        greenHitbox.setContentAreaFilled(false);
        greenHitbox.setBorderPainted(false);
        greenHitbox.addActionListener(e -> { selectedSkin = new GreenSkin(); repaint(); });

        add(backBtn);
        add(startBtn);
        add(redHitbox);
        add(blueHitbox);
        add(greenHitbox);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Comic Sans MS", Font.BOLD, 45));
        g2d.drawString("Choose your Skin", 210, 120);

        g2d.setColor(Color.YELLOW);
        if (selectedSkin.getColor().equals(Color.RED)) g2d.fillOval(190, 240, 100, 100);
        else if (selectedSkin.getColor().equals(Color.BLUE)) g2d.fillOval(350, 240, 100, 100);
        else if (selectedSkin.getColor().equals(Color.GREEN)) g2d.fillOval(510, 240, 100, 100);

        drawCube(g2d, Color.RED, 200, 250);
        drawCube(g2d, Color.BLUE, 360, 250);
        drawCube(g2d, Color.GREEN, 520, 250);
    }

    private void drawCube(Graphics2D g2d, Color color, int x, int y) {
        g2d.setColor(color);
        g2d.fillRect(x, y, 80, 80);
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(4));
        g2d.drawRect(x, y, 80, 80);
    }
}
