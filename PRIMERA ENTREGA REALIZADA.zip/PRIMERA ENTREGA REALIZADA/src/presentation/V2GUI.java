package presentation;

import javax.swing.*;
import java.awt.*;

import domain.DOPOGame;
import domain.Player;
import domain.HumanPlayer;
import domain.Position;

public class V2GUI extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainContainer;
    private DOPOGame game;
    private GamePanel gamePanel;
    private Timer renderTimer;
    private domain.PlayerSkin selectedSkin;

    public V2GUI() {
        game = new DOPOGame();
        setTitle("The DOPO Hardest Game Martinez-Sanchez");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        cardLayout = new CardLayout();
        mainContainer = new JPanel(cardLayout);

        MainMenuPanel mainMenu = new MainMenuPanel(this);
        mainContainer.add(mainMenu, "MainMenu");

        PlayPanel playPanel = new PlayPanel(this);
        mainContainer.add(playPanel, "Play");

        SettingsPanel settingsPanel = new SettingsPanel(this);
        mainContainer.add(settingsPanel, "Settings");

        SkinSelectionPanel skinPanel = new SkinSelectionPanel(this);
        mainContainer.add(skinPanel, "SkinSelection");

        LevelSelectionPanel levelSelection = new LevelSelectionPanel(this);
        mainContainer.add(levelSelection, "LevelSelection");

        gamePanel = new GamePanel(this, game);
        mainContainer.add(gamePanel, "Game");

        add(mainContainer);
        renderTimer = new Timer(16, e -> {
            if (game.getState() == domain.GameState.PLAYING) {
                game.tick();
                gamePanel.repaint();
            } else if (game.getState() == domain.GameState.VICTORY) {
                renderTimer.stop();
                JOptionPane.showMessageDialog(this, "Victory!");
                game.endGame();
                showPanel("LevelSelection");
            } else if (game.getState() == domain.GameState.GAME_OVER) {
                renderTimer.stop();
                JOptionPane.showMessageDialog(this, "Game Over!");
                showPanel("LevelSelection");
            }
        });
    }

    public void showPanel(String name) {
        cardLayout.show(mainContainer, name);
    }

    public void setSelectedSkin(domain.PlayerSkin skin) {
        this.selectedSkin = skin;
    }

    public void launchGame(String levelConfig) {
        java.util.List<Player> players = new java.util.ArrayList<>();
        players.add(new HumanPlayer(new Position(100, 100), selectedSkin, Color.BLACK, 1));
        
        try {
            game.startGame(levelConfig, "SinglePlayer", players);
            showPanel("Game");
            gamePanel.requestFocusInWindow();
            renderTimer.start();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "¡Ese nivel todavía está en construcción!", "Nivel no disponible", JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new V2GUI().setVisible(true);
        });
    }
}
