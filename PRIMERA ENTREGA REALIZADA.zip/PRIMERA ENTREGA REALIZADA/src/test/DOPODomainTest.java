package test;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import domain.*;
import java.awt.Color;
import java.util.List;


public class DOPODomainTest {
    private Board board;
    private HumanPlayer player;
    private GreenSkin greenSkin;

    @Before
    public void setUp() {
        board = new Board(800, 600);
        greenSkin = new GreenSkin();
        player = new HumanPlayer(new Position(100, 100), greenSkin, Color.BLACK, 1);
    }

    @Test
    public void testCollisionDetection() {
        BasicEnemy enemy = new BasicEnemy(new Position(105, 105), new LinearMovement(true));
        board.addCollidable(enemy);

        List<Collidable> hits = board.checkCollision(player, 20, 20);

        assertFalse("Debería detectarse una colisión", hits.isEmpty());
        assertTrue("El enemigo detectado debería ser el que añadimos", hits.contains(enemy));
    }

    @Test
    public void testNoCollisionWhenFar() {
        BasicEnemy distantEnemy = new BasicEnemy(new Position(400, 400), new LinearMovement(true));
        board.addCollidable(distantEnemy);

        List<Collidable> hits = board.checkCollision(player, 20, 20);

        assertTrue("No debería haber colisión si el enemigo está lejos", hits.isEmpty());
    }

    @Test
    public void testGreenSkinShield() {
        HitResult result = player.receiveHit();

        assertEquals("El GreenSkin debería sobrevivir al primer golpe", HitResult.SURVIVED_SHIELD, result);
        assertEquals("El contador de muertes no debería aumentar con escudo", 0, player.getDeaths());
    }

    @Test
    public void testCoinCollectionProgress() {
        YellowCoin coin = new YellowCoin(new Position(200, 200));
        player.setTotalCoinsRequired(1);

        player.collectCoin(coin);

        assertEquals("El contador de monedas debería haber aumentado", 1, player.getCollectedCoins());
        assertTrue("El jugador debería haber cumplido el requisito del nivel", player.hasCollectedAllCoins());
    }

    @Test
    public void testWallBlockingPath() {
        Wall wall = new Wall(new Position(150, 150), 50, 50);
        board.addCollidable(wall);

        boolean canWalk = board.isWalkable(new Position(160, 160), 20);

        assertFalse("El jugador no debería poder caminar a través de una pared", canWalk);
    }

    @Test
    public void testRedSkinVsGreenSkin() {
        player = new HumanPlayer(new Position(100, 100), new RedSkin(), Color.BLACK, 1);
        assertEquals("RedSkin debe morir instantáneamente", HitResult.DEAD, player.receiveHit());

        player = new HumanPlayer(new Position(100, 100), new GreenSkin(), Color.BLACK, 1);
        assertEquals("GreenSkin debe usar escudo", HitResult.SURVIVED_SHIELD, player.receiveHit());
    }

    @Test
    public void testFinalZoneVictory() {
        FinalZone goal = new FinalZone(new Position(500, 500), 100, 100);
        board.addZone(goal);
        
        player.setPosition(new Position(550, 550));
        player.setTotalCoinsRequired(1); 
        SinglePlayerMode mode = new SinglePlayerMode(List.of(player), board);
        assertFalse("No debería ganar sin recoger las monedas requeridas", mode.checkVictory());

        player.collectCoin(new YellowCoin(new Position(0,0)));
        assertTrue("Debería ganar al estar en la zona final con todas las monedas", mode.checkVictory());
    }

    @Test
    public void testInitialZoneSpawnCalculation() {
        InitialZone start = new InitialZone(new Position(0, 0), 100, 100);
        Position spawn = start.getSpawnPoint();

        assertEquals("El spawn X debe estar centrado en la zona", 40.0, spawn.getX(), 0.01);
        assertEquals("El spawn Y debe estar centrado en la zona", 40.0, spawn.getY(), 0.01);
    }

    @Test
    public void testBoardClearance() {
        board.addVisual(new Wall(new Position(0,0), 10, 10));
        board.addCollidable(new Wall(new Position(0,0), 10, 10));
        
        board.clearAll();

        assertTrue("El tablero debe estar vacío tras clearAll", board.getVisualElements().isEmpty());
        assertTrue("El tablero no debe tener colisionables tras clearAll", board.getCollidables().isEmpty());
    }
}
