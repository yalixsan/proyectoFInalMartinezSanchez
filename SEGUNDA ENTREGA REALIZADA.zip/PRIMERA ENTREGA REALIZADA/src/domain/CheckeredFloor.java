package domain;

/**
 * CLASE NETAMENTE DECORATIVA PARA QUE EL NIVEL SE VEA CON EL PISO DE AJEDREZ
 */
public class CheckeredFloor extends BoardElement {
    /** La dimensión latitudinal que cubrirá la textura sobre el plano */
    private double width;
    
    /** La dimensión longitudinal asignada a la decoración de superficie */
    private double height;

    /**
     * Instancia una placa de suelo pavimentado para el área visual
     * @param position Ubicación ancla (X, Y) desde la cual se expandirá la superficie
     * @param width    El perímetro horizontal a revestir
     * @param height   El margen vertical cubierto
     */
    public CheckeredFloor(Position position, double width, double height) {
        super(position);
        this.width = width;
        this.height = height;
    }

    /** @return Constante de extensión lateral del suelo */
    public double getWidth() { return width; }
    
    /** @return Constante de elevación o profundidad proyectada para este sector gráfico*/
    public double getHeight() { return height; }

    @Override
    public java.util.Map<String, Object> toVisualMap() {
        java.util.Map<String, Object> data = new java.util.HashMap<>();
        if (isActive) {
            data.put("shape", "CHECKER");
            data.put("x", (int)position.getX());
            data.put("y", (int)position.getY());
            data.put("w", (int)width);
            data.put("h", (int)height);
            data.put("r", 255);
            data.put("g", 255);
            data.put("b", 255);
            data.put("br", 0);
            data.put("bg", 0);
            data.put("bb", 0);
        }
        return data;
    }
}
