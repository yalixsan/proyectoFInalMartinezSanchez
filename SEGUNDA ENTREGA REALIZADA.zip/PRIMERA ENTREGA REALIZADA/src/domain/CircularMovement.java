package domain;

/**
 * Implementación de trayectoria elíptica o puramente rotacional.
 * Ancla el movimiento del objeto a un radio concéntrico específico, incrementando el ángulo
 * constantemente para dibujar una órbita perfecta.
 */
public class CircularMovement implements MovementStrategy {
    /** Coordenada matriz sobre el eje de las abscisas alrededor de la cual rota. */
    private double centerX;
    
    /** Coordenada matriz sobre el eje de las ordenadas alrededor de la cual rota. */
    private double centerY;
    
    /** Distancia radial o longitud del vector pivote respecto al centro. */
    private double radius;
    
    /** Rotación inicial y progresiva medida en radianes. */
    private double angle;
    
    /** Tasa de incremento o decaimiento angular por ciclo lógico (tick). */
    private double angularSpeed;

    /**
     * Instancia una órbita cerrada asignando un epicentro.
     * 
     * @param centerX Eje focal X.
     * @param centerY Eje focal Y.
     * @param radius Dimensión escalar desde el foco hasta el ente rotatorio.
     * @param initialAngle Posicionamiento trigonométrico inicial evaluado en grados.
     * @param speed Nivel de rotación o factor multiplicativo de giro.
     */
    public CircularMovement(double centerX, double centerY, double radius, double initialAngle, double speed) {
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.angle = Math.toRadians(initialAngle);
        this.angularSpeed = speed * 0.01; 
    }

    /**
     * Evalúa las funciones trigonométricas en función de la velocidad y reasigna
     * la locación espacial de la entidad.
     * 
     * @param element Actor en movimiento orbital.
     * @param board Entorno (en rotaciones, el board carece de impacto directo salvo restricciones personalizadas).
     */
    @Override
    public void move(MovableElement element, Board board) {
        angle += angularSpeed; 
        double nextX = centerX + radius * Math.cos(angle);
        double nextY = centerY + radius * Math.sin(angle);
        // Corrige el ajuste visual restando el diámetro nominal de compensación
        element.setPosition(new Position(nextX - Enemy.VISUAL_RADIUS, nextY - Enemy.VISUAL_RADIUS));
    }

    /** @return Epicentro orbital en el eje X. */
    public double getCenterX() { return centerX; }
    
    /** @return Epicentro orbital en el eje Y. */
    public double getCenterY() { return centerY; }
    
    /** @return Margen de alejamiento frente al epicentro. */
    public double getRadius() { return radius; }
    
    /** @return Ángulo interno real convertido a formato de 360 grados. */
    public double getAngleDegrees() { return Math.toDegrees(angle); }
    
    /** @return Velocidad base en magnitud estándar pre-atenuación. */
    public double getSpeed() { return angularSpeed / 0.01; }
}
