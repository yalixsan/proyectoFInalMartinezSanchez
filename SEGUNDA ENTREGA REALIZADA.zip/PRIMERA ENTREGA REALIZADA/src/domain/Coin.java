package domain;

/**
 * Clase Moneda 
 */
public abstract class Coin extends CollectableElement {
    /**
     * Inicializa la moneda con sus coordenadas
     * @param position El vector (X, Y) donde residirá el objeto
     */
    public Coin(Position position) {
        super(position);
    }

    /**
     * Detona la secuencia de adquisición
     * @param p    El avatar responsable de la recolección física
     * @param mode El motor arbitral que atiende las lógicas de interacción de la sesión
     */
    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
        if (isActive()) {
            p.collectCoin(this);
        }
    }
}
