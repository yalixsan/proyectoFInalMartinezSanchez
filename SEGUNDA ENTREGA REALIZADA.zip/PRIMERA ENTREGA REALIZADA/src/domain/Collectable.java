package domain;

import java.io.Serializable;

/**
 * Interfaz para los objetos que pueden ser coleccionados por el jugador 
 */
public interface Collectable extends Serializable {
    /**
     * Evalúa si este elemento es requisito indispensable para habilitar el triunfo
     * @return true si el objeto suma al progreso obligatorio; false si es opcional
     */
    boolean countsAsRequiredCoin();
    
    /**
     * Restaura el estado del objeto a su configuración inicial, devolviéndolo al tablero si se trataba de un ítem consumido previamente.
     */
    void resetIfCollectable();
}
