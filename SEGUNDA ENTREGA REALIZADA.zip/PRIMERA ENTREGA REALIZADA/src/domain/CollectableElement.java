package domain;

/**
 * Clase para cualquier elemento del juego que pueda ser recogido por el jugador
 */
public abstract class CollectableElement extends BoardElement implements Collectable, Interactable {

    protected boolean collected;

    public CollectableElement(Position position) {
        super(position);
        this.collected = false;
    }

    public abstract void collect(Player player);

    public void reset() {
        this.collected = false;
        this.isActive = true;
    }

    @Override
    public void resetIfCollectable() {
        reset();
    }

    @Override
    public boolean countsAsRequiredCoin() { return true; }

    @Override
    public Hitbox getHitbox() {
        return new CircularHitbox(
            new Position(position.getX() + 10, position.getY() + 10), 
            10
        );
    }

    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
        if (isActive()) {
            this.collect(p);
        }
    }

    public boolean isCollected() {
        return collected;
    }

    @Override
    public java.util.Map<String, Object> toVisualMap() {
        java.util.Map<String, Object> data = new java.util.HashMap<>();
        if (isActive && !collected) {
            data.put("shape", "OVAL");
            data.put("x", (int)position.getX());
            data.put("y", (int)position.getY());
            data.put("w", 20);
            data.put("h", 20);
            // Amarillo oro para monedas
            data.put("r", 255);
            data.put("g", 215);
            data.put("b", 0);
            // Borde negro
            data.put("br", 0);
            data.put("bg", 0);
            data.put("bb", 0);
        }
        return data;
    }
}
