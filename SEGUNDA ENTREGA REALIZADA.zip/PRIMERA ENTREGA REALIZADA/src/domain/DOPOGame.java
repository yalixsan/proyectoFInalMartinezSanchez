package domain;

import java.util.List;
import java.io.Serializable;

/**
 * Clase principal que administra el flujo del juego
 * Se encarga de gestionar el nivel actual, el estado de la partida, el control del tiempo y coordinar los datos visuales que se envían a la interfaz
 */
public class DOPOGame implements Serializable {
    /** 
     * El tablero que contiene la disposición física de los muros, enemigos y jugadores
     */
    private Board board;
    
    /** Define la fase en la que se encuentra el juego (por ejemplo, en pausa, en curso o finalizado). */
    private GameState state;
    
    /**
     * Administra las reglas de la partida activa y el comportamiento de los jugadores
     */
    private GameMode gameMode;
    
    /**
     * Temporizador encargado de medir el tiempo restante para superar el nivel
     */
    private GameTimer timer;

    /**
     * Catálogo con las Skins disponibles para los jugadores
     */
    private final PlayerSkin[] availableSkins = { 
        new RedSkin(), 
        new BlueSkin(), 
        new GreenSkin() 
    };

    /**
     * Nombre del archivo de configuración del nivel en curso
     */
    private String currentLevelName = "level1";

    /**
     * Constructor por defecto. Inicializa la sesión en un estado de espera, listo para configurar una partida
     */
    public DOPOGame() {
        this.state = new ReadyState();
    }

    /**
     * Proceso que se realiza para la inicialización de una partida
     * @param configPath Nombre del nivel a cargar (ej. "level1")
     * @param players Lista con los jugadores configurados que jugarán
     * @param remainingTime Tiempo restante en milisegundos para usar el tiempo original del mapa.
     * @param loadBoardFromDisk Indica si el tablero debe leerse desde un archivo físico o si ya se encuentra cargado en memoria
     * @throws DopoException Si ocurre algún fallo al leer el archivo o al procesar la configuración
     */
    private void initGameSession(String configPath, List<Player> players, int remainingTime, boolean loadBoardFromDisk) throws DopoException {
        try {
            this.state = new PlayingState();
            this.currentLevelName = configPath;
            
            if (loadBoardFromDisk) {
                LevelLoader loader = new LevelLoader();
                this.board = loader.loadLevel(configPath);
            } else if (this.board == null) {
                throw new DopoException("No hay un tablero cargado para restaurar la partida");
            }
            int timeLimit = (remainingTime > 0) ? remainingTime : this.board.getTimeLimit();
            this.timer = new GameTimer(timeLimit);
            this.gameMode = new GameMode(players, this.board);
            this.gameMode.initGame();
        } catch (DopoException e) {
            Log.record(e);
            throw e;
        }
    }

    /**
     * Proceso auxiliar que crea los jugadores seleccionador por los usuarios
     * @param mode Define la modalidad de juego ("Player", "Player vs Player")
     * @param skinIndex1 Índice de la skin seleccionada para el Jugador 1.
     * @param borderR1 Valor del componente rojo para el borde del Jugador 1.
     * @param borderG1 Valor del componente verde para el borde del Jugador 1.
     * @param borderB1 Valor del componente azul para el borde del Jugador 1.
     * @param skinIndex2 Índice de la skin seleccionada para el Jugador 2.
     * @param borderR2 Valor del componente rojo para el borde del Jugador 2.
     * @param borderG2 Valor del componente verde para el borde del Jugador 2.
     * @param borderB2 Valor del componente azul para el borde del Jugador 2.
     * @return Una lista con las instancias de los jugadores correctamente inicializadas.
     */
    private List<Player> buildPlayers(String mode, int skinIndex1, int borderR1, int borderG1, int borderB1, 
                                       int skinIndex2, int borderR2, int borderG2, int borderB2) {
        PlayerSkin s1 = availableSkins[skinIndex1];
        ElementColor c1 = new ElementColor(borderR1, borderG1, borderB1);
        PlayerSkin s2 = availableSkins[skinIndex2];
        ElementColor c2 = new ElementColor(borderR2, borderG2, borderB2);
        return PlayerFactory.createPlayers(mode, s1, c1, s2, c2, availableSkins);
    }

    /**
     * Inicia una nueva partida cargando los recursos del nivel
     * @param configPath Nombre del nivel a cargar (ej. "level1")
     * @param mode Modalidad seleccionada ("Player" o "Player vs Player")
     * @param skinIndex1 Índice de skin del jugador 1.
     * @param borderR1 Componente rojo del borde del jugador 1
     * @param borderG1 Componente verde del borde del jugador 1
     * @param borderB1 Componente azul del borde del jugador 1
     * @param skinIndex2 Índice de skin del jugador 2
     * @param borderR2 Componente rojo del borde del jugador 2
     * @param borderG2 Componente verde del borde del jugador 2
     * @param borderB2 Componente azul del borde del jugador 2
     * @throws DopoException Si el archivo de nivel no se encuentra o contiene errores de formato
     */
    public void startGame(String configPath, String mode, 
                          int skinIndex1, int borderR1, int borderG1, int borderB1, 
                          int skinIndex2, int borderR2, int borderG2, int borderB2) throws DopoException {
        List<Player> players = buildPlayers(mode, skinIndex1, borderR1, borderG1, borderB1, skinIndex2, borderR2, borderG2, borderB2);
        initGameSession(configPath, players, -1, true);
    }

    /**
     * Obtiene el nombre del nivel actualmente en ejecución
     * @return El identificador o nombre del archivo de nivel
     */
    public String getCurrentLevelName() { 
        return currentLevelName; 
    }

    /** 
     * Pausa el juego, deteniendo a los jugadores, moviemiento y tiempos
     */
    public void pauseGame() {
        if (state.isPlaying()) state = new PausedState();
    }

    /**
     * Reanuda el progreso del juego tras una pausa previa
     */
    public void resumeGame() {
        if (state.isPaused()) state = new PlayingState();
    }

    /**
     * Alterna dinámicamente entre el estado de juego activo y pausado
     */
    public void togglePause() {
        this.state = this.state.togglePause();
    }

    /**
     * Finaliza la partida de forma inmediata y cambia el estado general a Game Over
     */
    public void endGame() {
        this.state = new GameOverState();
    }

    /**
     * Recibe el movimiento generado por las teclas y lo transfiere al jugador correspondiente 
     * @param playerId Identificador del jugador
     * @param direction Dirección hacia la que el jugador desea desplazarse
     */
    public void movePlayer(int playerId, Direction direction) {
        this.state = this.state.movePlayer(this.gameMode, playerId, direction);
    }

    /**
     * Avanza un ciclo de actualización (tick) en la lógica del juego
     * Permite evaluar movimientos, actualizar contadores y verificar colisiones
     */
    public void tick() {
        this.state = this.state.tick(this.gameMode, this.timer);
    }

    /**
     * Extrae y formatea las propiedades de los elementos del tablero (muros, zonas, enemigos) para facilitar su renderizado en la interfaz
     * @return Una lista de diccionarios con las coordenadas, dimensiones y colores de los objetos visuales
     */
    public java.util.List<java.util.Map<String, Object>> getObjectsData() {
        java.util.List<java.util.Map<String, Object>> list = new java.util.ArrayList<>();
        if (board != null) {
            for (BoardElement e : board.getVisualElements()) {
                java.util.Map<String, Object> map = e.toVisualMap();
                if (map != null && !map.isEmpty()) {
                    list.add(map);
                }
            }
        }
        return list;
    }

    /**
     * Extrae y formatea exclusivamente las propiedades de los jugadores para tener su representación visual
     * @return Una lista de diccionarios con el estado y datos gráficos de cada jugador
     */
    public java.util.List<java.util.Map<String, Object>> getPlayersData() {
        java.util.List<java.util.Map<String, Object>> list = new java.util.ArrayList<>();
        if (gameMode != null) {
            for (Player p : gameMode.getPlayers()) {
                java.util.Map<String, Object> map = p.toVisualMap();
                if (map != null && !map.isEmpty()) {
                    list.add(map);
                }
            }
        }
        return list;
    }

    /**
     * Consulta la cantidad total de veces que un jugador ha muerto
     * @param playerIdx Identificador del jugador
     * @return El número acumulado de muertes
     */
    public int getPlayerDeaths(int playerIdx) {
        if (gameMode != null && gameMode.getPlayers().size() > playerIdx) {
            return gameMode.getPlayers().get(playerIdx).getDeaths();
        }
        return 0;
    }

    /**
     * Consulta la cantidad de monedas recolectadas por un jugador hasta ese momento
     * @param playerIdx Identificador del jugador
     * @return Cantidad actual de monedas en su inventario
     */
    public int getPlayerCollectedCoins(int playerIdx) {
        if (gameMode != null && gameMode.getPlayers().size() > playerIdx) {
            return gameMode.getPlayers().get(playerIdx).getCollectedCoins();
        }
        return 0;
    }

    /**
     * Consulta el número total de monedas que el jugador requiere recolectar para habilitar la victoria del nivel
     * @param playerIdx Identificador del jugador
     * @return Número de monedas meta
     */
    public int getPlayerTotalCoinsRequired(int playerIdx) {
        if (gameMode != null && gameMode.getPlayers().size() > playerIdx) {
            return gameMode.getPlayers().get(playerIdx).getTotalCoinsRequired();
        }
        return 0;
    }

    /**
     * Define la dirección de desplazamiento de un jugador
     * @param playerIdx Identificador del jugador
     * @param dx Componente direccional horizontal (1 para derecha, -1 para izquierda, 0 sin movimiento)
     * @param dy Componente direccional vertical (1 para abajo, -1 para arriba, 0 sin movimiento)
     */
    public void setPlayerDirection(int playerIdx, int dx, int dy) {
        if (gameMode != null && gameMode.getPlayers().size() > playerIdx) {
            gameMode.getPlayers().get(playerIdx).setCurrentDirection(Direction.fromVector(dx, dy));
        }
    }

    /**
     * Retorna el arreglo base de las apariencias o skins registradas que los jugadores pueden utilizar
     * @return Arreglo de instancias de PlayerSkin
     */
    public PlayerSkin[] getAvailableSkins() {
        return availableSkins;
    }

    /**
     * Consulta el tiempo disponible antes de que la partida termine por tiempo agotado
     * @return Los milisegundos restantes
     */
    public int getTimeRemaining() {
        return (timer != null) ? timer.getRemainingTime() : 0;
    }

    /** 
     * Consulta si la partida se encuentra activa
     * @return true si la partida se encuentra activa y en curso
     */
    public boolean isPlaying() { return state.isPlaying(); }
    
    /** 
     * Consulta si la partida está pausada
     * @return true si la partida ha sido detenida temporalmente
     */
    public boolean isPaused() { return state.isPaused(); }
    
    /** 
     * Consulta si la partida ya se acabó 
     * @return true si la partida culminó en derrota
     */
    public boolean isGameOver() { return state.isGameOver(); }
    
    /**
     * Consulta si se ha ganado la partida
     * @return true si los jugadores cumplieron los objetivos y ganaron la partida
     */
    public boolean isVictory() { return state.isVictory(); }
    
    /**
     * Consulta si ya se está lsto para un nuevo juego
     * @return true si el sistema está a la espera de configurar un nuevo juego
     */
    public boolean isReady() { return state.isReady(); }

    /**
     * Obtiene el tablero
     * @return La instancia del tablero que gestiona los elementos físicos
     */
    public Board getBoard() { 
        return board; 
    }

    /**
     * Reemplaza el tablero actual por uno nuevo (utilizado principalmente al restaurar partidas)
     * @param board La nueva instancia del tablero
     */
    public void setBoard(Board board) { 
        this.board = board; 
    }

    /**
     * Escribe el estado actual de la partida en un archivo
     * @param file Archivo destino de la computadora donde se almacenará el progreso
     * @throws DopoException Si el archivo no tiene permisos de escritura o el disco genera error
     */
    public void save(java.io.File file) throws DopoException {
        try {
            DOPOPersistence.save(file, this);
        } catch (DopoException e) {
            Log.record(e);
            throw e;
        }
    }

    /**
     * Lee un archivo previamente guardado y reconstruye la partida
     * @param file Archivo que contiene la información serializada
     * @return Una instancia de DOPOGame con todo su estado restaurado correctamente
     * @throws DopoException Si el formato del archivo es inválido o se corrompió
     */
    public static DOPOGame open(java.io.File file) throws DopoException {
        try {
            return DOPOPersistence.open(file);
        } catch (DopoException e) {
            Log.record(e);
            throw e;
        }
    }

    /**
     * Inicia una partida cargando la distribución de un nivel directamente desde un archivo local
     * @param file Archivo de texto que estructura el nivel a cargar
     * @param mode Modalidad ("Player" o "Player vs Player")
     * @param skinIndex1 Índice de skin del jugador 1
     * @param borderR1 Componente rojo del jugador 1
     * @param borderG1 Componente verde del jugador 1
     * @param borderB1 Componente azul del jugador 1
     * @param skinIndex2 Índice de skin del jugador 2
     * @param borderR2 Componente rojo del jugador 2
     * @param borderG2 Componente verde del jugador 2
     * @param borderB2 Componente azul del jugador 2
     * @throws DopoException Si el archivo es ilegible o contiene errores de sintaxis en su diseño
     */
    public void loadLevelAndRestore(java.io.File file, String mode,
                                    int skinIndex1, int borderR1, int borderG1, int borderB1,
                                    int skinIndex2, int borderR2, int borderG2, int borderB2) throws DopoException {
        try {
            LevelLoader loader = new LevelLoader();
            this.board = loader.loadLevel(file);
            List<Player> players = buildPlayers(mode, skinIndex1, borderR1, borderG1, borderB1, skinIndex2, borderR2, borderG2, borderB2);
            initGameSession(file.getName().replace(".txt", ""), players, -1, false);
        } catch (DopoException e) {
            Log.record(e);
            throw e;
        }
    }

    /** 
     * Retorna el estado del juego
     * @return El objeto que representa la etapa del ciclo de vida en la que está la partida
     * */
    public GameState getState() { return state; }
    
    
    /**
     * Retorna el modo de juego actual
     * @return El componente responsable de las reglas y del control sobre los jugadores
     * */
    public GameMode getGameMode() { return gameMode; }
    
    /**
     * Retorna el temporizador
     * @return El temporizador encargado del tiempo restante
     * */
    public GameTimer getTimer() { return timer; }
}
