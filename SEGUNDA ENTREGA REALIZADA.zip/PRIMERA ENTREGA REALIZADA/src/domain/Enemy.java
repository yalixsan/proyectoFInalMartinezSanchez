package domain;

/**
 * Representa a una entidad hostil dentro del juego.
 * Gestiona de forma automatizada su propio movimiento a través de un patrón Strategy y delega las penalizaciones por colisión hacia los jugadores
 */
public class Enemy extends MovableElement implements Interactable, Tickable {
    /** Estrategia de movimiento inyectada que define la trayectoria del enemigo */
    protected MovementStrategy movementStrategy;
    
    /** Radio estándar para su representación visual y cálculo de área gráfica */
    public static final double VISUAL_RADIUS = 10.0;
    
    /** Diámetro completo de la representación gráfica del enemigo */
    public static final double VISUAL_SIZE = VISUAL_RADIUS * 2;

    /**
     * Construye un nuevo enemigo con una posición, velocidad y patrón de movimiento predefinidos
     * @param position Coordenada espacial de aparición en el tablero
     * @param speed Magnitud del desplazamiento por ciclo
     * @param movementStrategy Algoritmo que dictará la trayectoria 
     */
    public Enemy(Position position, double speed, MovementStrategy movementStrategy) {
        super(position, speed);
        this.movementStrategy = movementStrategy;
    }

    /**
     * Ejecuta el desplazamiento delegando la lógica matemática a su estrategia configurada
     * @param board Entorno físico donde ocurre el movimiento y las colisiones
     */
    @Override
    public void move(Board board) {
        movementStrategy.move(this, board);
    }

    /**
     * Modifica dinámicamente el patrón de movimiento de la entidad
     * @param movementStrategy Nueva estrategia directriz a emplear
     */
    public void setMovementStrategy(MovementStrategy movementStrategy) {
        this.movementStrategy = movementStrategy;
    }

    /**
     * Retorna la estrategia de movimiento en uso
     * @return Instancia del comportamiento de movimiento actual
     */
    public MovementStrategy getMovementStrategy() {
        return movementStrategy;
    }

    /**
     * Actualiza el estado del enemigo por cada fotograma lógico del sistema
     * @param board Tablero físico de interacción
     */
    @Override
    public void tick(Board board) {
        move(board);
    }

    /**
     * Genera un volumen delimitador de forma circular para los cálculos de impacto
     * @return Una Hitbox circular dimensionada a partir de las coordenadas del enemigo
     */
    @Override
    public Hitbox getHitbox() {
        return new CircularHitbox(
            new Position(position.getX() + VISUAL_RADIUS, position.getY() + VISUAL_RADIUS), VISUAL_RADIUS);
    }

    /**
     * Delega la resolución del evento de colisión al controlador general del modo de juego
     * @param p El jugador que ha entrado en contacto físico
     * @param mode El modo de juego activo que gestionará las consecuencias del impacto
     */
    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
        mode.handlePlayerEnemyCollision(p, this);
    }

    /**
     * Extrae las propiedades estructurales y estéticas para ser renderizadas gráficamente
     * @return Un diccionario conteniendo el tipo de forma geométrica, coordenadas, tamaño y colores base
     */
    @Override
    public java.util.Map<String, Object> toVisualMap() {
        java.util.Map<String, Object> data = new java.util.HashMap<>();
        if (isActive) {
            data.put("shape", "OVAL");
            data.put("x", (int)position.getX());
            data.put("y", (int)position.getY());
            data.put("w", (int)VISUAL_SIZE);
            data.put("h", (int)VISUAL_SIZE);
            data.put("r", 50);
            data.put("g", 90);
            data.put("b", 230);
            data.put("br", 0);
            data.put("bg", 0);
            data.put("bb", 0);
        }
        return data;
    }
}
