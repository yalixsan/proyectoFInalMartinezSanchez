package domain;

/**
 * Zona final del nivel/partida
 */
public class FinalZone extends Zone implements VictoryZone {
    /**
     * Define y setea la estructura de victoria en el escenario lógico
     * @param position Coordenada geográfica para la esquina superior izquierda
     * @param width    Medida horizontal de la meta
     * @param height   Medida vertical del área resolutoria
     */
    public FinalZone(Position position, double width, double height) {
        super(position, width, height);
    }

    /**
     * Somete a comprobación la posición actual del jugador para dictaminar si este ha invadido satisfactoriamente la demarcación de la meta
     * @param pos La coordenada actual que está pisando el usuario
     * @return true si dicha posición vulnera o coincide con el interior de esta zona
     */
    @Override
    public boolean isFinalZoneFor(Position pos) {
        return contains(pos);
    }
}
