package domain;

import java.util.List;
import java.io.Serializable;

/**
 * Administra las reglas de progreso y las condiciones de victoria de una partida en curso
 * Gestiona las interacciones entre los jugadores y su impacto con los elementos del tablero
 */
public class GameMode implements Serializable {
    protected List<Player> players;
    
    protected Board board;

    /**
     * Construye y enlaza un nuevo modo de juego
     * @param players Los jugadores inicializados para la partida
     * @param board El tablero poblado con sus respectivos obstáculos y zonas
     */
    public GameMode(List<Player> players, Board board) {
        this.players = players;
        this.board = board;
    }

    /**
     * Configura el punto de partida de los jugadores
     */
    public void initGame() {
        if (players.isEmpty() || board.getSpawnZones().isEmpty()) return;
        
        InitialZone spawnZone = (InitialZone) board.getSpawnZones().get(0);
        int totalCoins = countCoins();

        for (int i = 0; i < players.size(); i++) {
            Player p = players.get(i);
            Position pSpawn = spawnZone.getSpawnPoint(i, p, players.size());
            p.setSpawnPoint(pSpawn);
            p.setPosition(pSpawn);
            p.setTotalCoinsRequired(totalCoins);
        }
    }

    /**
     * Analiza el tablero para contabilizar cuántos elementos cuentan como condición para la victoria
     * @return El número de monedas requeridos
     */
    protected int countCoins() {
        int count = 0;
        for (Collectable c : board.getCollectables()) {
            if (c.countsAsRequiredCoin()) count++;
        }
        return count;
    }

    /**
     * Actualiza la posición y el estado de los jugadores en cada iteración del sistema
     */
    public void tick() {
        for (Player p : players) {
            p.decreaseInvulnerability();
            double size = Player.BASE_SIZE * p.getCurrentSkin().getSize();
            Position nextPos = p.calculateNextPosition();
            if (board.isWalkable(nextPos, size)) { 
                p.setPosition(nextPos);
            }
            List<Interactable> collisions = board.checkCollision(p, size, size);
            for (Interactable i : collisions) {
                i.collideWithPlayer(p, this);
            }
        }
        
        if (players.size() > 1) {
            Player p1 = players.get(0);
            Player p2 = players.get(1);
            double size1 = Player.BASE_SIZE * p1.getCurrentSkin().getSize();
            double size2 = Player.BASE_SIZE * p2.getCurrentSkin().getSize();
            
            if (p1.getHitbox().collidesWith(p2.getPosition(), size2, size2)) {
                handlePlayerPlayerCollision(p1, p2);
            }
        }
        
        for (Tickable t : board.getTickables()) {
            t.tick(board);
        }
    }

    /**
     * Comprueba si los requisitos establecidos para culminar exitosamente el nivel han sido alcanzados
     * @return true si los jugadores cumplieron los criterios de victoria, false en caso contrario
     */
    public boolean checkVictory() {
        int totalCollected = 0;
        for (Player p : players) {
            totalCollected += p.getCollectedCoins();
        }
        
        int required = 0;
        if (!players.isEmpty()) {
            required = players.get(0).getTotalCoinsRequired();
        }

        // Se considera victoria cuando se agarran todas las monedas :D
        if (totalCollected == required) {
            for (Player p : players) {
                for (VictoryZone v : board.getVictoryZones()) {
                    if (v.isFinalZoneFor(p.getPosition())) {
                        return true; 
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Procesa la colisión entre un jugador y un enemigo
     * @param player El jugador afectado por el daño
     * @param enemy El obstáculo dinámico que provocó la interrupción
     */
    public void handlePlayerEnemyCollision(Player player, Enemy enemy) {
        HitResult result = player.receiveHit();
        if (result == HitResult.DEAD) {
            player.resetCoins();
        }
    }

    /**
     * Resuelve el impacto directo entre entidades aliadas dentro del tablero
     * Dicha infracción ocasiona la penalización máxima y el reinicio simultáneo de ambos componentes
     * 
     * @param player1 La primera entidad involucrada.
     * @param player2 La segunda entidad involucrada.
     */
    public void handlePlayerPlayerCollision(Player player1, Player player2) {
        player1.die(); 
        player2.die(); 
        
        for (Player p : players) {
            p.resetCoins();
        }
        
        for (Collectable c : board.getCollectables()) {
            c.resetIfCollectable();
        }
    }

    /**
     * Verifica si ya se acabó el juego
     * @return Siempre retorna false bajo las reglas actuales de límite de tiempo
     */
    public boolean isGameOver() {
        return false; 
    }

    /** @return La lista de jugadores que están en este modo de juego */
    public List<Player> getPlayers() { return players; }
    
    /** @return El tablero subyacente que opera para esta modalidad */
    public Board getBoard() { return board; }
}
