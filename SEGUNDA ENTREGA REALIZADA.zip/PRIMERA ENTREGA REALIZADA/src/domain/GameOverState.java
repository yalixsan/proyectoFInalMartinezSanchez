package domain;

/**
 * Fase terminal negativa ("Fin de Partida").
 * Sella el tablero inhabilitando progresos e interacciones, consumando la penalización por muerte
 * o por límite temporal vencido.
 */
public class GameOverState implements GameState {
    /** Deniega el tiempo e interrumpe cualquier cálculo cinemático. */
    @Override public GameState tick(GameMode mode, GameTimer timer) { return this; }
    
    /** Intercepta solicitudes y obstruye las acciones del control. */
    @Override public GameState movePlayer(GameMode mode, int playerId, Direction dir) { return this; }
    
    /** Suprime la facultad de aplicar pausas al ya tratarse de una culminación estricta. */
    @Override public GameState togglePause() { return this; }
    
    @Override public boolean isGameOver() { return true; }
}
