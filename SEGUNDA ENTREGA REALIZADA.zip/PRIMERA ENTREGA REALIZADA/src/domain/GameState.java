package domain;

import java.io.Serializable;

/**
 * Arquitectura central del modelo State para gobernar el flujo de la partida.
 * Abstrae e independiza las reglas operativas según si el jugador está jugando activamente,
 * ha pausado, ha triunfado o ha perdido.
 */
public interface GameState extends Serializable {
    /**
     * Modera el avance temporal de los recursos del juego.
     * @param mode Gestor supremo de las rutinas de la partida.
     * @param timer Motor cronológico encargado de dictaminar la expiración.
     * @return El estado subsecuente derivado tras la validación de este ciclo.
     */
    GameState tick(GameMode mode, GameTimer timer);
    
    /**
     * Intenta delegar un impulso o directiva desde el controlador humano.
     * @param mode Gestor de la partida.
     * @param playerId Índice de identificación del usuario local o remoto.
     * @param dir Orientación cardinal exigida.
     * @return El estado vigente tras el intento de movimiento.
     */
    GameState movePlayer(GameMode mode, int playerId, Direction dir);
    
    /**
     * Interrumpe o retoma el avance asíncrono inter-estados.
     * @return La permutación resultante a Pausa o Juego Activo.
     */
    GameState togglePause();
    
    /** @return Verifica y afirma la presencia de una sesión activa (por defecto, false). */
    default boolean isPlaying() { return false; }
    
    /** @return Verifica y afirma la presencia de una suspensión de procesos (por defecto, false). */
    default boolean isPaused() { return false; }
    
    /** @return Afirma que los requisitos de derrota se han concretado (por defecto, false). */
    default boolean isGameOver() { return false; }
    
    /** @return Certifica el cierre victorioso sobre el entorno evaluado (por defecto, false). */
    default boolean isVictory() { return false; }
    
    /** @return Confirma si el modo está configurado y a la espera para empezar (por defecto, false). */
    default boolean isReady() { return false; }
}
