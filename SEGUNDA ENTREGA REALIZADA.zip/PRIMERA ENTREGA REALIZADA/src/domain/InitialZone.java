package domain;

/**
 * Zona inicial del nivel (Donde spawnean los jugadores) 
 */
public class InitialZone extends Zone implements Spawnable {
    /**
     * Construye y establece la región inicial en el tablero lógico
     * @param position Coordenada designando el extremo superior izquierdo de la zona
     * @param width    El ancho oficial de la superficie de inicio
     * @param height   El alto oficial de la superficie de inicio
     */
    public InitialZone(Position position, double width, double height) {
        super(position, width, height);
    }

    /**
     * Determina con el uso de matematica la mitad de la zona para que ahí spawnee el jugador 
     * 
     * @return La coordenada calculada y alineada al núcleo del área.
     */
    @Override
    public Position getSpawnPoint() {
        double halfPlayer = domain.Player.BASE_SIZE / 2.0;
        double centerX = getPosition().getX() + (getWidth() / 2) - halfPlayer;
        double centerY = getPosition().getY() + (getHeight() / 2) - halfPlayer;
        return new Position(centerX, centerY);
    }

    /**
     * Calcula dinámicamente un punto de instanciación asumiendo modalidad multijugador base
     * @param i Índice numérico que identifica al avatar
     * @param p Instancia de la entidad jugador que requiere la ubicación
     * @return La coordenada de resurgimiento ajustada para no colisionar con otros avatares
     */
    public Position getSpawnPoint(int i, Player p) {
        return getSpawnPoint(i, p, 2); 
    }

    /**
     * Determina con el uso de matematica la mitad de la zona para que ahí spawnee el jugador  (en este caso 2 Players)
     * @param i Índice del participante dentro de la sesión.
     * @param p El jugador a ubicar.
     * @param totalPlayers La suma de todos los usuarios confirmados en la sala
     * @return Una Posición equitativamente distanciada del centro
     */
    public Position getSpawnPoint(int i, Player p, int totalPlayers) {
        Position base = getSpawnPoint();
        if (totalPlayers <= 1) {
            return base; 
        }
        double playerSize = Player.BASE_SIZE * p.getCurrentSkin().getSize();
        double gap = 15.0; // Para dejar a un jugador lejitos del otro
        double offset = (playerSize / 2.0) + (gap / 2.0);
        
        if (i == 0) {
            return new Position(base.getX() - offset, base.getY());
        } else {
            return new Position(base.getX() + offset, base.getY());
        }
    }
}
