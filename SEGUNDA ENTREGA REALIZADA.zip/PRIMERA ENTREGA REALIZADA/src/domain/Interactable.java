package domain;

import java.io.Serializable;

/**
 * Define la capacidad de un elemento para reaccionar físicamente ante el contacto.
 * Todo objeto que implemente esta interfaz expone su volumen y sus consecuencias
 * al colisionar con los avatares controlados.
 */
public interface Interactable extends Serializable {
    /**
     * Consulta el vector posicional del ente interactuable.
     * @return Coordenada actual sobre la que se emplaza el objeto.
     */
    Position getPosition();
    
    /**
     * Construye y provee el volumen de intersección del objeto.
     * @return La Hitbox o caja de colisiones asignada.
     */
    Hitbox getHitbox();
    
    /**
     * Ejecuta la lógica o penalización correspondiente al momento en que un usuario
     * impacta contra este elemento.
     * @param p El avatar involucrado en la colisión.
     * @param mode El orquestador de reglas del nivel activo.
     */
    void collideWithPlayer(Player p, GameMode mode);
}
