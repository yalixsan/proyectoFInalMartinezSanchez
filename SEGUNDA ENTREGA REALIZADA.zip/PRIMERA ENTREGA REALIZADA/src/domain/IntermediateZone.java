package domain;

/**
 * Zona de "CheckPoints" para el juego
 */
public class IntermediateZone extends InitialZone implements Interactable {
    
    /**
     * Inicializa un área de control intermedia para el guardado de progreso espacial
     * 
     * @param position Vértice originario de este cuadrante
     * @param width    Largo total en proyección X
     * @param height   Largo total en proyección Y
     */
    public IntermediateZone(Position position, double width, double height) {
        super(position, width, height);
    }

    /**
     * Reacciona ante una colisión inminente obligando al avatar a adoptar las métricas de esta zona como su nueva matriz de origen
     * 
     * @param p Entidad manipulada por el usuario que detonó el evento interactivo
     * @param mode El modo operativo del juego que expone los recursos y lista de participantes
     */
    @Override
    public void collideWithPlayer(Player p, GameMode mode) {
        int idx = mode.getPlayers().indexOf(p);
        if (idx >= 0) {
            p.setSpawnPoint(getSpawnPoint(idx, p, mode.getPlayers().size()));
        } else {
            p.setSpawnPoint(getSpawnPoint());
        }
    }

    /**
     * Sobreescribe y provee la coordenada exacta de respawn basada en el núcleo de esta zona intermedia
     * @return Coordenada corregida ajustada al tamaño estándar del avatar
     */
    public Position getSpawnPoint() {
        return new Position(
            position.getX() + (width / 2) - (Player.BASE_SIZE / 2),
            position.getY() + (height / 2) - (Player.BASE_SIZE / 2)
        );
    }
}
