package domain;

import java.util.*;
import java.nio.file.*;
import java.io.IOException;

/**
 * Analizador y adaptador estructurado encargado de leer las configuraciones en texto plano de los niveles
 */
public class LevelLoader {
    
    /** Registro interno que mapea instrucciones de texto hacia acciones específicas de ensamblado en el nivel */
    private final Map<String, LevelAction> commandRegistry = new HashMap<>();

    /** Interfaz funcional que define el contrato de ejecución para procesar cada comando leído. */
    @FunctionalInterface
    private interface LevelAction {
        void execute(String[] parts, Board board) throws Exception;
    }

    /**
     * Construye y preconfigura el cargador, enlazando la sintaxis de palabras clave (TIME, FLOOR, WALL, ZONE, COIN, ENEMY) con sus respectivos métodos de generación.
     */
    public LevelLoader() {
        commandRegistry.put("TIME", (parts, board) -> board.setTimeLimit(Integer.parseInt(parts[1])));
        commandRegistry.put("FLOOR", this::parseFloor);
        commandRegistry.put("WALL", this::parseWall);
        commandRegistry.put("ZONE", this::parseZone);
        commandRegistry.put("COIN", this::parseCoin);
        commandRegistry.put("ENEMY", this::parseEnemy);
    }

    /**
     * Interpola y decodifica un documento de nivel físico del sistema de archivos, procesando secuencialmente cada línea para crearla en el nuevo tablero
     * 
     * @param file Archivo textual estandarizado que aloja las directrices de diseño
     * @return El Board maestro generado y completamente poblado de componentes
     * @throws DopoException Si el documento resulta inaccesible o experimenta problemas de lectura
     */
    public Board loadLevel(java.io.File file) throws DopoException {
        List<String> lines;
        try {
            lines = Files.readAllLines(file.toPath(), java.nio.charset.StandardCharsets.ISO_8859_1);
        } catch (IOException e) {
            throw new DopoException(DopoException.LEVEL_NOT_FOUND + ": " + file.getName(), e);
        }
        return parseLevelLines(lines);
    }

    /**
     * Extrae y compila las configuraciones del nivel utilizando únicamente el nombre del archivo
     * Genera automáticamente una ruta predeterminada ubicada dentro de levels
     * @param levelConfig Identificador del archivo nivel
     * @return El tablero final procesado a partir de sus directrices internas
     * @throws DopoException Si la configuración textual es ilegible o contiene rutas inválidas
     */
    public Board loadLevel(String levelConfig) throws DopoException {
        String filePath = "levels/" + levelConfig + ".txt";
        List<String> lines;
        try {
            lines = Files.readAllLines(Paths.get(filePath), java.nio.charset.StandardCharsets.ISO_8859_1);
        } catch (IOException e) {
            throw new DopoException(DopoException.LEVEL_NOT_FOUND + ": " + levelConfig, e);
        }
        return parseLevelLines(lines);
    }

    /**
     * Procesa las lineas del archivo txt, delegando cada comando para configurar instancias en el board
     * 
     * @param lines Colección textual de instrucciones extraídas del archivo
     * @return El tablero completamente validado
     * @throws DopoException En caso de presentarse faltas ortográficas en los comandos o violaciones de estructura
     */
    private Board parseLevelLines(List<String> lines) throws DopoException {
        Board board = new Board(800, 600);
        board.clearAll();
        
        int lineNumber = 0;
        for (String line : lines) {
            lineNumber++;
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;

            String[] parts = line.split("\\s+");
            String command = parts[0].toUpperCase();

            try {
                LevelAction action = commandRegistry.get(command);
                if (action == null) {
                    throw new IllegalArgumentException(DopoException.UNKNOWN_COMMAND + command);
                }
                action.execute(parts, board);
            } catch (ArrayIndexOutOfBoundsException e) {
                throw new DopoException(DopoException.formatLevelError(lineNumber, command, "Faltan parámetros"), e);
            } catch (Exception e) {
                throw new DopoException(DopoException.formatLevelError(lineNumber, command, e.getMessage()), e);
            }
        }

        if (board.getSpawnZones().isEmpty()) {
            throw new DopoException(DopoException.MISSING_INITIAL_ZONE);
        }
        if (board.getVictoryZones().isEmpty()) {
            throw new DopoException(DopoException.MISSING_FINAL_ZONE);
        }

        return board;
    }

    private void parseFloor(String[] parts, Board board) {
        if (parts.length < 6) throw new IllegalArgumentException("Faltan parámetros para FLOOR.");
        double x = Double.parseDouble(parts[2]);
        double y = Double.parseDouble(parts[3]);
        double w = Double.parseDouble(parts[4]);
        double h = Double.parseDouble(parts[5]);
        if (w <= 0 || h <= 0) throw new IllegalArgumentException(DopoException.INVALID_DIMENSION);
        board.addVisual(new CheckeredFloor(new Position(x, y), w, h));
    }

    private void parseWall(String[] parts, Board board) {
        if (parts.length < 6) throw new IllegalArgumentException("Faltan parámetros para WALL.");
        double x = Double.parseDouble(parts[1]);
        double y = Double.parseDouble(parts[2]);
        double w = Double.parseDouble(parts[3]);
        double h = Double.parseDouble(parts[4]);
        boolean visible = Boolean.parseBoolean(parts[5]);
        if (w <= 0 || h <= 0) throw new IllegalArgumentException(DopoException.INVALID_DIMENSION);
        Wall wall = new Wall(new Position(x, y), w, h);
        wall.setVisible(visible);
        board.addVisual(wall);
        board.addSolid(wall); 
    }

    private void parseZone(String[] parts, Board board) {
        if (parts.length < 6) throw new IllegalArgumentException("Faltan parámetros para ZONE.");
        String type = parts[1].toUpperCase();
        double x = Double.parseDouble(parts[2]);
        double y = Double.parseDouble(parts[3]);
        double w = Double.parseDouble(parts[4]);
        double h = Double.parseDouble(parts[5]);
        
        if (w <= 0 || h <= 0) throw new IllegalArgumentException(DopoException.INVALID_DIMENSION);
        
        if (type.equals("INITIAL")) {
            InitialZone z = new InitialZone(new Position(x, y), w, h);
            board.addVisual(z);
            board.addSpawnZone(z);
        } else if (type.equals("FINAL")) {
            FinalZone z = new FinalZone(new Position(x, y), w, h);
            board.addVisual(z);
            board.addVictoryZone(z);
        } else if (type.equals("INTERMEDIATE")) {
            IntermediateZone z = new IntermediateZone(new Position(x, y), w, h);
            board.addVisual(z);
            board.addInteractable(z); 
        } else {
            throw new IllegalArgumentException("Tipo de zona desconocido: " + type);
        }
    }

    private void parseCoin(String[] parts, Board board) {
        String type = parts[1].toUpperCase();
        if (type.equals("SKIN")) {
            if (parts.length < 5) throw new IllegalArgumentException("Faltan parámetros para COIN SKIN.");
            String skinType = parts[2].toUpperCase();
            double x = Double.parseDouble(parts[3]);
            double y = Double.parseDouble(parts[4]);
            PlayerSkin skin;
            if (skinType.equals("BLUE")) {
                skin = new BlueSkin();
            } else if (skinType.equals("GREEN")) {
                skin = new GreenSkin();
            } else if (skinType.equals("RED")) {
                skin = new RedSkin();
            } else {
                throw new IllegalArgumentException("Tipo de skin desconocido: " + skinType);
            }
            SkinCoin coin = new SkinCoin(new Position(x, y), skin);
            board.addVisual(coin);
            board.addInteractable(coin);
            board.addCollectable(coin);
        } else if (type.equals("YELLOW")) {
            if (parts.length < 4) throw new IllegalArgumentException("Faltan parámetros para COIN YELLOW.");
            double x = Double.parseDouble(parts[2]);
            double y = Double.parseDouble(parts[3]);
            YellowCoin coin = new YellowCoin(new Position(x, y));
            board.addVisual(coin);
            board.addInteractable(coin);
            board.addCollectable(coin);
        } else {
            throw new IllegalArgumentException("Tipo de moneda desconocido: " + type);
        }
    }

    private void parseEnemy(String[] parts, Board board) {
        String type = parts[1].toUpperCase();
        if (type.equals("BASIC")) {
            if (parts.length < 6) throw new IllegalArgumentException("Faltan parámetros para ENEMY BASIC.");
            double x = Double.parseDouble(parts[2]);
            double y = Double.parseDouble(parts[3]);
            String dir = parts[4];
            if (!dir.equalsIgnoreCase("H") && !dir.equalsIgnoreCase("V")) {
                throw new IllegalArgumentException("Dirección de enemigo básico inválida: " + dir);
            }
            boolean isH = dir.equalsIgnoreCase("H");
            double speed = Double.parseDouble(parts[5]);
            if (speed < 0) throw new IllegalArgumentException(DopoException.INVALID_SPEED);
      
            Enemy e = new Enemy(new Position(x, y), speed, new LinearMovement(isH));
            board.addVisual(e);
            board.addInteractable(e);
            board.addTickable(e);
        } else if (type.equals("PATROL")) {
            if (parts.length < 7) throw new IllegalArgumentException("Faltan parámetros para ENEMY PATROL.");
            double cx = Double.parseDouble(parts[2]);
            double cy = Double.parseDouble(parts[3]);
            double r = Double.parseDouble(parts[4]);
            double angle = Double.parseDouble(parts[5]);
            double speed = Double.parseDouble(parts[6]);
            if (r < 0) throw new IllegalArgumentException(DopoException.INVALID_RADIUS);
            if (speed < 0) throw new IllegalArgumentException(DopoException.INVALID_SPEED);
            
            double rad = Math.toRadians(angle);
            Position pos = new Position((cx + r * Math.cos(rad)) - Enemy.VISUAL_RADIUS, (cy + r * Math.sin(rad)) - Enemy.VISUAL_RADIUS);
            
            Enemy e = new Enemy(pos, speed, new CircularMovement(cx, cy, r, angle, speed));
            board.addVisual(e);
            board.addInteractable(e);
            board.addTickable(e);
        } else {
            throw new IllegalArgumentException("Tipo de enemigo desconocido: " + type);
        }
    }
}
