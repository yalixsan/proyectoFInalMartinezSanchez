package domain;

/**
 * Implementación de trayectoria rectilínea.
 * Dirige a la entidad en un flujo vertical u horizontal constante, 
 * invirtiendo matemáticamente su dirección al impactar contra los confines del nivel o barreras sólidas.
 */
public class LinearMovement implements MovementStrategy {
    /** Determina el eje de proyección (true para X, false para Y). */
    private boolean horizontal;
    
    /** Constante que dictamina el sentido actual del movimiento (positivo o negativo). */
    private int directionSign = 1;

    /**
     * Instancia un algoritmo de traslación recta.
     * @param horizontal Bandera que asienta el desplazamiento sobre el eje de las abscisas.
     */
    public LinearMovement(boolean horizontal) {
        this.horizontal = horizontal;
    }

    /**
     * Aplica la transformación escalar basándose en la velocidad inherente de la entidad.
     * Comprueba predictivamente la colisión; si el terreno próximo no es transitable, invierte su polaridad.
     * 
     * @param element Actor sometido al movimiento rectilíneo.
     * @param board Escenario para validación del mapa de obstáculos.
     */
    @Override
    public void move(MovableElement element, Board board) {
        double currentX = element.getPosition().getX();
        double currentY = element.getPosition().getY();
        double speed = element.getSpeed(); 
        
        Position nextPos;
        if (horizontal) {
            nextPos = new Position(currentX + (directionSign * speed), currentY);
        } else {
            nextPos = new Position(currentX, currentY + (directionSign * speed));
        }

        if (board != null && !board.isWalkable(nextPos, 20.0)) {
            directionSign *= -1;
        } else {
            element.setPosition(nextPos);
        }
    }

    /** @return true si este ente orbita sobre el eje horizontal. */
    public boolean isHorizontal() {
        return horizontal;
    }
}
