package domain;

/**
 * Clase base abstracta para todos los elementos del tablero que tienen la capacidad de desplazarse
 */
public abstract class MovableElement extends BoardElement {
    /** Magnitud de desplazamiento por fotograma del objeto */
    protected double speed;

    /**
     * Construye un elemento móvil con una posición y velocidad inicial
     * @param position Coordenada espacial de inicio.
     * @param speed Velocidad inicial de desplazamiento.
     */
    public MovableElement(Position position, double speed) {
        super(position);
        this.speed = speed;
    }

    /**
     * Define la lógica específica de desplazamiento del elemento a través del tablero
     * @param board Tablero sobre el cual se evalúa y ejecuta el movimiento
     */
    public abstract void move(Board board);

    /**
     * Consulta la velocidad de desplazamiento actual
     * @return La velocidad configurada
     */
    public double getSpeed() {
        return speed;
    }

    /**
     * Modifica la velocidad base de desplazamiento
     * @param speed Nueva velocidad a asignar
     */
    public void setSpeed(double speed) {
        this.speed = speed;
    }
}
