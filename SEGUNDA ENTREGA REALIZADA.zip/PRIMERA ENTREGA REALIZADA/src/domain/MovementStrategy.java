package domain;

import java.io.Serializable;

/**
 * Define el contrato estándar para los algoritmos de desplazamiento.
 * Patrón Strategy que permite intercambiar lógicas de movimiento dinámicamente
 * (ej. lineal vs circular) sin alterar la estructura base de los elementos móviles.
 */
public interface MovementStrategy extends Serializable {
    /**
     * Calcula y proyecta un cambio en las coordenadas espaciales de la entidad gobernada.
     * @param element El componente físico que experimentará la traslación.
     * @param board El plano interactivo que impone límites y barreras.
     */
    void move(MovableElement element, Board board);
}
