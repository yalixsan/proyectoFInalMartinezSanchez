package domain;

/**
 * Etapa de suspensión estática ("Pausa").
 * Interviene silenciando o rechazando las iteraciones matemáticas del núcleo temporal,
 * y prohíbe la transferencia de controles espaciales hasta que se expida una revocación.
 */
public class PausedState implements GameState {
    /** Ignota y anula el desarrollo secuencial retornándose a sí mismo sin afectar recursos. */
    @Override public GameState tick(GameMode mode, GameTimer timer) { return this; }
    
    /** Desecha comandos motrices evadiendo el acceso al personaje durante la inactividad. */
    @Override public GameState movePlayer(GameMode mode, int playerId, Direction dir) { return this; }
    
    /**
     * Restablece la secuencia natural, devolviendo el dominio al estadio de juego activo.
     */
    @Override
    public GameState togglePause() {
        return new PlayingState();
    }
    
    @Override public boolean isPaused() { return true; }
}
