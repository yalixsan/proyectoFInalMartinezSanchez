package domain;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

/**
 * Motor físico que controla la interacción volumétrica y espacial en el tablero
 * Gestiona las validaciones de las Hitboxes, el sistema de colisiones sólidas (muros) y la detección temprana de eventos interactuables
 */
public class PhysicsEngine implements Serializable {
    /** Margen interno de flexibilidad al evaluar solapamientos matemáticos */
    public static final double COLLISION_TOLERANCE = 8.0;

    /** Dimensión de anchura máxima oficial del plano de juego operativo */
    private int boardWidth;
    
    /** Dimensión de altura máxima oficial del plano de juego operativo */
    private int boardHeight;
    
    /** Inventario de obstáculos macizos que bloquean definitivamente las proyecciones de movimiento */
    private List<Solid> solids;
    
    /** Conjunto de entidades que toleran el paso pero desatan efectos a través del solapamiento físico */
    private List<Interactable> interactables;

    /**
     * Instancia un motor espacial basado en las métricas de lienzo estipuladas por la vista general
     * @param boardWidth Ancho general de los límites del nivel
     * @param boardHeight Altura general de los límites del nivel
     */
    public PhysicsEngine(int boardWidth, int boardHeight) {
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;
        this.solids = new ArrayList<>();
        this.interactables = new ArrayList<>();
    }

    /**
     * Ingresa una nueva geometría sólida (p. ej. Muro) al motor de restricciones
     * @param solid Objeto macizo a registrar
     */
    public void addSolid(Solid solid) { solids.add(solid); }

    /**
     * Vincula un componente capaz de reaccionar orgánicamente al contacto sin impedir el avance general
     * @param interactable Entidad condicionada al contacto
     */
    public void addInteractable(Interactable interactable) { interactables.add(interactable); }

    /**
     * Reinicia el motor borrando toda colisión o barrera existente en sus listas de comprobación
     */
    public void clear() {
        solids.clear();
        interactables.clear();
    }

    /**
     * Evalua si hay choques entre la Hitbox en movimiento y cualquier elemento susceptible de reaccionar
     * 
     * @param element La figura abstracta móvil que avanza por el tablero
     * @param elementSizeX Longitud física actual ocupada sobre el eje de las abscisas
     * @param elementSizeY Longitud física actual ocupada sobre el eje de las ordenadas
     * @return La lista estricta de todos los objetos que han reportado un solapamiento confirmado
     */
    public List<Interactable> checkCollision(MovableElement element, double elementSizeX, double elementSizeY) {
        List<Interactable> hits = new ArrayList<>();
        Position pPos = element.getPosition();

        for (Interactable c : interactables) {
            if (c != element) {
                if (c.getHitbox().collidesWith(pPos, elementSizeX, elementSizeY)) { 
                    hits.add(c);
                }
            }
        }
        return hits;
    }

    /**
     * Somete una hipotética coordenada a verificación contra las barreras sólidas (muros) y los confines físicos universales de la ventana de juego
     * 
     * @param position Coordenada proyectada hacia donde el objeto intenta migrar
     * @param size El volumen proyectado necesario para que la entidad atraviese
     * @return true si la ruta se encuentra totalmente despejada de sólidos y dentro del mapa
     */
    public boolean isWalkable(Position position, double size) {
        for (Solid s : solids) {
            if (s.blocksPosition(position, size)) {
                return false;
            }
        }
        return position.getX() >= 0 && position.getX() + size <= boardWidth && position.getY() >= 0 && position.getY() + size <= boardHeight;
    }

    /** @return Retorna un listado estructurado de los bloques estáticos con densidad */
    public List<Solid> getSolids() { return solids; }

    /** @return Devuelve un catálogo con todos los objetos interactivos actuales */
    public List<Interactable> getInteractables() { return interactables; }
}
