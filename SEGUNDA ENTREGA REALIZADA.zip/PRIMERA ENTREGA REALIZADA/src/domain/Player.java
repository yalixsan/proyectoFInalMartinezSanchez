package domain;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

/**
 * Representa al usuario interactivo dentro del tablero de juego
 */
public abstract class Player extends MovableElement {
    /** 
     * Tamaño base estándar para el cuerpo del jugador
     */
    public static final double BASE_SIZE = 20.0;
    
    /** 
     * Período de duración de los escudos protectores
     */
    public static final int INVULNERABILITY_TICKS = 60;

    /**
     * Número acumulado de muertes padecidas durante la partida
     */
    protected int deaths;
    
    /** 
     * Conteo numérico total de monedas válidas retenidas de manera actual
     */
    protected int collectedCoins;
    
    /**
     * Colección estricta de referencias a los objetos recolectados
     */
    private List<Collectable> collectedList = new ArrayList<>();
    
    /**
     * Monedas totales para poder pasar el nivel
     */
    protected int totalCoinsRequired;
    
    /**
     * Nivel o carga actual de escudos disponibles
     */
    protected int shieldPoints; 
    
    /**
     * Aspecto físico y propiedades temporales activas que posee el Player
     */
    protected PlayerSkin currentSkin;
    
    /**
     * Apariencia base con la que el jugador inicia y resucita
     */
    protected PlayerSkin originalSkin;
    
    /**
     * Especificación de colorización para los contornos del jugador
     */
    protected ElementColor borderColor;
    
    /**
     * Coordenada de spawn del jugador
     */
    protected Position spawnPoint;
    
    /** 
     * Vector de dirección solicitado de forma asíncrona por las interacciones del teclado
     */
    protected Direction intendedDirection = Direction.NONE;
    
    /**
     * Reloj interno en cuenta regresiva que define ventanas temporales de resistencia al daño
     * */
    protected int invulnerabilityTimer = 0;

    /**
     * Construye y estructura una nueva entidad de control para el usuario
     * @param position Coordenada espacial original en el plano de juego
     * @param skin Configuración de apariencia y propiedades físicas
     * @param borderColor Configuración de color para la demarcación visual del marco
     */
    public Player(Position position, PlayerSkin skin, ElementColor borderColor) {
        super(position, skin.getSpeed());
        this.originalSkin = skin;
        this.currentSkin = skin;
        this.borderColor = borderColor;
        this.deaths = 0;
        this.collectedCoins = 0;
        this.spawnPoint = new Position(position.getX(), position.getY());
    }

    /**
     * Analiza el resultado de impacto tras colisionar con una amenaza, tomando en consideración las barreras protectoras y delegando el efecto base al Skin equipado
     * @return El resultado final de la evaluación del impacto
     */
    public HitResult receiveHit() {
        if (invulnerabilityTimer > 0) {
            return HitResult.SURVIVED_SHIELD;
        }

        HitResult result = currentSkin.onHit(this);
        if (result == HitResult.SURVIVED_SHIELD) {
            invulnerabilityTimer = INVULNERABILITY_TICKS; 
        } else if (result == HitResult.DEAD) {
            die();
        }
        return result;
    }

    /**
     * Disminuye de forma iterativa el temporizador de invulnerabilidad
     * Ejecutado internamente en cada ciclo lógico del sistema 
     */
    public void decreaseInvulnerability() {
        if (invulnerabilityTimer > 0) invulnerabilityTimer--;
    }

    /**
     * Realiza la acción de hacer "morir" al jugador y una muertes al contador
     */
    public void die() {
        this.deaths++;
        respawn();
    }

    /**
     * Reubica la entidad espacialmente en su punto seguro, restaurando sus condiciones base
     */
    public void respawn() {
        this.position = new Position(spawnPoint.getX(), spawnPoint.getY());
        this.currentSkin = originalSkin;
        this.currentSkin.onRespawn();
        this.invulnerabilityTimer = 0;
    }

    /**
     * Registra un objeto de bonificación al inventario y activa el proceso de recolección en el mismo
     * @param coin Elemento coleccionable extraído exitosamente del tablero
     */
    public void collectCoin(Coin coin) {
        collectedCoins++;
        collectedList.add(coin);
        coin.collect(this);
    }

    /**
     * Modifica o asigna el punto de anclaje para apariciones seguras tras perder vidas
     * @param spawnPoint La nueva coordenada segura en el mapa
     */
    public void setSpawnPoint(Position spawnPoint) {
        this.spawnPoint = spawnPoint;
    }

    /**
     * Consulta el punto de aparición actual del jugador
     * @return Objeto posición de su anclaje
     */
    public Position getSpawnPoint() {
        return spawnPoint;
    }

    /**
     * Verifica si el progreso individual o acumulativo del inventario iguala el requerimiento de victoria
     * @return true si la recolección es completa, false en caso contrario
     */
    public boolean hasCollectedAllCoins() {
        return collectedCoins >= totalCoinsRequired;
    }

    /**
     * Actualiza el vector proyectado por el teclado antes de proceder con el cálculo espacial formal
     * @param direction Nueva intención direccional
     */
    public void setCurrentDirection(Direction direction) {
        this.intendedDirection = direction;
    }

    /**
     * Proyecta geométricamente la próxima ubicación del jugador aplicando su velocidad y vector direccional
     * Esto permite a los motores de colisión avalar y confirmar el movimiento
     * @return La coordenada tentativa donde se desea posar
     */
    public Position calculateNextPosition() {
        double currentSpeed = currentSkin.getSpeed();
        double dx = intendedDirection.getDx() * currentSpeed;
        double dy = intendedDirection.getDy() * currentSpeed;
        return this.position.translate(dx, dy);
    }

    /**
     * Ejecuta y asienta físicamente el movimiento proyectado, reasignando su coordenada final
     * @param board Tablero sobre el que se efectúa el traslado
     */
    @Override
    public void move(Board board) {
        this.position = calculateNextPosition();
    }

    /** @return Suma estadística total de eliminaciones */
    public int getDeaths() { return deaths; }

    /** @return Total parcial de unidades recogidas actualmente retenidas */
    public int getCollectedCoins() { return collectedCoins; }

    /** @return true si el sistema de protección temporal bloquea los daños entrantes */
    public boolean isInvulnerable() { return invulnerabilityTimer > 0; }

    /**
     * Reestablece las monedas en el mapa
     */
    public void resetCoins() {
        for (Collectable c : collectedList) {
            c.resetIfCollectable();
        }
        collectedList.clear();
        this.collectedCoins = 0;
    }

    /** @return Las propiedades RGB para los contornos del marco gráfico */
    public ElementColor getBorderColor() { return borderColor; }

    /** @return El modificador de atributos y apariencia en estado activo */
    public PlayerSkin getCurrentSkin() { return currentSkin; }

    /**
     * Reasigna de manera dinámica la apariencia del avatar en pleno progreso y sincroniza sus métricas 
     * @param skin Objeto representativo de las nuevas capacidades funcionales.
     */
    public void setCurrentSkin(PlayerSkin skin) {
        this.currentSkin = skin;
        this.speed = skin.getSpeed();
    }

    /**
     * Elimina el estado de apariencia provisional y devuelve al avatar a sus características nativas de origen
     */
    public void revertToOriginalSkin() {
        this.currentSkin = originalSkin;
        this.currentSkin.onRespawn();
        this.speed = originalSkin.getSpeed();
    }

    /**
     * Modifica internamente el parámetro de avance
     * @param val Requisito numérico necesario para abrir las compuertas de victoria
     */
    public void setTotalCoinsRequired(int val) { this.totalCoinsRequired = val; }

    /** @return Número maestro global para la condición del juego */
    public int getTotalCoinsRequired() { return totalCoinsRequired; }
    
    /**
     * Construye un volumen matemático derivado dinámicamente de su ubicación
     * 
     * @return El área perimetral estricta de ocupación
     */
    public Hitbox getHitbox() {
        return new RectangularHitbox(position, BASE_SIZE, BASE_SIZE);
    }

    
    @Override
    public Map<String, Object> toVisualMap() {
        Map<String, Object> data = new HashMap<>();
        if (isActive) {
            data.put("shape", "RECT"); 
            data.put("x", (int)position.getX());
            data.put("y", (int)position.getY());
            
            int size = (int)(BASE_SIZE * currentSkin.getSize());
            data.put("w", size);
            data.put("h", size);
            
            data.put("isInvulnerable", isInvulnerable());
            
            // Color de Relleno (Skin)
            ElementColor skinColor = currentSkin.getColor();
            data.put("r", skinColor.getR());
            data.put("g", skinColor.getG());
            data.put("b", skinColor.getB());
            
            data.put("br", borderColor.getR());
            data.put("bg", borderColor.getG());
            data.put("bb", borderColor.getB());
        }
        return data;
    }
}
