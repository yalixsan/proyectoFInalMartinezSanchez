package domain;

/**
 * Etapa de procesamiento activo ("En Juego").
 * Avala la ejecución en paralelo de los motores, el control motriz de los jugadores y
 * transiciona automáticamente a estados terminales si cambian las condiciones evaluadas de victoria o derrota.
 */
public class PlayingState implements GameState {
    
    /**
     * Hace discurrir el tiempo real consumiendo milisegundos lógicos e inspeccionando
     * las fronteras operativas para emitir los correspondientes cierres de nivel.
     */
    @Override
    public GameState tick(GameMode mode, GameTimer timer) {
        mode.tick();
        timer.tick();
        
        if (mode.checkVictory()) {
            return new VictoryState();
        } else if (mode.isGameOver() || timer.isTimeUp()) {
            return new GameOverState();
        }
        return this;
    }
    
    /**
     * Aprueba la canalización de la señal humana impactando directamente a la orientación de su entidad virtual.
     */
    @Override
    public GameState movePlayer(GameMode mode, int playerId, Direction dir) {
        if (mode != null && mode.getPlayers().size() > playerId) {
            mode.getPlayers().get(playerId).setCurrentDirection(dir);
        }
        return this;
    }
    
    /**
     * Ordena una pausa estructural saltando orgánicamente al nodo de suspensión.
     */
    @Override
    public GameState togglePause() {
        return new PausedState();
    }
    
    @Override public boolean isPlaying() { return true; }
}
