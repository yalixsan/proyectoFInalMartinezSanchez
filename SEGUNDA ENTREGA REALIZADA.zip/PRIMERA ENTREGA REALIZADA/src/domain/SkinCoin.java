package domain;

/**
 * Diferentes tipos de monedas 
 */
public class SkinCoin extends Coin {
    /** Disfraz cosmético encapsulado y listo para ser equipado por el jugador */
    private PlayerSkin associatedSkin;

    /**
     * Construye un utilitario cosmético depositándolo sobre el entorno
     * @param position       Coordenada precisa donde residirá
     * @param associatedSkin El paquete estético a otorgar al contacto
     */
    public SkinCoin(Position position, PlayerSkin associatedSkin) {
        super(position);
        this.associatedSkin = associatedSkin;
    }

    /**
     * Interpola la adquisición transfiriendo inmediatamente la máscara cosmética al avatar e inhabilitando a la moneda.
     * @param player Usuario beneficiado por la interacción
     */
    @Override
    public void collect(Player player) {
        collected = true;
        deactivate();
        player.setCurrentSkin(associatedSkin);
    }

    /**
     * Ratifica su carácter obligatorio frente al motor de reglas del juego
     * @return true incondicionalmente
     */
    @Override
    public boolean countsAsRequiredCoin() {
        return true;
    }

    /** @return La indumentaria o estética atada a este coleccionable */
    public PlayerSkin getAssociatedSkin() {
        return associatedSkin;
    }

    @Override
    public java.util.Map<String, Object> toVisualMap() {
        java.util.Map<String, Object> data = super.toVisualMap();
        if (data != null && !data.isEmpty()) {
            ElementColor color = associatedSkin.getColor();
            data.put("r", color.getR());
            data.put("g", color.getG());
            data.put("b", color.getB());
        }
        return data;
    }

    @Override
    public void reset() {
        super.reset();
        if (associatedSkin != null) {
            associatedSkin.onRespawn();
        }
    }
}
