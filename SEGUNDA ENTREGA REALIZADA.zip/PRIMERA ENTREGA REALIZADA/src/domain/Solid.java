package domain;

import java.io.Serializable;

/**
 * Contrato para aquellos objetos que son solidos, o no traspasables 
 */
public interface Solid extends Serializable {
    /**
     * Obtiene el punto de origen geométrico de esta barrera
     * @return La coordenada maestra de la entidad estática
     */
    Position getPosition();
    
    /**
     * Verifica categóricamente si el prisma espacial de este objeto rechaza y prohíbe el paso de un volumen entrante
     * @param pos Coordenada ajena a evaluar
     * @param size Margen de ocupación del visitante
     * @return true si ocurre colisión impidiendo el paso; false de lo contrario
     */
    boolean blocksPosition(Position pos, double size);
}
