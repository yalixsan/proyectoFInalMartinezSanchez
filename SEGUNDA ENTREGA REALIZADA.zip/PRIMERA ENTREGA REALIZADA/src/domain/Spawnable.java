package domain;

import java.io.Serializable;

/**
 * Capacita a un componente territorial para funcionar como punto de despliegue
 * Provee la lógica necesaria para inyectar a un jugador dentro del lienzo
 */
public interface Spawnable extends Serializable {
    /**
     * Calcula y entrega una coordenada lícita para la aparición de una entidad
     * @return El vector posicional seguro para instanciar al avatar
     */
    Position getSpawnPoint();
}
