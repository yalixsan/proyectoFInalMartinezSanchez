package domain;

import java.io.Serializable;

/**
 * Establece el contrato para entidades dinámicas que exigen actualizaciones constantes
 */
public interface Tickable extends Serializable {
    /**
     * Procesa la lógica interna de la entidad correspondiente a un instante temporal del juego
     * @param board Tablero sobre el que opera y valida sus cálculos de contexto
     */
    void tick(Board board);
}
