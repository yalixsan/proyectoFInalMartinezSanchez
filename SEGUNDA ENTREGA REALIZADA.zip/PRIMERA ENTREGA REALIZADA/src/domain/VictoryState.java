package domain;

/**
 * Fase terminal afirmativa ("Victoria").
 * Reconoce el cumplimiento protocolar absoluto de las reglas y objetivos, congelando
 * mecánicas competitivas en favor de premiar y transicionar la sesión.
 */
public class VictoryState implements GameState {
    /** Frena toda cronometría y despliegues matemáticos confirmando la meta. */
    @Override public GameState tick(GameMode mode, GameTimer timer) { return this; }
    
    /** Bloquea las peticiones direccionales finalizando la jugabilidad activa. */
    @Override public GameState movePlayer(GameMode mode, int playerId, Direction dir) { return this; }
    
    /** Deshabilita la opción de suspensión operativa por cierre irreversible de nivel. */
    @Override public GameState togglePause() { return this; }
    
    @Override public boolean isVictory() { return true; }
}
