package domain;

import java.io.Serializable;

/**
 * Zona especializada en acabar la partida dando un estado de victoria
 */
public interface VictoryZone extends Serializable {
    /**
     * Dictamina si la posición consultada trasciende la línea de meta
     * @param pos El vector posicional del jugador a someter a evaluación
     * @return true si el usuario se encuentra validamente dentro del territorio de triunfo
     */
    boolean isFinalZoneFor(Position pos);
}
