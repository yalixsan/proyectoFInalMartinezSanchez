package domain;

/**
 * Entidad estática infranqueable que delimita la topología del mapa.
 * Actúa como una restricción material sólida interrumpiendo trayectorias de movimiento.
 * Puede presentarse en variantes explícitamente visibles para el usuario u ocultas.
 */
public class Wall extends BoardElement implements Solid {
    /** Escala horizontal de la muralla que impedirá el tránsito. */
    private double width;
    
    /** Escala vertical del componente para dictaminar el área de bloqueo. */
    private double height;
    
    /** Indicador booleano de renderización. Si es true, el motor visual expone este muro. */
    private boolean visible = true;

    /**
     * Erige una nueva muralla arquitectónica estándar (por defecto expuesta en la interfaz).
     * 
     * @param position Coordenada geográfica originaria en el entorno de juego.
     * @param width    Longitud que obstruye sobre el eje X.
     * @param height   Longitud que obstaculiza en el eje Y.
     */
    public Wall(Position position, double width, double height) {
        this(position, width, height, true);
    }

    /**
     * Erige un muro con la capacidad de omitir su trazado gráfico en el motor visual.
     * 
     * @param position Origen topológico del prisma inquebrantable.
     * @param width    Extensión a bloquear lateralmente.
     * @param height   Extensión a interrumpir verticalmente.
     * @param visible  Bandera que ordena (true) o prohíbe (false) la renderización del muro.
     */
    public Wall(Position position, double width, double height, boolean visible) {
        super(position);
        this.width = width;
        this.height = height;
        this.visible = visible;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    /**
     * Valida de manera estricta si un área de proyección superpone o viola la solidez de esta pared.
     * 
     * @param pos  La posición estimada a la cual el avatar u objeto pretende migrar.
     * @param size El volumen estimado ocupado por dicha entidad viajera.
     * @return true si se comprueba el traslape (prohibiendo así el avance); false si el paso es lícito.
     */
    @Override
    public boolean blocksPosition(Position pos, double size) {
        double px = pos.getX();
        double py = pos.getY();
        return px < position.getX() + width && 
               px + size > position.getX() &&
               py < position.getY() + height &&
               py + size > position.getY();
    }

    /** @return Espacio total negado horizontalmente por la pieza maciza. */
    public double getWidth() { return width; }
    
    /** @return Margen denegado de forma vertical en el entorno. */
    public double getHeight() { return height; }
    
    /** @return Afirmación directa sobre si esta estructura se dibujará en la vista. */
    public boolean isVisible() { return visible; }
    
    /**
     * Obliga al muro a revelar u ocultar sus trazos gráficos según corresponda el diseño.
     * @param visible true para pintarlo; false para volverlo imperceptible (invisible wall).
     */
    public void setVisible(boolean visible) { this.visible = visible; }

    @Override
    public java.util.Map<String, Object> toVisualMap() {
        java.util.Map<String, Object> data = new java.util.HashMap<>();
        if (visible && isActive) {
            data.put("shape", "RECT");
            data.put("x", (int)position.getX());
            data.put("y", (int)position.getY());
            data.put("w", (int)width);
            data.put("h", (int)height);
            // Color azul/gris pastel para muros
            data.put("r", 140);
            data.put("g", 150);
            data.put("b", 220);
            // Borde oscuro (Negro)
            data.put("br", 0);
            data.put("bg", 0);
            data.put("bb", 0);
        }
        return data;
    }
}
