package domain;

/**
 * Clase para la representación de la moneda
 */
public class YellowCoin extends Coin {
    /**
     * Construye y posiciona la recompensa básica en el plano físico
     * @param position Coordenada geográfica asignada a su instanciación
     */
    public YellowCoin(Position position) {
        super(position);
    }

    /**
     * Resuelve el acto de recolección apagando la visibilidad del ítem
     * @param player El usuario que ha entrado en la circunferencia del ítem
     */
    @Override
    public void collect(Player player) {
        collected = true;
        deactivate();
        player.revertToOriginalSkin();
    }

    /**
     * Confirma ante los árbitros del sistema que la obtención de esta moneda es obligatoria
     * @return true de manera constante.
     */
    @Override
    public boolean countsAsRequiredCoin() {
        return true;
    }
}
