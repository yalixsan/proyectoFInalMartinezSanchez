package domain;

/**
 * Representa una abstracción geométrica fundamental sobre el tablero
 */
public abstract class Zone extends BoardElement {
    /** Longitud horizontal estipulada para el área de la zona */
    protected double width;
    
    /** Longitud vertical estipulada para el área de la zona */
    protected double height;

    /**
     * Constructor base que inicializa las propiedades espaciales y dimensionales de la región
     * 
     * @param position Coordenada que define el vértice superior izquierdo de la zona
     * @param width    Magnitud que define la extensión horizontal
     * @param height   Magnitud que define la extensión vertical
     */
    public Zone(Position position, double width, double height) {
        super(position);
        this.width = width;
        this.height = height;
    }

    /**
     * Algoritmo de validación espacial que evalúa matemáticamente si un punto exacto reside dentro de los márgenes bidimensionales de esta zona.
     * @param pos La coordenada específica a someter bajo escrutinio
     * @return true si el punto es interior a los límites; de lo contrario, false
     */
    public boolean contains(Position pos) {
        return pos.getX() >= position.getX() && pos.getX() <= position.getX() + width &&
        pos.getY() >= position.getY() && pos.getY() <= position.getY() + height;
    }

    /** @return La extensión escalar del ancho de esta región */
    public double getWidth() { return width; }
    
    /** @return La extensión escalar de la altura de esta región */
    public double getHeight() { return height; }

    /**
     * Construye y exporta una caja de colisiones basada en las métricas actuales del elemento
     * @return Instancia de RectangularHitbox ajustada a las proporciones de la zona
     */
    public Hitbox getHitbox() {
        return new RectangularHitbox(position, width, height);
    }

    @Override
    public java.util.Map<String, Object> toVisualMap() {
        java.util.Map<String, Object> data = new java.util.HashMap<>();
        if (isActive) {
            data.put("shape", "RECT");
            data.put("x", (int)position.getX());
            data.put("y", (int)position.getY());
            data.put("w", (int)width);
            data.put("h", (int)height);
            data.put("r", 153);
            data.put("g", 255);
            data.put("b", 153);
            data.put("br", 0);
            data.put("bg", 0);
            data.put("bb", 0);
        }
        return data;
    }
}
