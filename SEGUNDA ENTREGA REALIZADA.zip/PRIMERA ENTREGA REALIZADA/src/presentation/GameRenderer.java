package presentation;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * GameRenderer maneja el registro de renderizadores para cada tipo de figura
 * y se encarga del renderizado gráfico del juego y de su HUD en pantalla.
 */
public class GameRenderer {
    private final Map<String, ElementRenderer> renderers = new HashMap<>();

    public GameRenderer() {
        initializeGameRenderers();
    }

    private void initializeGameRenderers() {
        renderers.put("RECT", (data, g2d) -> {
            int x = ((Number) data.get("x")).intValue();
            int y = ((Number) data.get("y")).intValue();
            int w = ((Number) data.get("w")).intValue();
            int h = ((Number) data.get("h")).intValue();
            int r = ((Number) data.get("r")).intValue();
            int g = ((Number) data.get("g")).intValue();
            int b = ((Number) data.get("b")).intValue();
            g2d.setColor(new Color(r, g, b));
            g2d.fillRect(x, y, w, h);
            
            if (data.containsKey("br")) {
                int br = ((Number) data.get("br")).intValue();
                int bg = ((Number) data.get("bg")).intValue();
                int bb = ((Number) data.get("bb")).intValue();
                g2d.setColor(new Color(br, bg, bb));
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRect(x, y, w, h);
            }
        });
        
        renderers.put("OVAL", (data, g2d) -> {
            int x = ((Number) data.get("x")).intValue();
            int y = ((Number) data.get("y")).intValue();
            int w = ((Number) data.get("w")).intValue();
            int h = ((Number) data.get("h")).intValue();
            int r = ((Number) data.get("r")).intValue();
            int g = ((Number) data.get("g")).intValue();
            int b = ((Number) data.get("b")).intValue();
            g2d.setColor(new Color(r, g, b));
            g2d.fillOval(x, y, w, h);
            
            if (data.containsKey("br")) {
                int br = ((Number) data.get("br")).intValue();
                int bg = ((Number) data.get("bg")).intValue();
                int bb = ((Number) data.get("bb")).intValue();
                g2d.setColor(new Color(br, bg, bb));
                g2d.setStroke(new BasicStroke(1));
                g2d.drawOval(x, y, w, h);
            }
        });
        
        renderers.put("CHECKER", (data, g2d) -> {
            int cx = ((Number) data.get("x")).intValue();
            int cy = ((Number) data.get("y")).intValue();
            int cw = ((Number) data.get("w")).intValue();
            int ch = ((Number) data.get("h")).intValue();
            int r = ((Number) data.get("r")).intValue();
            int g = ((Number) data.get("g")).intValue();
            int b = ((Number) data.get("b")).intValue();
            
            g2d.setColor(new Color(r, g, b));
            g2d.fillRect(cx, cy, cw, ch);
            g2d.setColor(new Color(230, 230, 255));
            for(int x = 0; x < cw; x += 25) {
                for(int y = 0; y < ch; y += 25) {
                    if(((x/25) + (y/25)) % 2 == 0) g2d.fillRect(cx + x, cy + y, 25, 25);
                }
            }
            if (data.containsKey("br")) {
                int br = ((Number) data.get("br")).intValue();
                int bg = ((Number) data.get("bg")).intValue();
                int bb = ((Number) data.get("bb")).intValue();
                g2d.setColor(new Color(br, bg, bb));
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRect(cx, cy, cw, ch);
            }
        });
    }

    /**
     * Dibuja los elementos del juego y el HUD en el panel.
     */
    public void drawGame(Graphics2D g2d, V2GUI gui, int panelWidth, int panelHeight, boolean isPaused) {
        g2d.setColor(new Color(180, 180, 255));
        g2d.fillRect(0, 0, panelWidth, panelHeight);

        if (gui.isGameLoaded()) {
            for (Map<String, Object> data : gui.getGameObjectsData()) {
                String shape = (String) data.get("shape");
                ElementRenderer r = renderers.get(shape);
                if (r != null) r.render(data, g2d);
            }

            for (Map<String, Object> data : gui.getGamePlayersData()) {
                Boolean isInvulnerable = (Boolean) data.get("isInvulnerable");
                if (isInvulnerable != null && isInvulnerable && System.currentTimeMillis() % 200 < 100) {
                    continue;
                }

                String shape = (String) data.get("shape");
                ElementRenderer r = renderers.get(shape);
                if (r != null) r.render(data, g2d);
            }
        }

        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        int secondsLeft = (gui.isGameLoaded()) ? gui.getTimeRemaining() : 0;
        g2d.drawString("Time: " + secondsLeft + "s", 10, 20);
        
        if (gui.isGameLoaded()) {
            int numPlayers = gui.getGamePlayersData().size();
            if (numPlayers > 0) {
                if (numPlayers > 1) {
                    g2d.drawString("P1 Deaths: " + gui.getGamePlayerDeaths(0) + " | Coins: " + gui.getGamePlayerCollectedCoins(0) + "/" + gui.getGamePlayerTotalCoinsRequired(0), 110, 20);
                    g2d.drawString("P2 Deaths: " + gui.getGamePlayerDeaths(1) + " | Coins: " + gui.getGamePlayerCollectedCoins(1) + "/" + gui.getGamePlayerTotalCoinsRequired(1), 340, 20);
                } else {
                    g2d.drawString("Deaths: " + gui.getGamePlayerDeaths(0), 120, 20);
                    g2d.drawString("Coins: " + gui.getGamePlayerCollectedCoins(0) + "/" + gui.getGamePlayerTotalCoinsRequired(0), 230, 20);
                }
            }
        }
        
        g2d.setFont(new Font("Arial", Font.ITALIC, 12));
        g2d.drawString("Press Esc/P to Pause | Ctrl+S to Save", 550, 20);

        if (isPaused) {
            g2d.setColor(new Color(0, 0, 0, 150));
            g2d.fillRect(0, 0, panelWidth, panelHeight);
        }
    }
}
