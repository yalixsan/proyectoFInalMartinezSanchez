# Plan de Diseño y Justificación para Cobertura de Pruebas Faltantes

Este documento detalla la estrategia de diseño y justificación técnica para cubrir el 100% de las funcionalidades del dominio de **DOPO** que actualmente carecen de pruebas unitarias o tienen cobertura parcial.

Siguiendo el principio de **alta calidad y rigidez**, optamos por **enriquecer y robustecer las pruebas unitarias existentes** en las 4 clases principales, integrando las llamadas a través de la fachada (`DOPOGame`) y de manera indirecta/integrada a través de las entidades principales (`Player`, `Enemy`, `Board`, `GameMode`), evitando aserciones aisladas o de bajo nivel sobre getters triviales o diccionarios.

---

## 1. Tabla de Mapeo y Estrategia de Cobertura

La siguiente tabla resume cómo se integrará cada elemento faltante en la suite de pruebas de manera integrada:

| Clase | Método / Constructor | Estrategia de Prueba Integrada | Test Asociado (Actual o Nuevo) |
| :--- | :--- | :--- | :--- |
| `InitialZone` | `getSpawnPoint(int, Player)` y `getSpawnPoint(int, Player, int)` | **Integrado**: Invocar a través de la reaparición del jugador en el tablero. | `testInitialZoneCentering` |
| `RectangularHitbox` | Constructor y `collidesWith(...)` | **Integrado**: Probar mediante las colisiones físicas de `board.isWalkable` y hitboxes de Zonas. | `testHitboxBoundaryCollisions` (en `BoardElementTest`) |
| `ElementColor` | `getName()`, `equals(...)` y `hashCode()` | **Integrado**: Comparar los colores de borde de los jugadores creados por la fábrica. | `testElementColorEquality` (en `BoardElementTest`) |
| `VisualEngine` | `getElementsAt(...)` | **Integrado**: Verificar mediante el filtrado de entidades visibles en el tablero. | `testEnemyListIsolationAfterClear` (en `GameplayLogicTest`) |
| `Enemy` | `setMovementStrategy(...)` y `getMovementStrategy()` | **Integrado**: Modificar y obtener la estrategia directamente desde la entidad `Enemy` en el tablero. | `testEnemyDynamicStrategyChange` (en `GameplayLogicTest`) |
| `Wall` | `getPosition()`, `getWidth()`, `getHeight()`, `isVisible()` | **Integrado**: Validar a través del comportamiento físico de colisión con muros en el tablero. | `testWallCollisionObstruction` |
| `Wall` | `blocksPosition(...)` (cobertura parcial) | **Integrado**: Evaluar mediante pasos de movimiento del jugador contra el muro en coordenadas límites. | `testWallCollisionObstruction` |
| `Wall` | `toVisualMap()` | **Invocación Indirecta**: Obtener datos gráficos del tablero mediante la fachada (`dopoGame.getObjectsData()`). | `testGamePauseLogic` (en `GameplayLogicTest`) |
| `GameMode` | `countCoins()` (cobertura parcial) | **Integrado**: Comprobar el progreso de recolección de monedas necesarias para activar la victoria. | `testVictoryConditionMet` |
| `GameMode` | `tick()` | **Integrado**: Ejecutar a través del ciclo de actualización controlado del juego en PvP y SinglePlayer. | `testPvPMutualPlayerCollision` (en `GameplayLogicTest`) |
| `GameMode` | `checkVictory()` | **Integrado**: Validar la transición de estados de victoria y juego en curso a través de la fachada. | `testVictoryConditionDenied` |
| `GameMode` | `handlePlayerEnemyCollision(...)` | **Integrado**: Colisionar al jugador con un enemigo en el tablero y verificar la pérdida de monedas a través del jugador. | `testEnemyHitResetsCollectedCoins` (en `GameplayLogicTest`) |
| `GameMode` | `handlePlayerPlayerCollision(...)` | **Integrado**: Colisionar a dos jugadores en el tablero y verificar la restauración de monedas a recoger. | `testPvPPlayerCollisionReset` |
| `GameMode` | `isGameOver()` y `getBoard()` | **Integrado**: Validar a través de las consultas de estado en la fachada de juego. | `testGamePauseLogic` y `testVictoryConditionMet` |
| `Position` | `setX(...)`, `setY(...)` y `distanceTo(...)` | **Integrado**: Validar a través del cálculo de posiciones de reaparición y cálculo de distancias de paso de entidades móviles. | `testPositionAlgebra` (en `PlayerSkinTest` o `BoardElementTest`) |
| `CircularMovement` | Getters (`getCenterX`, `getRadius`, `getAngleDegrees`, etc.) | **Integrado**: Consultar a través de la estrategia del enemigo patrullero registrado en el tablero. | `testEnemyCircularPatrolPath` |
| `Zone` | `contains(...)` (cobertura parcial) | **Integrado**: Verificar mediante la validación de si el jugador está dentro de la meta o checkpoint en el tablero. | `testIntermediateZoneCheckpoint` |
| `Zone` | `getHitbox()` | **Integrado**: Evaluar obteniendo la caja de colisión del checkpoint/meta del nivel. | `testIntermediateZoneCheckpoint` |
| `Zone` | `toVisualMap()` | **Invocación Indirecta**: Obtener datos gráficos del tablero mediante la fachada (`dopoGame.getObjectsData()`). | `testGamePauseLogic` (en `GameplayLogicTest`) |
| `LinearMovement` | Patrullaje vertical (`horizontal = false`) | **Integrado**: Verificar la inversión de dirección de un enemigo patrullero vertical al chocar contra un muro. | `testEnemyVerticalLinearBounce` (en `GameplayLogicTest`) |
| `LinearMovement` | `isHorizontal()` | **Integrado**: Validar consultando la estrategia del enemigo vertical en el tablero. | `testEnemyVerticalLinearBounce` |
| `GreenSkin` | `getSize()`, `getName()`, `getColor()`, `isResistanceUsed()`, `resetResistance()` | **Integrado**: Validar a través de las propiedades y el comportamiento de escudo del `Player` con skin Clyde. | `testGreenSkinFirstHitShield`, `testGreenSkinSecondHitFatal` y `testGreenSkinRespawnResetsShield` |
| `HumanPlayer` | `getPlayerId()` | **Integrado**: Validar a través del jugador retornado por la fábrica o el tablero de juego. | `testFactorySinglePlayerMode` |
| `HumanPlayer` | `processRemoteInput(...)` | **Integrado**: Simular eventos de teclado remotos en la fachada y verificar el cambio de dirección del jugador. | `testHumanPlayerRemoteInput` (en `PlayerSkinTest`) |
| `MovableElement` | `setSpeed(...)` | **Integrado**: Modificar velocidad en el jugador y evaluar que la distancia recorrida en un paso cambie proporcionalmente. | `testPlayerMovementStepPrecision` |
| `BlueSkin` | `onHit(...)` | **Integrado**: Dañar al jugador con skin Inky y verificar la muerte instantánea en el tablero. | `testBlueSkinAttributes` |
| `YellowCoin` | `countsAsRequiredCoin()` | **Integrado**: Verificar a través de la recolección e incremento de monedas requeridas en el modo de juego. | `testYellowCoinCollection` |

---

## 2. Diseño Detallado y Justificación de las Pruebas

A continuación se detalla cómo se diseñarán estas pruebas para asegurar que cada funcionalidad sea verificada con la máxima rigurosidad y de forma integrada.

### Componente A: Posiciones y Geometría (`Position` y `RectangularHitbox`)

#### 1. Enriquecer `testPositionAlgebra` (en `PlayerSkinTest`)
* **Diseño**:
  - Instanciar una posición `Position pos = new Position(10.0, 20.0)`.
  - Invocar `pos.setX(30.0)` y `pos.setY(40.0)`. Verificar mediante `assertEquals` que las coordenadas cambiaron de forma inmutable.
  - Calcular la distancia a otra posición `Position other = new Position(33.0, 44.0)` invocando `pos.distanceTo(other)`.
  - **Cálculo teórico**: $\sqrt{(33 - 30)^2 + (44 - 40)^2} = \sqrt{3^2 + 4^2} = 5.0$. Verificar que la distancia sea exactamente `5.0`.
* **Justificación**: Valida el comportamiento elemental y matemático del vector de posición bidimensional, garantizando que el cálculo de distancia euclidiana sea exacto para la detección de colisiones de proximidad en `VisualEngine`.

#### 2. Nuevo `testHitboxBoundaryCollisions` (en `BoardElementTest`)
* **Diseño**:
  - Instanciar un `RectangularHitbox hitbox = new RectangularHitbox(new Position(100, 100), 50, 50)`.
  - Probar tres casos de colisión usando `hitbox.collidesWith(Position, double, double)`:
    1. **Traslape completo (Colisión)**: Objeto en `(120, 120)` de tamaño `20x20`. Debe retornar `true`.
    2. **Fuera de límites (Sin colisión)**: Objeto en `(200, 200)` de tamaño `20x20`. Debe retornar `false`.
    3. **Caso límite (Borde exacto)**: Objeto en `(150, 100)` de tamaño `20x20` (X del objeto coincide exactamente con el límite derecho de la caja: $100 + 50 = 150$). Debe retornar `false` (puesto que el operador es estrictamente menor `<` y no menor o igual `<=`).
* **Justificación**: Verifica las condiciones límite del algoritmo de colisión AABB para asegurar que no se produzcan falsos positivos en los bordes de los muros y zonas del mapa.

---

### Componente B: Elementos del Tablero e Integración de Fachada (`Wall`, `Zone`, `ElementColor`)

#### 1. Enriquecer `testWallCollisionObstruction` e `testIntermediateZoneCheckpoint` (en `BoardElementTest`)
* **Diseño**:
  - Instanciar un `Wall wall = new Wall(new Position(100, 100), 50, 50, true)`.
  - Verificar getters: `assertEquals(100.0, wall.getPosition().getX())`, `assertEquals(50.0, wall.getWidth())`, `assertEquals(50.0, wall.getHeight())`, y `assertTrue(wall.isVisible())`.
  - Probar los límites de `blocksPosition(Position, double)` en los bordes exactos del muro.
  - En `testIntermediateZoneCheckpoint`, invocar `checkpoint.getHitbox()` y verificar que el hitbox resultante sea de tipo `RectangularHitbox`.
  - Probar la lógica del método `contains(Position)` pasando coordenadas límites exteriores de la zona (por ejemplo, sumando `width` y `height` exactos).
* **Justificación**: Asegura que el estado visual y físico del muro y la zona sea consistente, garantizando que el motor de físicas y el de renderizado compartan la misma información exacta.

#### 2. Invocación Indirecta de `toVisualMap()` vía Fachada
* **Diseño (Integrado en `testGamePauseLogic`)**:
  - En la prueba `testGamePauseLogic`, tras configurar el tablero de `dopoGame` con muros, coleccionables y zonas, realizar una llamada indirecta a la fachada:
    ```java
    java.util.List<java.util.Map<String, Object>> objectsData = dopoGame.getObjectsData();
    java.util.List<java.util.Map<String, Object>> playersData = dopoGame.getPlayersData();
    ```
  - Verificar que las listas no sean nulas y contengan elementos.
  - **Justificación**: Siguiendo la retroalimentación arquitectónica de no realizar aserciones manuales de bajo nivel sobre las llaves del mapa de renderizado, este enfoque delega el renderizado en la fachada `DOPOGame`. Esto comprueba indirectamente la ejecución de `toVisualMap()` en muros (`Wall`), zonas (`Zone`), monedas (`YellowCoin`) y jugadores sin acoplar la prueba a la estructura interna del diccionario.

#### 3. Nuevo `testElementColorEquality` (en `BoardElementTest`)
* **Diseño**:
  - Obtener los colores de los jugadores creados a través de `PlayerFactory` o instanciando los colores directamente.
  - Validar los métodos `equals()` y `hashCode()` de `ElementColor` usando colores iguales y diferentes.
  - Verificar la correcta asignación del nombre descriptivo del color (`getName()`).
* **Justificación**: Evita colisiones de hash incorrectas y asegura la inmutabilidad de los colores de borde del jugador, lo que previene errores al renderizar múltiples personajes de distintos equipos.

---

### Componente C: Reglas y Modos de Juego (`GameMode`, `VisualEngine`)

#### 1. Enriquecer `testVictoryConditionMet` y `testVictoryConditionDenied` (en `GameplayLogicTest`)
* **Diseño**:
  - Validar el método `gameMode.getBoard()` comprobando que retorne exactamente la misma instancia del tablero provista en el constructor.
  - Validar `gameMode.isGameOver()` asegurando que retorne `false` por defecto al inicio de la partida.
  - Verificar que el conteo de monedas requeridas de `gameMode.countCoins()` coincida exactamente con las monedas marcadas como obligatorias en el tablero.
* **Justificación**: Asegura que el facade principal o el motor gráfico puedan acceder de manera segura al estado y recursos del tablero.

#### 2. Nuevo `testEnemyHitResetsCollectedCoins` y Enriquecer PvP (en `GameplayLogicTest`)
* **Diseño**:
  - **Colisión con enemigo y pérdida de monedas**:
    - Simular que un jugador recoge una moneda: `player.collectCoin(new YellowCoin(new Position(0,0)))`.
    - Invocar `gameMode.handlePlayerEnemyCollision(player, enemy)`.
    - Verificar que el impacto sea letal para la skin roja (`HitResult.DEAD`) y que consecuentemente el total de monedas recolectadas del jugador regrese a `0` (reinicio completo de monedas al morir).
  - **Actualización en el ciclo de vida (tick)**:
    - En el test de PvP `testPvPPlayerCollisionReset`, tras la colisión mutua de los jugadores, agregar una moneda recolectada en el tablero y simular su recolección. Invocar `handlePlayerPlayerCollision(p1, p2)`.
    - Verificar que la moneda del tablero se haya restaurado (`resetIfCollectable()`) para que pueda ser recogida nuevamente.
    - Ejecutar un tick controlado del juego `gameMode.tick()`.
* **Justificación**: Asegura que las penalizaciones por muerte y la restauración del estado del nivel sigan reglas del juego estrictas en modo PvP y SinglePlayer.

#### 3. Enriquecer `testEnemyListIsolationAfterClear` (en `GameplayLogicTest`)
* **Diseño**:
  - Agregar dos enemigos en posiciones separadas: `enemy1` en `(100, 100)` y `enemy2` en `(150, 150)`.
  - Invocar `board.getVisualElementsAt(new Position(100, 100))` o a través de `VisualEngine` mediante la delegación en `board.getElementsAt(...)`.
  - Comprobar que retorne una lista que contenga únicamente a `enemy1` (debido a la distancia euclidiana inferior a `1.0`).
  - Probar con una coordenada intermedia donde no haya nada y validar que la lista retorne vacía.
* **Justificación**: Garantiza el correcto funcionamiento de las búsquedas espaciales en el motor de renderizado, optimizando la cantidad de elementos dibujados en pantalla en tiempo real.

---

### Componente D: Movimientos y Skins (`LinearMovement`, `CircularMovement`, `GreenSkin`, `BlueSkin`, `HumanPlayer`, `MovableElement`)

#### 1. Nuevo `testEnemyVerticalLinearBounce` (en `GameplayLogicTest`)
* **Diseño**:
  - Instanciar un enemigo en la posición `(100, 105)` con velocidad `5.0`.
  - Asignarle un movimiento lineal vertical: `LinearMovement` con parametrización `horizontal = false`.
  - Consultar `enemy.getMovementStrategy()` y verificar que `isHorizontal()` retorne `false` de forma integrada.
  - Colocar un muro sólido abajo del enemigo en la coordenada `(100, 130)` con tamaño `20x20`.
  - Ejecutar un tick de movimiento: el enemigo debe avanzar hacia el sur a `(100, 110)`.
  - Ejecutar un segundo tick: el enemigo colisionará con la caja física del muro en `(100, 130)` (rango de colisión), por lo que no modificará su posición (permanece en `110`) e invierte su dirección de patrullaje a `-1`.
  - Ejecutar un tercer tick: el enemigo avanza hacia el norte y se ubica en `(100, 105)`.
* **Justificación**: Valida el patrullaje vertical autónomo de los enemigos, completando la cobertura de todas las estrategias de movimiento lineal.

#### 2. Enriquecer `testEnemyCircularPatrolPath` (en `GameplayLogicTest`)
* **Diseño**:
  - Consultar el `MovementStrategy` activo del enemigo circular y comprobar que sus propiedades correspondan a los valores físicos orbitales:
    - Centro de órbita `(150, 150)`.
    - Radio `50.0`.
    - Ángulo inicial `0.0`.
    - Velocidad angular de patrulla `10.0`.
* **Justificación**: Asegura la inmutabilidad y la correcta lectura del estado interno de los enemigos orbitales por parte del cargador de niveles y los serializadores.

#### 3. Enriquecer y Robustecer Skins (`testGreenSkinFirstHitShield` y `testBlueSkinAttributes`)
* **Diseño**:
  - Consultar las propiedades de los jugadores creados con las skins `GreenSkin` (Clyde) e `BlueSkin` (Inky).
  - Validar los nombres (`getName()`), tamaños de escala (`getSize()`) y colores (`getColor()`) a través del objeto `Player` que las envuelve.
  - En Clyde, verificar `player.getCurrentSkin().isResistanceUsed()` antes y después del impacto, e invocar `resetResistance()` a través del ciclo de vida del juego.
  - En Inky, verificar que al recibir un golpe retorne `HitResult.DEAD` y mate al jugador instantáneamente.
* **Justificación**: Refuerza las reglas de negocio de las skins Clyde e Inky para evitar bugs que den inmunidades infinitas a los jugadores.

#### 4. Enriquecer `testFactorySinglePlayerMode` y Nuevo `testHumanPlayerRemoteInput` (en `PlayerSkinTest`)
* **Diseño**:
  - En `testFactorySinglePlayerMode`, verificar que el jugador creado tenga un ID de jugador válido: `assertEquals(1, player.getPlayerId())`.
  - En `testHumanPlayerRemoteInput`:
    - Simular señales de teclado mediante la fachada: `dopoGame.movePlayer(1, Direction.UP)` y `dopoGame.movePlayer(2, Direction.UP)`.
    - Verificar que el input afecte únicamente al jugador correspondiente, garantizando el aislamiento de controles por ID.
  - En `testPlayerMovementStepPrecision`, invocar `player.setSpeed(5.0)` en el elemento móvil y comprobar que el paso de traslación se actualice a la nueva velocidad en los ticks subsiguientes de movimiento.
* **Justificación**: Garantiza la integridad del modo multijugador local y remoto, comprobando que las señales de teclado e inputs de red afecten únicamente al jugador correspondiente.

#### 5. Enriquecer `testYellowCoinCollection` (en `BoardElementTest`)
* **Diseño**:
  - Verificar que las monedas amarillas del tablero sean contadas correctamente por `gameMode.countCoins()`, verificando que califiquen de manera integrada como requeridas.
* **Justificación**: Evita que fallos en la definición de coleccionables del nivel alteren el total de monedas necesarias para activar la meta de victoria.

---

## 3. Cobertura de Faltantes 2.0

Esta sección detalla el diseño de pruebas específicas para cubrir las brechas de cobertura de código remanentes (indicadas en rojo en los reportes de cobertura):

| Clase / Enum | Método o Bloque a Cubrir | Estrategia de Prueba Integrada | Test Asociado |
| :--- | :--- | :--- | :--- |
| `Direction` | Bucle y retorno en `fromVector(int, int)` | Probar la conversión de vectores direccionales válidos e inválidos. | `testDirectionFromVectorParsing` (en `PlayerSkinTest`) |
| `GameState` | Casos nulos, tipos ajenos e igualdad en `equals(Object)` | Validar que el comparador maneje nulls, clases ajenas y nombres diferentes. | `testGameStateEquality` (en `GameplayLogicTest`) |
| `CollectableElement` | Métodos base `countsAsRequiredCoin`, `getHitbox`, `collideWithPlayer` y `isCollected` | Instanciar un subtipo anónimo (dummy) para forzar la ejecución de los métodos de la clase abstracta. | `testCollectableElementBaseMethods` (en `BoardElementTest`) |

### Detalles de Diseño e Implementación:

#### 1. Nuevo `testDirectionFromVectorParsing` (en `PlayerSkinTest.java`)
* **Diseño**:
  - Invocar `Direction.fromVector(1, 0)` y verificar que retorne `Direction.EAST`.
  - Invocar `Direction.fromVector(0, -1)` y verificar que retorne `Direction.NORTH`.
  - Invocar `Direction.fromVector(99, 99)` (vector inválido) y verificar que retorne `Direction.NONE`.
* **Justificación**: Garantiza la cobertura del bucle interno `values()` en la conversión matemática de vectores de movimiento procedentes de los eventos del teclado, así como el retorno seguro de `NONE`.

#### 2. Nuevo `testGameStateEquality` (en `GameplayLogicTest.java`)
* **Diseño**:
  - Comparar `GameState.PLAYING` contra sí mismo (`assertTrue(GameState.PLAYING.equals(GameState.PLAYING))`).
  - Comparar `GameState.PLAYING` contra `null` (`assertFalse(GameState.PLAYING.equals(null))`).
  - Comparar `GameState.PLAYING` contra un objeto de tipo diferente (e.g. `String`) (`assertFalse(GameState.PLAYING.equals("PLAYING"))`).
  - Comparar `GameState.PLAYING` contra `GameState.PAUSED` (`assertFalse(GameState.PLAYING.equals(GameState.PAUSED))`).
* **Justificación**: Cubre de forma exhaustiva las ramificaciones condicionales de comparación de clases y valores de cadena de los estados del juego, previniendo errores durante su serialización o actualización en el motor.

#### 3. Nuevo `testCollectableElementBaseMethods` (en `BoardElementTest.java`)
* **Diseño**:
  - Definir una clase interna anónima que extienda `CollectableElement`.
  - Invocar `dummy.countsAsRequiredCoin()` y assert `true`.
  - Invocar `dummy.getHitbox()` y validar que retorne un `CircularHitbox` centrado con radio 10.
  - Invocar `dummy.collideWithPlayer(player, gameMode)` con la moneda activa e inactiva, verificando que invoque a `collect(...)` de manera interna.
  - Invocar `dummy.isCollected()` y verificar que retorne el estado del booleano `collected`.
* **Justificación**: Permite ejecutar directamente el código base de la superclase abstracta `CollectableElement`, el cual de otra forma queda enmascarado por las sobreescrituras en las subclases concretas (`YellowCoin` y `SkinCoin`).

---

## 4. Cobertura de Faltantes 2.0 (Parte II)

Esta sección cubre las brechas adicionales identificadas en la segunda tanda de pantallazos de cobertura, relativas a `Wall`, `LevelLoader` y la fachada `DOPOGame`:

| Clase / Componente | Bloque a Cubrir | Estrategia de Prueba Integrada | Test Asociado |
| :--- | :--- | :--- | :--- |
| `Wall` | Renderizado `toVisualMap` en muros visibles | Aseverar los valores del diccionario retornado al renderizar un muro activo. | `testWallCollisionObstruction` (en `BoardElementTest`) |
| `LevelLoader` | `IntermediateZone`, monedas de skins, validación de longitudes y excepciones | Cargar líneas de configuración que usen checkpoints, monedas de skins específicas (azul, verde, roja) y entradas malformadas de parámetros. | `testLevelLoaderValidationExtended` (en `PersistenceLogTest`) |
| `DOPOGame` | Sobrecargas de `startGame`, `restoreGame` y capturas de excepciones | Invocar las sobrecargas de inicio/restauración de partida por skin/color y forzar el disparo y captura de `DopoException`. | `testDOPOGameLifecycleAndRestore` (en `PersistenceLogTest`) |
| `DOPOGame` | Getters de estado y fallbacks de control | Invocar getters del HUD y consultas de muertes/monedas con índices fuera de rango (fallback a 0). | `testDOPOGameGettersAndFallbacks` (en `PersistenceLogTest`) |

### Detalles de Diseño e Implementación:

#### 1. Enriquecer `testWallCollisionObstruction` (en `BoardElementTest.java`)
* **Diseño**:
  - Tras verificar la colisión del muro, llamar a `wall.toVisualMap()`.
  - Comprobar que el mapa contenga la forma `"RECT"`, las coordenadas correspondientes, el color azul/gris pastel `(140, 150, 220)` y el borde negro `(0, 0, 0)`.
* **Justificación**: Garantiza la cobertura de la rama de renderizado del muro cuando este es visible e interactivo en pantalla.

#### 2. Nuevo `testLevelLoaderValidationExtended` (en `PersistenceLogTest.java`)
* **Diseño**:
  - Invocar por reflexión `parseLevelLines` con líneas válidas de `IntermediateZone` (`ZONE INTERMEDIATE 10 20 30 40`) y verificar que se agreguen al tablero.
  - Probar excepciones de tipos de zona desconocidos (`ZONE EXOTIC 10 20 30 40`) esperando `IllegalArgumentException`.
  - Cargar y validar monedas de skin (`COIN SKIN BLUE 10 10`, `COIN SKIN GREEN 10 10`, `COIN SKIN RED 10 10`) y comprobar su inclusión.
  - Probar excepciones de skin desconocida (`COIN SKIN PURPLE 10 10`) y parámetros incompletos (`COIN SKIN BLUE 10`).
  - Probar parámetros incompletos para monedas amarillas (`COIN YELLOW 10`) y tipo de moneda desconocido (`COIN SILVER 10 10`).
  - Probar enemigos básicos con dirección inválida (`ENEMY BASIC 10 10 X 2.0`).
  - Probar enemigos patrulleros con velocidad negativa (`ENEMY PATROL 10 10 50 0 -2.0`).
  - Probar enemigos patrulleros válidos (`ENEMY PATROL 10 10 50 0 2.0`) y verificar que se inserten.
  - Probar enemigos con tipo desconocido (`ENEMY ALIEN 10 10`).
* **Justificación**: Cubre de forma robusta y al 100% todas las ramas lógicas, validaciones dimensionales, comprobaciones de sintaxis y conversiones de tipo en el parser de archivos de nivel.

#### 3. Nuevo `testDOPOGameLifecycleAndRestore` (en `PersistenceLogTest.java`)
* **Diseño**:
  - Crear una instancia de `DOPOGame`.
  - Invocar las sobrecargas de `startGame` usando objetos `PlayerSkin` / `ElementColor` y usando índices directos de skin con colores personalizados.
  - Llamar a `getCurrentLevelName()` y verificar que retorne `"level1"`.
  - Forzar que `startGame` lance y capture `DopoException` pasando un archivo de nivel corrupto o inexistente.
  - Configurar un tablero y llamar a `restoreGame` para validar las tres variantes de restauración de partida (con lista de jugadores, con objetos de skins y con índices/colores personalizados).
  - Forzar que `restoreGame` dispare la excepción cuando el tablero es `null`.
* **Justificación**: Garantiza la correcta inicialización del motor, el flujo de recuperación de estados ante desconexiones o reinicios, y la resistencia a errores del controlador central.

#### 4. Nuevo `testDOPOGameGettersAndFallbacks` (en `PersistenceLogTest.java`)
* **Diseño**:
  - Invocar getters de estadísticas de jugadores con índices válidos e inválidos (e.g. `99`) para asegurar el retorno defensivo de `0`:
    - `getPlayerDeaths(99)`
    - `getPlayerCollectedCoins(99)`
    - `getPlayerTotalCoinsRequired(99)`
  - Invocar `setPlayerDirection(99, 1, 0)` (ID inválido) y `setPlayerDirection(0, 1, -1)` (dirección diagonal en jugador 1).
  - Invocar `getAvailableSkins()`, `getTimeRemaining()`, `getGameMode()`, `getTimer()`, y `setBoard(Board)`.
* **Justificación**: Incrementa la robustez de las APIs públicas de la fachada, garantizando que el acoplamiento con la interfaz gráfica maneje con gracia las llamadas fuera de rango y estados nulos sin producir excepciones de puntero nulo (`NullPointerException`).

#### 5. Nuevo `testDOPOGameFacadeExtremelyRigorous` (en `PersistenceLogTest.java`)
* **Diseño**:
  - Instanciar `DOPOGame` y comprobar que el estado inicial de la fachada sea `READY` y que las llamadas a `movePlayer` o `tick` en este estado no operativo se desvíen por el retorno temprano.
  - Asegurar que `getObjectsData()` y `getPlayersData()` devuelvan listas vacías ante objetos nulos.
  - Iniciar una partida válida, pausar, comprobar el estado `PAUSED`, llamar a `togglePause()` en ambas direcciones, y reanudar.
  - Provocar la finalización manual llamando a `endGame()`.
  - Probar `loadLevelAndRestore()` cargando el archivo de nivel de producción `levels/level1.txt`.
  - Forzar que el temporizador venza a través de reflexión y llamar a `tick()` para asegurar la transición de estado a `GAME_OVER`.
* **Justificación**: Cubre al 100% las ramas de pause, resume, togglePause, endGame, getters booleanos de estado, obtención de datos de renderizado en maps de Java, restauración integrada y finalización por expiración del timer.



