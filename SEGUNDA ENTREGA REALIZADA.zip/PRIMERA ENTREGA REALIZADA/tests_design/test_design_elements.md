# Especificación de Casos de Prueba: Elementos del Tablero (`test_design_elements.md`)

Este documento detalla el diseño de pruebas rígidas para validar el comportamiento físico y lógico de los elementos interactivos del escenario: monedas (amarillas y de skin), zonas (inicio, meta y checkpoints) y muros.

---

### Módulo E01: Monedas y Coleccionables

#### **Caso de Prueba E01.1: `testYellowCoinCollection`**
* **Propósito**: Verificar que recolectar una moneda amarilla aumente el contador del jugador y apague la moneda lógica y visualmente en el tablero.
* **Precondiciones**:
  * Jugador con `RedSkin` en `Position(100, 100)`.
  * `YellowCoin` agregada al tablero en `Position(100, 100)`.
* **Acción**: Ejecutar `coin.collideWithPlayer(player, gameMode)`.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(1, player.getCollectedCoins());`
  * `assertFalse(coin.isActive());`
  * `assertTrue(coin.isCollected());`
  * `Map<String, Object> map = coin.toVisualMap();`
  * `assertTrue(map.isEmpty());` (Una moneda inactiva no debe tener mapa visual)
* **Justificación**: Evita que las monedas recolectadas sigan consumiendo recursos de pintado o bloqueando/activando colisiones fantasmas.

#### **Caso de Prueba E01.2: `testSkinCoinCollectionBlue`**
* **Propósito**: Verificar que recolectar una moneda de Skin Azul cambie la skin actual del jugador de forma instantánea a `BlueSkin`.
* **Precondiciones**:
  * Jugador con `RedSkin` (inicial).
  * `SkinCoin` creada con `new BlueSkin()` en `Position(100, 100)`.
* **Acción**: Ejecutar `skinCoin.collideWithPlayer(player, gameMode)`.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals("BlueSkin", player.getCurrentSkin().getName());`
  * `assertEquals(3.6, player.getCurrentSkin().getSpeed(), 0.001);`
  * `assertTrue(skinCoin.isCollected());`
* **Justificación**: Garantiza la inyección correcta del comportamiento de la skin recogible.

#### **Caso de Prueba E01.3: `testSkinCoinVisualColorMatch`**
* **Propósito**: Verificar que el mapa visual de la moneda de skin exporte exactamente los componentes RGB correspondientes a la skin que porta.
* **Precondiciones**:
  * `SkinCoin` asociada a `GreenSkin` creada en `Position(0,0)`.
* **Acción**: Invocar `skinCoin.toVisualMap()`.
* **Aseveraciones (`Asserts`)**:
  * `Map<String, Object> data = skinCoin.toVisualMap();`
  * `assertEquals(0, (int)data.get("r"));` (GreenSkin es RGB: 0, 255, 0)
  * `assertEquals(255, (int)data.get("g"));`
  * `assertEquals(0, (int)data.get("b"));`
* **Justificación**: Evita bugs donde el color visual de la moneda de skin no corresponda con la skin que otorga, confundiendo al usuario.

---

### Módulo E02: Zonas del Tablero

#### **Caso de Prueba E02.1: `testInitialZoneCentering`**
* **Propósito**: Verificar que la zona inicial (`InitialZone`) calcule correctamente el punto de reaparición centrado para el jugador 1.
* **Precondiciones**:
  * `InitialZone` creada en `Position(200, 200)` con ancho `100` y alto `100`.
* **Acción**: Consultar `initialZone.getSpawnPoint()`.
* **Aseveraciones (`Asserts`)**:
  * `Position spawn = initialZone.getSpawnPoint();`
  * `assertEquals(240.0, spawn.getX(), 0.001);` (200 + 50 - BASE_SIZE/2)
  * `assertEquals(240.0, spawn.getY(), 0.001);`
* **Justificación**: Evita desalineación visual del jugador al aparecer en el juego.

#### **Caso de Prueba E02.2: `testIntermediateZoneCheckpoint`**
* **Propósito**: Verificar que colisionar con una zona intermedia actualice el punto de reaparición (*spawnPoint*) del jugador y que este persista tras la muerte.
* **Precondiciones**:
  * Jugador con spawn inicial en `Position(0, 0)`.
  * `IntermediateZone` ubicada en `Position(300, 300)` con dimensiones 50x50.
* **Acción**:
  * Mover jugador a `Position(310, 310)`.
  * Simular colisión llamando a `checkpoint.collideWithPlayer(player, gameMode)`.
  * Invocar `player.die()`.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(new Position(315, 315), player.getSpawnPoint());`
  * `assertEquals(new Position(315, 315), player.getPosition());`
* **Justificación**: Garantiza la funcionalidad correcta del Checkpoint (salvaguarda de avance en niveles largos).

---

### Módulo E03: Muros (`Wall`)

#### **Caso de Prueba E03.1: `testWallCollisionObstruction`**
* **Propósito**: Verificar que un muro sólido impida al jugador moverse a una posición que traslape su área física.
* **Precondiciones**:
  * Muro (`Wall`) creado en `Position(100, 100)` con ancho `50` y alto `50`.
  * Jugador situado en `Position(75, 100)` (justo al borde izquierdo del muro).
* **Acción**: Intentar moverse al ESTE (`Direction.EAST`), calculando la próxima posición e invocando `board.isWalkable()`.
* **Aseveraciones (`Asserts`)**:
  * `Position next = player.getPosition().translate(2.4, 0);`
  * `boolean walkable = board.isWalkable(next, Player.BASE_SIZE);`
  * `assertFalse("La posición de traslape con la pared no debe ser transitable", walkable);`
* **Justificación**: Garantiza la solidez de las físicas, impidiendo que el jugador atraviese obstáculos.
