# Especificación de Casos de Prueba: QA Adicional y Cobertura Extrema (`test_design_extra.md`)

Este documento complementa el diseño de pruebas con escenarios críticos adicionales enfocados en la precisión geométrica, la recolección exhaustiva de todas las skins, ciclos de muerte/checkpoint, validación estricta de excepciones y técnicas para maximizar la cobertura (*Coverage Test*) sin comprometer la rigidez lógica.

---

### Módulo EX_01: Precisión Geométrica y Movilidad

#### **Caso de Prueba EX_M01: `testPlayerMovementStepPrecision`**
* **Propósito**: Verificar la exactitud matemática de la posición acumulada del jugador después de múltiples movimientos sucesivos en línea recta.
* **Precondiciones**:
  * Jugador con `RedSkin` (velocidad `2.4`) posicionado en `Position(100.0, 100.0)`.
* **Acción**: Simular la pulsación y movimiento continuo hacia el ESTE (`Direction.EAST`) durante 10 ticks de juego.
* **Aseveraciones (`Asserts`)**:
  * `Position current = player.getPosition();`
  * `for(int i = 0; i < 10; i++) { current = current.translate(2.4, 0); }`
  * `player.setPosition(current);`
  * `assertEquals(124.0, player.getPosition().getX(), 0.001);`
  * `assertEquals(100.0, player.getPosition().getY(), 0.001);`
* **Justificación**: Previene errores de acumulación de punto flotante en trayectorias largas.

#### **Caso de Prueba EX_M02: `testDiagonalDisplacementLimit`**
* **Propósito**: Garantizar que el desplazamiento en diagonal no exceda la velocidad proporcional del jugador (evitando velocidad doble).
* **Precondiciones**:
  * Jugador con `RedSkin` (velocidad `2.4`) posicionado en `Position(0.0, 0.0)`.
* **Acción**: Mover el jugador en diagonal Noreste (`Direction.NORTH_EAST`).
* **Aseveraciones (`Asserts`)**:
  * `Position next = player.calculateNextPosition();`
  * `double distance = Math.sqrt(Math.pow(next.getX() - 0, 2) + Math.pow(next.getY() - 0, 2));`
  * `assertTrue(distance <= 2.4 * Math.sqrt(2));` (Validación del vector resultante)
* **Justificación**: Evita que los jugadores se desplacen más rápido de lo diseñado al presionar dos teclas direccionales al mismo tiempo.

---

### Módulo EX_02: Verificación de Monedas de Skin (Todas las Skins)

#### **Caso de Prueba EX_S01: `testBlueSkinCoinCollection`**
* **Propósito**: Validar que recolectar una `SkinCoin` de color azul aplique correctamente la `BlueSkin` con sus correspondientes cambios físicos de escala y velocidad.
* **Precondiciones**:
  * Jugador inicia con `RedSkin` (velocidad `2.4`, tamaño `1.0`).
  * `SkinCoin` azul creada con `new BlueSkin()`.
* **Acción**: Recolectar la moneda azul.
* **Aseveraciones (`Asserts`)**:
  * `player.collectCoin(blueCoin);`
  * `assertEquals(BlueSkin.class, player.getCurrentSkin().getClass());`
  * `assertEquals(3.6, player.getCurrentSkin().getSpeed(), 0.001);`
  * `assertEquals(1.5, player.getCurrentSkin().getSize(), 0.001);`

#### **Caso de Prueba EX_S02: `testGreenSkinCoinCollection`**
* **Propósito**: Validar que recolectar una `SkinCoin` de color verde aplique correctamente la `GreenSkin` con el escudo activo.
* **Precondiciones**:
  * Jugador inicia con `RedSkin`.
  * `SkinCoin` verde creada con `new GreenSkin()`.
* **Acción**: Recolectar la moneda verde.
* **Aseveraciones (`Asserts`)**:
  * `player.collectCoin(greenCoin);`
  * `assertEquals(GreenSkin.class, player.getCurrentSkin().getClass());`
  * `assertEquals(2.4, player.getCurrentSkin().getSpeed(), 0.001);`
  * `assertEquals(HitResult.SURVIVED_SHIELD, player.receiveHit());`

#### **Caso de Prueba EX_S03: `testRedSkinCoinCollection`**
* **Propósito**: Validar que recolectar una `SkinCoin` de color rojo devuelva al jugador a la `RedSkin` estándar si tenía otra activa.
* **Precondiciones**:
  * Jugador con `BlueSkin` activa en el juego.
  * `SkinCoin` roja creada con `new RedSkin()`.
* **Acción**: Recolectar la moneda roja.
* **Aseveraciones (`Asserts`)**:
  * `player.collectCoin(redCoin);`
  * `assertEquals(RedSkin.class, player.getCurrentSkin().getClass());`
  * `assertEquals(2.4, player.getCurrentSkin().getSpeed(), 0.001);`
  * `assertEquals(HitResult.DEAD, player.receiveHit());`

---

### Módulo EX_03: Flujo de Reaparición en Checkpoint (IntermediateZone)

#### **Caso de Prueba EX_C01: `testRespawnAtCheckpointExactCoordinates`**
* **Propósito**: Verificar que al morir el jugador reaparezca exactamente en la coordenada centradada de la última `IntermediateZone` que activó, y no en la zona inicial.
* **Precondiciones**:
  * `InitialZone` en `(0, 0, 50, 50)` -> Spawn inicial centrado en `(15, 15)`.
  * `IntermediateZone` en `(500, 500, 100, 100)` -> Spawn centrado en `(540, 540)`.
  * Jugador instanciado y movido a `(510, 510)`.
* **Acción**:
  * Colisionar con la zona intermedia para activar el Checkpoint.
  * Recibir un golpe fatal y reaparecer.
* **Aseveraciones (`Asserts`)**:
  * `checkpoint.collideWithPlayer(player, gameMode);`
  * `player.die();`
  * `player.respawn();`
  * `assertEquals(540.0, player.getPosition().getX(), 0.001);`
  * `assertEquals(540.0, player.getPosition().getY(), 0.001);`

---

### Módulo EX_04: Reinicio Total ante la Muerte del Jugador

#### **Caso de Prueba EX_R01: `testFullResetStateOnDeath`**
* **Propósito**: Asegurar que al morir un jugador, todo su estado dinámico del nivel se reinicie (contador de monedas a 0, reactivación de monedas en el tablero, y reversión a la skin inicial).
* **Precondiciones**:
  * Jugador creado con skin base `RedSkin`.
  * Recoge una `YellowCoin` y una `SkinCoin` de `BlueSkin`.
  * El jugador tiene ahora 2 monedas y skin `BlueSkin`.
* **Acción**: Simular impacto fatal `player.die()` y restructurar escenario.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(0, player.getCollectedCoins());`
  * `assertEquals(RedSkin.class, player.getCurrentSkin().getClass());`
  * `assertTrue(yellowCoin.isActive());`
  * `assertTrue(skinCoin.isActive());`
* **Justificación**: Mantiene la dificultad clásica del juego original (si mueres, debes recolectar todo de nuevo).

---

### Módulo EX_05: Verificación de Zona de Victoria en Ambos Escenarios

#### **Caso de Prueba EX_V01: `testVictoryConditionMet`**
* **Propósito**: Comprobar que estar en la `FinalZone` con todas las monedas obligatorias recolectadas dispare la victoria de forma exitosa.
* **Precondiciones**:
  * Total de monedas requeridas = `2`.
  * Jugador recoge las `2` monedas y se ubica en la `FinalZone`.
* **Acción**: Evaluar `gameMode.checkVictory()`.
* **Aseveraciones (`Asserts`)**:
  * `assertTrue(gameMode.checkVictory());`

#### **Caso de Prueba EX_V02: `testVictoryConditionDenied`**
* **Propósito**: Comprobar que estar en la `FinalZone` pero con menos monedas de las requeridas retorne falso.
* **Precondiciones**:
  * Total de monedas requeridas = `2`.
  * Jugador recoge sólo `1` moneda y se ubica en la `FinalZone`.
* **Acción**: Evaluar `gameMode.checkVictory()`.
* **Aseveraciones (`Asserts`)**:
  * `assertFalse(gameMode.checkVictory());`

---

### Módulo EX_06: Excepciones de Lector de Niveles y Escritura de Logs

#### **Caso de Prueba EX_E01: `testLevelLoaderExceptionOnMalformedInput`**
* **Propósito**: Validar que líneas irreconocibles en los archivos de nivel lancen una excepción estructurada para evitar configuraciones erráticas.
* **Precondiciones**:
  * Archivo de nivel que incluye una instrucción corrupta: `INVALID_CMD ABC 123`.
* **Acción**: Intentar procesar la línea con `LevelLoader`.
* **Aseveraciones (`Asserts`)**:
  * Capturar la excepción y verificar que sea `DopoException`.

#### **Caso de Prueba EX_E02: `testLoggerAppendPerformance`**
* **Propósito**: Verificar que registrar múltiples excepciones en `Log` escriba en modo append sin sobreescribir los logs previos del archivo `Tower.log`.
* **Precondiciones**:
  * Limpiar el archivo `Tower.log`.
* **Acción**:
  * Registrar `DopoException("Error 1")`.
  * Registrar `DopoException("Error 2")`.
* **Aseveraciones (`Asserts`)**:
  * Contar las líneas de `Tower.log` y comprobar que ambas excepciones se registren consecutivamente.
  * `assertTrue(logFileContent.contains("Error 1"));`
  * `assertTrue(logFileContent.contains("Error 2"));`

---

### Módulo EX_07: Propuestas de Pruebas Adicionales (Mejora de Cobertura)

Para maximizar la cobertura (*Test Coverage*) sobre áreas que suelen pasarse por alto en las entregas, sugiero agregar los siguientes dos diseños:

1. **`testPlayerBoundsObstruction` (Límite del Tablero)**:
   * **Objetivo**: Comprobar que el jugador no pueda salirse físicamente de las dimensiones de la pantalla (ej. coordenadas negativas en X/Y, o X > 800, Y > 600), incluso si el usuario mantiene presionada una tecla de dirección.
   * **Verificación**: Al mover el jugador en `(0, 0)` al OESTE, `board.isWalkable()` debe dar falso.

2. **`testEnemyListIsolationAfterClear` (Estabilidad de Memoria)**:
   * **Objetivo**: Verificar que al limpiar el tablero (`board.clearAll()`), las referencias internas se eliminen por completo y no queden retenidas en listas estáticas o de persistencia, previniendo fugas de memoria (*memory leaks*).
   * **Verificación**: Assert de listas `isEmpty()` tras llamada a `clearAll()`.

---

### Módulo EX_08: Organización de Clases de Test (Mapeo a Clases Java)

Para organizar de manera limpia los 42 casos de prueba (29 existentes y 13 nuevos), estructuraremos el código de pruebas en **cuatro clases Java especializadas** dentro del directorio `src/test/`. A continuación se detalla la distribución de los casos de prueba mediante tablas:

#### Tabla 1: `PlayerSkinTest.java` (14 Casos de Prueba)
*Centrada en atributos físicos, movimientos y habilidades especiales de los jugadores y sus apariencias.*

| ID del Método de Test | Tipo | Origen | Validación Principal |
| :--- | :---: | :--- | :--- |
| `testPlayerDefaultInitialization` | Existente | `P01.1` | Valores por defecto al inicializar un jugador (`deaths=0`, `coins=0`, no invulnerable). |
| `testFactorySinglePlayerMode` | **NUEVO** | `P02.1` | La fábrica crea exactamente 1 jugador humano para el modo individual. |
| `testFactoryPvPMode` | **NUEVO** | `P02.2` | La fábrica crea exactamente 2 jugadores con sus skins correspondientes en PvP. |
| `testPlayerMovementNorth` | Existente | `P03.1` | Disminución correcta de la coordenada Y al moverse al Norte basándose en la velocidad. |
| `testPlayerMovementDiagonal` | Existente | `P03.2` | Suma correcta de vectores direccionales (Norte-Este) en la traslación de posición. |
| `testPlayerMovementStepPrecision` | **NUEVO** | `EX_M01` | Precisión de coordenadas tras una secuencia continua de 10 ticks de movimiento. |
| `testDiagonalDisplacementLimit` | **NUEVO** | `EX_M02` | Comprobación de que el movimiento diagonal respete la escala proporcional de velocidad (evita doble velocidad). |
| `testRedSkinMortalHit` | Existente | `P04.1` | La skin estándar roja (`RedSkin`) muere al primer golpe fatal. |
| `testBlueSkinAttributes` | Existente | `P04.2` | Comprobación de atributos físicos de `BlueSkin` (velocidad `3.6`, escala física `1.5`). |
| `testGreenSkinFirstHitShield` | Existente | `P04.3` | Absorción del primer impacto por el escudo de `GreenSkin` (retorna `SURVIVED_SHIELD`, activa invulnerabilidad). |
| `testGreenSkinInvulnerabilityTimer` | Existente | `P04.4` | Decremento secuencial y expiración exacta de los 60 ticks de invulnerabilidad. |
| `testGreenSkinSecondHitFatal` | Existente | `P04.5` | El segundo impacto tras expirar la invulnerabilidad resulta en la muerte de `GreenSkin`. |
| `testGreenSkinRespawnResetsShield` | Existente | `P04.6` | Al reaparecer tras morir, la skin verde recupera el escudo y su velocidad base de `2.4`. |
| `testPlayerBoundsObstruction` | **NUEVO** | `EX_A01` | Bloqueo de coordenadas físicas en los límites de pantalla `(0, 0)` y `(800, 600)`. |

---

#### Tabla 2: `BoardElementTest.java` (7 Casos de Prueba)
*Centrada en coleccionables, obstáculos sólidos estáticos y zonas del tablero.*

| ID del Método de Test | Tipo | Origen | Validación Principal |
| :--- | :---: | :--- | :--- |
| `testYellowCoinCollection` | Existente | `E01.1` | Incremento de monedas del jugador y desactivación lógica/visual de la moneda amarilla. |
| `testSkinCoinCollectionBlue` | Existente | `E01.2` | Transición y cambio de skin en tiempo real al recoger una moneda de skin. |
| `testSkinCoinVisualColorMatch` | Existente | `E01.3` | Los valores RGB del mapa visual coinciden con el color físico de la skin que la moneda porta. |
| `testInitialZoneCentering` | Existente | `E02.1` | Cálculo matemático centrado del punto de aparición basándose en las dimensiones de `InitialZone`. |
| `testIntermediateZoneCheckpoint` | Existente | `E02.2` | Actualización de la coordenada de reaparición del jugador al entrar en contacto con una zona intermedia. |
| `testWallCollisionObstruction` | Existente | `E03.1` | Retorno de `walkable = false` al intentar desplazarse a una coordenada traslapada con un muro. |
| `testWallBlockingPath` | Existente | Original | El jugador no puede avanzar a través de bloques marcados como sólidos en el tablero. |

---

#### Tabla 3: `GameplayLogicTest.java` (11 Casos de Prueba)
*Centrada en motores de colisiones de enemigos, lógica del temporizador del juego y mecánicas de PvP.*

| ID del Método de Test | Tipo | Origen | Validación Principal |
| :--- | :---: | :--- | :--- |
| `testEnemyCollisionDetection` | Existente | Original | Identificación de colisión física cuando el jugador toca la caja de colisión de un enemigo azul. |
| `testNoEnemyCollisionWhenFar` | Existente | Original | Sin colisiones falsas positivas cuando los enemigos están en coordenadas distantes. |
| `testEnemyBasicLinearBounce` | Existente | `G01.1` | Rebote e inversión de dirección de un enemigo lineal al chocar contra un muro. |
| `testEnemyCircularPatrolPath` | Existente | `G01.2` | Desplazamiento orbital correcto (cálculo trigonométrico en coordenadas) de los enemigos circulares. |
| `testGameTimerTickAndExpiration` | Existente | `G02.1` | Descuento regular de segundos en cada tick y activación del estado de expiración del tiempo. |
| `testGamePauseLogic` | Existente | `G02.2` | En estado pausado, las posiciones de jugadores/enemigos y el temporizador quedan congelados. |
| `testPvPMutualPlayerCollision` | Existente | Original | Muerte mutua de ambos jugadores si colisionan entre sí en modo multijugador local. |
| `testPvPPlayerCollisionReset` | **NUEVO** | `G03.1` | Incremento de muertes y reinicio de monedas recolectadas para ambos jugadores al colisionar. |
| `testVictoryConditionMet` | **NUEVO** | `EX_V01` | Victoria habilitada en `FinalZone` al haber recogido el 100% de las monedas obligatorias. |
| `testVictoryConditionDenied` | **NUEVO** | `EX_V02` | Denegación de victoria si el jugador pisa la `FinalZone` pero no tiene todas las monedas obligatorias. |
| `testEnemyListIsolationAfterClear` | **NUEVO** | `EX_A02` | Eliminación total de referencias del tablero tras invocar `clearAll()` para evitar fugas de memoria. |

---

#### Tabla 4: `PersistenceLogTest.java` (10 Casos de Prueba)
*Centrada en la serialización, la carga e integridad de archivos y la persistencia de excepciones en la bitácora.*

| ID del Método de Test | Tipo | Origen | Validación Principal |
| :--- | :---: | :--- | :--- |
| `testDeepSerializationIntegrity` | Existente | `S01.1` | Serialización de partida en archivo y deserialización con valores de jugador, estadísticas y mapa idénticos. |
| `testLevelLoaderValidationInvalidWallDimension` | Existente | `S02.1` | Excepción `INVALID_DIMENSION` al intentar cargar un nivel con dimensiones de muro <= 0. |
| `testLevelLoaderValidationNegativeEnemySpeed` | Existente | `S02.2` | Excepción `INVALID_SPEED` al intentar cargar un nivel con velocidad de enemigo negativa. |
| `testLevelLoaderValidationNegativePatrolRadius` | Existente | `S02.3` | Excepción `INVALID_RADIUS` al intentar cargar un nivel con radio de enemigo patrullero negativo. |
| `testLevelLoaderValidationMissingZones` | Existente | `S02.4` | Excepción por ausencia de zonas obligatorias (`INITIAL` o `FINAL`) en el archivo `.txt`. |
| `testLevelLoaderExceptionOnMalformedInput` | **NUEVO** | `EX_E01` | Lanzamiento de excepciones lógicas al parsear líneas corruptas o comandos desconocidos. |
| `testLoggerCreationAndIntegrity` | Existente | `S03.1` | Generación y escritura física del archivo `Tower.log` al capturar una excepción del sistema. |
| `testLoggerAppendPerformance` | **NUEVO** | `EX_E02` | Mantenimiento histórico de registros en el archivo log mediante concatenación (`append`) sin sobrescritura. |
| `testGameFacadeDecouplingLoadCustomLevel` | Existente | Original | Propagación controlada de excepciones al cargar un archivo de nivel personalizado inexistente. |
| `testDOPOGameSaveOpenExceptionLogging` | Existente | Original | Manejo y logging de errores ante intentos de guardado en rutas de disco inexistentes o protegidas. |
