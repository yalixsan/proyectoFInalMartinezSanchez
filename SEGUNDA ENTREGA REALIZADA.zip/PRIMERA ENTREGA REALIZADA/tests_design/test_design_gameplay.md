# Especificación de Casos de Prueba: Mecánicas y Jugabilidad (`test_design_gameplay.md`)

Este documento detalla los casos de prueba necesarios para validar las colisiones, el bucle de juego, el control del temporizador, la pausa y el modo multijugador local (PvP).

---

### Módulo G01: Colisión y Movimiento de Enemigos

#### **Caso de Prueba G01.1: `testEnemyBasicLinearBounce`**
* **Propósito**: Verificar que un enemigo con patrón de movimiento lineal (`LinearMovement`) avance en su dirección y rebote (invierta su signo de dirección) al tocar una pared sólida.
* **Precondiciones**:
  * Enemigo básico en `Position(90, 100)` con velocidad `5.0` y dirección horizontal `H` (hacia la derecha).
  * Muro sólido ubicado en `Position(100, 100)` de 20x20.
* **Acción**: Ejecutar `enemy.tick(board)` dos veces seguidas.
* **Aseveraciones (`Asserts`)**:
  * En la primera ejecución, colisiona con el muro y cambia la dirección: `directionSign` debe invertirse a `-1`.
  * En la segunda ejecución, la posición del enemigo debe retroceder: `Position` final debe ser menor que la inicial en X.
* **Justificación**: Evita que los enemigos se queden atascados contra las paredes o las atraviesen.

#### **Caso de Prueba G01.2: `testEnemyCircularPatrolPath`**
* **Propósito**: Verificar que un enemigo patrullero (`CircularMovement`) describa una trayectoria circular alrededor de su centro en cada tick.
* **Precondiciones**:
  * Enemigo patrullero creado con centro en `(400, 300)`, radio `50`, ángulo inicial `0` y velocidad angular `2.0`.
* **Acción**: Invocar `enemy.tick(board)`.
* **Aseveraciones (`Asserts`)**:
  * `double rad = Math.toRadians(0 + 2.0);`
  * `double expectedX = (400 + 50 * Math.cos(rad)) - Enemy.VISUAL_RADIUS;`
  * `double expectedY = (300 + 50 * Math.sin(rad)) - Enemy.VISUAL_RADIUS;`
  * `assertEquals(expectedX, enemy.getPosition().getX(), 0.01);`
  * `assertEquals(expectedY, enemy.getPosition().getY(), 0.01);`
* **Justificación**: Valida la fidelidad matemática de las trayectorias curvas de los enemigos.

---

### Módulo G02: Bucle del Temporizador y Pausa

#### **Caso de Prueba G02.1: `testGameTimerTickAndExpiration`**
* **Propósito**: Verificar que el temporizador disminuya de segundo en segundo en cada tick y lance el evento de Game Over al llegar a 0.
* **Precondiciones**:
  * Instanciar `GameTimer` con un límite inicial de `2` segundos.
* **Acción**: Invocar `timer.tick()` tres veces.
* **Aseveraciones (`Asserts`)**:
  * `timer.tick();` -> `assertEquals(1, timer.getRemainingTime());`
  * `timer.tick();` -> `assertEquals(0, timer.getRemainingTime());`
  * `assertTrue(timer.isExpired());`
* **Justificación**: Asegura la precisión de la condición de derrota por tiempo.

#### **Caso de Prueba G02.2: `testGamePauseLogic`**
* **Propósito**: Verificar que al pausar el juego (`GameState.PAUSED`), las coordenadas de los personajes permanezcan estáticas e inmunes a llamadas accidentales del método `tick()`.
* **Precondiciones**:
  * `DOPOGame` inicializado en modo `SinglePlayer`, en estado `PAUSED`.
  * Guardar coordenadas iniciales del jugador.
* **Acción**:
  * Invocar `game.movePlayer(1, Direction.EAST)`.
  * Invocar `game.tick()`.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(posicionInicial, jugador.getPosition());`
  * `assertEquals(tiempoRestanteInicial, timer.getRemainingTime());`
* **Justificación**: Evita que los jugadores o enemigos se desplacen o que el tiempo siga transcurriendo en la pantalla de pausa.

---

### Módulo G03: Multijugador Local (PvP)

#### **Caso de Prueba G03.1: `testPvPPlayerCollisionReset`**
* **Propósito**: Verificar que si en modo PvP los dos jugadores colisionan entre sí, ambos sumen una muerte, sus monedas individuales se reinicien y reaparezcan en su zona segura.
* **Precondiciones**:
  * Dos jugadores instanciados en modo PvP.
  * Jugador 1 ha recolectado 2 monedas. Jugador 2 ha recolectado 1 moneda.
* **Acción**: Invocar `gameMode.handlePlayerPlayerCollision(p1, p2)`.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(1, p1.getDeaths());`
  * `assertEquals(1, p2.getDeaths());`
  * `assertEquals(0, p1.getCollectedCoins());`
  * `assertEquals(0, p2.getCollectedCoins());`
* **Justificación**: Garantiza la penalización equitativa y la restauración del tablero en la competencia.

---

### Módulo G04: Condiciones de Victoria

#### **Caso de Prueba G04.1: `testVictoryValidationRequireAllCoins`**
* **Propósito**: Asegurar que la meta (`FinalZone`) no admita la victoria si queda alguna moneda obligatoria sin recoger, e inclusive si el jugador está parado sobre la meta.
* **Precondiciones**:
  * Nivel cargado con total de monedas requeridas = `3`.
  * Jugador ha recogido `2` monedas y se posiciona dentro de la `FinalZone`.
* **Acción**: Evaluar `gameMode.checkVictory()`.
* **Aseveraciones (`Asserts`)**:
  * `assertFalse("No debería ganar si faltan monedas obligatorias", gameMode.checkVictory());`
* **Justificación**: Protege la regla fundamental del juego: la recolección total es mandatoria antes de escapar.
