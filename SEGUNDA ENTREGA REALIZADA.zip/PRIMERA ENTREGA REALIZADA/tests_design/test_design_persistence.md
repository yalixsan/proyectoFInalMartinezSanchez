# Especificación de Casos de Prueba: Persistencia, Lector de Niveles y Robustez (`test_design_persistence.md`)

Este documento especifica las pruebas encargadas de validar que el cargador de archivos de niveles y la serialización binaria sean seguros, reporten errores de manera clara y controlen los fallos de lectura/escritura mediante logs.

---

### Módulo S01: Serialización Profunda (`DOPOPersistence`)

#### **Caso de Prueba S01.1: `testDeepSerializationIntegrity`**
* **Propósito**: Verificar que al serializar la partida en disco y volverla a cargar, se restaure exactamente el mismo estado lógico en memoria, incluyendo la inmutabilidad de los objetos deserializados.
* **Precondiciones**:
  * Instancia de `DOPOGame` iniciada.
  * Jugador 1 en `Position(150, 200)` habiendo acumulado `3` monedas y `2` muertes.
  * Un archivo temporal creado en disco.
* **Acción**:
  * Ejecutar `DOPOPersistence.save(tempFile, game)`.
  * Instanciar `DOPOGame loaded = DOPOPersistence.open(tempFile)`.
* **Aseveraciones (`Asserts`)**:
  * `assertNotNull("El juego deserializado no debe ser nulo", loaded);`
  * `assertEquals(3, loaded.getPlayerCollectedCoins(0));`
  * `assertEquals(2, loaded.getPlayerDeaths(0));`
  * `assertEquals(150, (int)loaded.getPlayersData().get(0).get("x"));`
  * `assertEquals(200, (int)loaded.getPlayersData().get(0).get("y"));`
* **Justificación**: Garantiza la fiabilidad del sistema de "Guardar partida" y "Cargar partida" sin pérdida de datos.

---

### Módulo S02: Validaciones Semánticas en el Lector de Niveles (`LevelLoader`)

Para evitar errores en tiempo de ejecución por archivos `.txt` de nivel corruptos o mal estructurados, el analizador debe ser muy restrictivo:

#### **Caso de Prueba S02.1: `testLevelLoaderValidationInvalidWallDimension`**
* **Propósito**: Validar que el cargador rechace dimensiones de muro nulas o negativas.
* **Precondiciones**:
  * Un bloque de líneas que define una pared con ancho <= 0: `WALL 100 100 0 50 true`.
* **Acción**: Invocar el parsing de líneas de `LevelLoader`.
* **Aseveraciones (`Asserts`)**:
  * Comprobar que lance una `DopoException` cuyo mensaje interno contenga la constante `DopoException.INVALID_DIMENSION`.
* **Justificación**: Evita colisiones infinitas o deformidades visuales causadas por geometrías inexistentes en el mapa.

#### **Caso de Prueba S02.2: `testLevelLoaderValidationNegativeEnemySpeed`**
* **Propósito**: Validar que el cargador de niveles no admita velocidades de enemigos negativas.
* **Precondiciones**:
  * Línea de enemigo con velocidad negativa: `ENEMY BASIC 100 100 H -2.0`.
* **Acción**: Invocar el parsing del nivel.
* **Aseveraciones (`Asserts`)**:
  * Capturar la excepción y verificar que el mensaje interno sea `DopoException.INVALID_SPEED`.
* **Justificación**: Previene el movimiento invertido no controlado en el motor de físicas.

#### **Caso de Prueba S02.3: `testLevelLoaderValidationNegativePatrolRadius`**
* **Propósito**: Validar que el cargador rechace radios de patrulla negativos para enemigos circulares.
* **Precondiciones**:
  * Línea del nivel: `ENEMY PATROL 100 100 -25 0 2.0`.
* **Acción**: Invocar el parsing del nivel.
* **Aseveraciones (`Asserts`)**:
  * Capturar la excepción y validar que el mensaje contenga `DopoException.INVALID_RADIUS`.
* **Justificación**: Evita errores aritméticos trigonométricos por radios negativos en el cálculo de órbitas.

#### **Caso de Prueba S02.4: `testLevelLoaderValidationMissingZones`**
* **Propósito**: Validar que el nivel sea rechazado si no define al menos una zona inicial y una zona final.
* **Precondiciones**:
  * Un archivo de nivel `.txt` sin ninguna declaración `ZONE INITIAL` o `ZONE FINAL`.
* **Acción**: Intentar cargar el archivo con `LevelLoader.loadLevel`.
* **Aseveraciones (`Asserts`)**:
  * Capturar la excepción y validar que el mensaje contenga `DopoException.MISSING_INITIAL_ZONE` o `DopoException.MISSING_FINAL_ZONE`.
* **Justificación**: Impide que el jugador aparezca fuera del mapa o no tenga una meta física para ganar el nivel.

---

### Módulo S03: Bitácora de Errores e Integración del Logger (`Log`)

#### **Caso de Prueba S03.1: `testLoggerCreationAndIntegrity`**
* **Propósito**: Verificar que ante cualquier excepción capturada por el sistema, se genere un registro físico legible en el archivo de registro `Tower.log`.
* **Precondiciones**:
  * Eliminar el archivo `Tower.log` en el directorio del proyecto si existe.
* **Acción**:
  * Disparar una excepción simulada y grabarla llamando a `Log.record(exception)`.
* **Aseveraciones (`Asserts`)**:
  * `File logFile = new File("Tower.log");`
  * `assertTrue("El archivo de log se debe haber creado", logFile.exists());`
  * `assertTrue("El archivo no debe estar vacío", logFile.length() > 0);`
* **Justificación**: Ofrece trazabilidad de fallos a los desarrolladores cuando ocurran errores inesperados en el despliegue del juego.
