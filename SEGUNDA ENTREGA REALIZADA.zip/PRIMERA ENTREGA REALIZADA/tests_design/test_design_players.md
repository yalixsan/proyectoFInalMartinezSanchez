# Especificación de Casos de Prueba: Jugadores, Fábrica y Skins (`test_design_players.md`)

Este documento contiene el diseño de pruebas unitarias específicas y rígidas para verificar el comportamiento de los personajes, sus habilidades físicas y la fábrica encargada de su creación.

---

### Módulo P01: Inicialización y Estructura Base

#### **Caso de Prueba P01.1: `testPlayerDefaultInitialization`**
* **Propósito**: Verificar que un jugador recién creado tenga su estado inicial correcto y limpio.
* **Precondiciones**:
  * Instancia de `RedSkin` y `Position(100, 150)` creadas.
* **Acción**: Instanciar `HumanPlayer` y consultar sus variables de estado.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(100.0, player.getPosition().getX(), 0.001);`
  * `assertEquals(150.0, player.getPosition().getY(), 0.001);`
  * `assertEquals(0, player.getDeaths());`
  * `assertEquals(0, player.getCollectedCoins());`
  * `assertFalse(player.isInvulnerable());`
* **Justificación**: Garantiza la consistencia en el inicio de la partida.

---

### Módulo P02: Fábrica de Jugadores (`PlayerFactory`)

#### **Caso de Prueba P02.1: `testFactorySinglePlayerMode`**
* **Propósito**: Validar que en modo solitario la fábrica cree únicamente el jugador 1.
* **Precondiciones**:
  * Instancias de skins `RedSkin` y `BlueSkin` creadas.
* **Acción**: Invocar `PlayerFactory.createPlayers("SinglePlayer", redSkin, ElementColor.RED, blueSkin, ElementColor.BLUE, availableSkins)`.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(1, players.size());`
  * `assertEquals(HumanPlayer.class, players.get(0).getClass());`
  * `assertEquals("RedSkin", players.get(0).getCurrentSkin().getName());`
* **Justificación**: Evita que se instancien personajes fantasma en partidas individuales.

#### **Caso de Prueba P02.2: `testFactoryPvPMode`**
* **Propósito**: Validar que en modo multijugador local se creen exactamente dos jugadores con las skins correspondientes.
* **Precondiciones**:
  * Instancias de skins `RedSkin` y `BlueSkin` creadas.
* **Acción**: Invocar `PlayerFactory.createPlayers("PvP", redSkin, ElementColor.RED, blueSkin, ElementColor.BLUE, availableSkins)`.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(2, players.size());`
  * `assertEquals("RedSkin", players.get(0).getCurrentSkin().getName());`
  * `assertEquals("BlueSkin", players.get(1).getCurrentSkin().getName());`
* **Justificación**: Garantiza el setup correcto de partidas cooperativas/competitivas locales.

---

### Módulo P03: Movimiento y Física de Posición

#### **Caso de Prueba P03.1: `testPlayerMovementNorth`**
* **Propósito**: Verificar que el movimiento hacia el Norte decremente la coordenada Y según la velocidad exacta del jugador.
* **Precondiciones**:
  * Jugador con `RedSkin` en `Position(100, 100)`.
* **Acción**:
  * Invocar `player.setCurrentDirection(Direction.NORTH)`.
  * Invocar `player.move(board)` o `player.calculateNextPosition()`.
* **Aseveraciones (`Asserts`)**:
  * `Position next = player.calculateNextPosition();`
  * `assertEquals(100.0, next.getX(), 0.001);`
  * `assertEquals(100.0 - 2.4, next.getY(), 0.001);`
* **Justificación**: Evita regresiones en el sistema de coordenadas de la pantalla (Y decrece hacia arriba).

#### **Caso de Prueba P03.2: `testPlayerMovementDiagonal`**
* **Propósito**: Verificar que los movimientos diagonales (ej. Noreste) combinen correctamente los vectores X e Y.
* **Precondiciones**:
  * Jugador con `RedSkin` en `Position(100, 100)`.
* **Acción**:
  * Invocar `player.setCurrentDirection(Direction.NORTH_EAST)`.
* **Aseveraciones (`Asserts`)**:
  * `Position next = player.calculateNextPosition();`
  * `assertEquals(100.0 + 2.4, next.getX(), 0.001);`
  * `assertEquals(100.0 - 2.4, next.getY(), 0.001);`
* **Justificación**: Valida la fluidez en el control omnidireccional.

---

### Módulo P04: Mecánicas de Skins y Habilidades

#### **Caso de Prueba P04.1: `testRedSkinMortalHit`**
* **Propósito**: Verificar que la skin estándar (RedSkin) muera inmediatamente ante un golpe.
* **Precondiciones**:
  * Jugador con `RedSkin` en `Position(100, 100)`.
* **Acción**: Invocar `player.receiveHit()`.
* **Aseveraciones (`Asserts`)**:
  * `HitResult res = player.receiveHit();`
  * `assertEquals(HitResult.DEAD, res);`
  * `assertEquals(1, player.getDeaths());`
* **Justificación**: Asegura que el juego aplique el reinicio por impacto para la skin estándar.

#### **Caso de Prueba P04.2: `testBlueSkinAttributes`**
* **Propósito**: Verificar el tamaño de caja de colisión y velocidad de la skin veloz (BlueSkin).
* **Precondiciones**:
  * Jugador con `BlueSkin` en `Position(100, 100)`.
* **Acción**: Obtener la velocidad y el visualMap del jugador.
* **Aseveraciones (`Asserts`)**:
  * `assertEquals(3.6, player.getCurrentSkin().getSpeed(), 0.001);`
  * `Map<String, Object> data = player.toVisualMap();`
  * `assertEquals(30, (int)data.get("w"));` (BASE_SIZE 20 * 1.5)
  * `assertEquals(30, (int)data.get("h"));`
* **Justificación**: Valida que la skin rápida sea de hecho un 50% más grande y rápida.

#### **Caso de Prueba P04.3: `testGreenSkinFirstHitShield`**
* **Propósito**: Verificar la absorción del escudo de Clyde (GreenSkin) en su primer impacto.
* **Precondiciones**:
  * Jugador con `GreenSkin` en `Position(100, 100)`.
* **Acción**: Invocar `player.receiveHit()`.
* **Aseveraciones (`Asserts`)**:
  * `HitResult res = player.receiveHit();`
  * `assertEquals(HitResult.SURVIVED_SHIELD, res);`
  * `assertEquals(0, player.getDeaths());`
  * `assertEquals(2.4 * 0.7, player.getCurrentSkin().getSpeed(), 0.001);` (Velocidad reducida)
  * `assertTrue(player.isInvulnerable());`
* **Justificación**: Valida que la mecánica de absorción de daño y la penalización de velocidad se activen juntas.

#### **Caso de Prueba P04.4: `testGreenSkinInvulnerabilityTimer`**
* **Propósito**: Validar que el temporizador de invulnerabilidad decrementa en cada tick y expire correctamente.
* **Precondiciones**:
  * Jugador con `GreenSkin` golpeado una vez (invulnerable).
* **Acción**: Decrementar la invulnerabilidad 60 veces usando `player.decreaseInvulnerability()`.
* **Aseveraciones (`Asserts`)**:
  * `assertTrue(player.isInvulnerable());`
  * `for(int i=0; i<60; i++) player.decreaseInvulnerability();`
  * `assertFalse(player.isInvulnerable());`
* **Justificación**: Asegura que el estado de inmunidad parpadeante no dure de forma indefinida.

#### **Caso de Prueba P04.5: `testGreenSkinSecondHitFatal`**
* **Propósito**: Verificar que una vez roto el escudo y expirada la invulnerabilidad, el siguiente golpe mate al jugador con GreenSkin.
* **Precondiciones**:
  * Jugador con `GreenSkin` golpeado una vez, invulnerabilidad expirada.
* **Acción**: Invocar `player.receiveHit()`.
* **Aseveraciones (`Asserts`)**:
  * `HitResult res = player.receiveHit();`
  * `assertEquals(HitResult.DEAD, res);`
  * `assertEquals(1, player.getDeaths());`
* **Justificación**: Evita inmortalidad infinita de la GreenSkin.

#### **Caso de Prueba P04.6: `testGreenSkinRespawnResetsShield`**
* **Propósito**: Validar que al reaparecer tras morir, la GreenSkin recupere su escudo y su velocidad original de 2.4.
* **Precondiciones**:
  * Jugador con `GreenSkin` muerto (muertes = 1).
* **Acción**: Invocar `player.respawn()`.
* **Aseveraciones (`Asserts`)**:
  * `player.respawn();`
  * `assertEquals(2.4, player.getCurrentSkin().getSpeed(), 0.001);`
  * `assertFalse(player.isInvulnerable());`
* **Justificación**: Garantiza la restauración del estado físico óptimo tras reiniciar la reaparición.
